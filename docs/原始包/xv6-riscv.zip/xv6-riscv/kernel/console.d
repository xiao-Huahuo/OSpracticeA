kernel/console.o: kernel/console.c \
 /opt/homebrew/Cellar/riscv64-elf-gcc/16.2.0/lib/gcc/riscv64-elf/16.2.0/include/stdarg.h \
 kernel/types.h kernel/param.h kernel/spinlock.h kernel/sleeplock.h \
 kernel/fs.h kernel/file.h kernel/memlayout.h kernel/riscv.h \
 kernel/defs.h kernel/proc.h
