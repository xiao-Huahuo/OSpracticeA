user/printf.o: user/printf.c kernel/types.h kernel/stat.h user/user.h \
 /opt/homebrew/Cellar/riscv64-elf-gcc/16.2.0/lib/gcc/riscv64-elf/16.2.0/include/stdarg.h
