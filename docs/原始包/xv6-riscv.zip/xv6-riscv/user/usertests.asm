
user/_usertests:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <copyinstr1>:
}

// what if you pass ridiculous string pointers to system calls?
void
copyinstr1(char *s)
{
       0:	711d                	addi	sp,sp,-96
       2:	ec86                	sd	ra,88(sp)
       4:	e8a2                	sd	s0,80(sp)
       6:	e4a6                	sd	s1,72(sp)
       8:	e0ca                	sd	s2,64(sp)
       a:	fc4e                	sd	s3,56(sp)
       c:	f852                	sd	s4,48(sp)
       e:	1080                	addi	s0,sp,96
  uint64 addrs[] = {0x80000000LL, 0x3fffffe000, 0x3ffffff000, 0x4000000000,
      10:	00008797          	auipc	a5,0x8
      14:	2d878793          	addi	a5,a5,728 # 82e8 <malloc+0x2930>
      18:	638c                	ld	a1,0(a5)
      1a:	6790                	ld	a2,8(a5)
      1c:	6b94                	ld	a3,16(a5)
      1e:	6f98                	ld	a4,24(a5)
      20:	fab43423          	sd	a1,-88(s0)
      24:	fac43823          	sd	a2,-80(s0)
      28:	fad43c23          	sd	a3,-72(s0)
      2c:	fce43023          	sd	a4,-64(s0)
      30:	739c                	ld	a5,32(a5)
      32:	fcf43423          	sd	a5,-56(s0)
                    0xffffffffffffffff};

  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
      36:	fa840493          	addi	s1,s0,-88
      3a:	fd040a13          	addi	s4,s0,-48
    uint64 addr = addrs[ai];

    int fd = open((char *)addr, O_CREATE | O_WRONLY);
      3e:	20100993          	li	s3,513
      42:	0004b903          	ld	s2,0(s1)
      46:	85ce                	mv	a1,s3
      48:	854a                	mv	a0,s2
      4a:	494050ef          	jal	54de <open>
    if (fd >= 0) {
      4e:	00055d63          	bgez	a0,68 <copyinstr1+0x68>
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
      52:	04a1                	addi	s1,s1,8
      54:	ff4497e3          	bne	s1,s4,42 <copyinstr1+0x42>
      printf("open(%p) returned %d, not -1\n", (void *)addr, fd);
      exit(1);
    }
  }
}
      58:	60e6                	ld	ra,88(sp)
      5a:	6446                	ld	s0,80(sp)
      5c:	64a6                	ld	s1,72(sp)
      5e:	6906                	ld	s2,64(sp)
      60:	79e2                	ld	s3,56(sp)
      62:	7a42                	ld	s4,48(sp)
      64:	6125                	addi	sp,sp,96
      66:	8082                	ret
      printf("open(%p) returned %d, not -1\n", (void *)addr, fd);
      68:	862a                	mv	a2,a0
      6a:	85ca                	mv	a1,s2
      6c:	00006517          	auipc	a0,0x6
      70:	a4450513          	addi	a0,a0,-1468 # 5ab0 <malloc+0xf8>
      74:	089050ef          	jal	58fc <printf>
      exit(1);
      78:	4505                	li	a0,1
      7a:	424050ef          	jal	549e <exit>

000000000000007e <bsstest>:
void
bsstest(char *s)
{
  int i;

  for (i = 0; i < sizeof(uninit); i++) {
      7e:	0000a797          	auipc	a5,0xa
      82:	55a78793          	addi	a5,a5,1370 # a5d8 <uninit>
      86:	0000d697          	auipc	a3,0xd
      8a:	c6268693          	addi	a3,a3,-926 # cce8 <buf>
    if (uninit[i] != '\0') {
      8e:	0007c703          	lbu	a4,0(a5)
      92:	e709                	bnez	a4,9c <bsstest+0x1e>
  for (i = 0; i < sizeof(uninit); i++) {
      94:	0785                	addi	a5,a5,1
      96:	fed79ce3          	bne	a5,a3,8e <bsstest+0x10>
      9a:	8082                	ret
{
      9c:	1141                	addi	sp,sp,-16
      9e:	e406                	sd	ra,8(sp)
      a0:	e022                	sd	s0,0(sp)
      a2:	0800                	addi	s0,sp,16
      printf("%s: bss test failed\n", s);
      a4:	85aa                	mv	a1,a0
      a6:	00006517          	auipc	a0,0x6
      aa:	a2a50513          	addi	a0,a0,-1494 # 5ad0 <malloc+0x118>
      ae:	04f050ef          	jal	58fc <printf>
      exit(1);
      b2:	4505                	li	a0,1
      b4:	3ea050ef          	jal	549e <exit>

00000000000000b8 <opentest>:
{
      b8:	1101                	addi	sp,sp,-32
      ba:	ec06                	sd	ra,24(sp)
      bc:	e822                	sd	s0,16(sp)
      be:	e426                	sd	s1,8(sp)
      c0:	1000                	addi	s0,sp,32
      c2:	84aa                	mv	s1,a0
  fd = open("echo", 0);
      c4:	4581                	li	a1,0
      c6:	00006517          	auipc	a0,0x6
      ca:	a2250513          	addi	a0,a0,-1502 # 5ae8 <malloc+0x130>
      ce:	410050ef          	jal	54de <open>
  if (fd < 0) {
      d2:	02054263          	bltz	a0,f6 <opentest+0x3e>
  close(fd);
      d6:	3f0050ef          	jal	54c6 <close>
  fd = open("doesnotexist", 0);
      da:	4581                	li	a1,0
      dc:	00006517          	auipc	a0,0x6
      e0:	a2c50513          	addi	a0,a0,-1492 # 5b08 <malloc+0x150>
      e4:	3fa050ef          	jal	54de <open>
  if (fd >= 0) {
      e8:	02055163          	bgez	a0,10a <opentest+0x52>
}
      ec:	60e2                	ld	ra,24(sp)
      ee:	6442                	ld	s0,16(sp)
      f0:	64a2                	ld	s1,8(sp)
      f2:	6105                	addi	sp,sp,32
      f4:	8082                	ret
    printf("%s: open echo failed!\n", s);
      f6:	85a6                	mv	a1,s1
      f8:	00006517          	auipc	a0,0x6
      fc:	9f850513          	addi	a0,a0,-1544 # 5af0 <malloc+0x138>
     100:	7fc050ef          	jal	58fc <printf>
    exit(1);
     104:	4505                	li	a0,1
     106:	398050ef          	jal	549e <exit>
    printf("%s: open doesnotexist succeeded!\n", s);
     10a:	85a6                	mv	a1,s1
     10c:	00006517          	auipc	a0,0x6
     110:	a0c50513          	addi	a0,a0,-1524 # 5b18 <malloc+0x160>
     114:	7e8050ef          	jal	58fc <printf>
    exit(1);
     118:	4505                	li	a0,1
     11a:	384050ef          	jal	549e <exit>

000000000000011e <truncate2>:
{
     11e:	7179                	addi	sp,sp,-48
     120:	f406                	sd	ra,40(sp)
     122:	f022                	sd	s0,32(sp)
     124:	ec26                	sd	s1,24(sp)
     126:	e84a                	sd	s2,16(sp)
     128:	e44e                	sd	s3,8(sp)
     12a:	1800                	addi	s0,sp,48
     12c:	89aa                	mv	s3,a0
  unlink("truncfile");
     12e:	00006517          	auipc	a0,0x6
     132:	a1250513          	addi	a0,a0,-1518 # 5b40 <malloc+0x188>
     136:	3b8050ef          	jal	54ee <unlink>
  int fd1 = open("truncfile", O_CREATE | O_TRUNC | O_WRONLY);
     13a:	60100593          	li	a1,1537
     13e:	00006517          	auipc	a0,0x6
     142:	a0250513          	addi	a0,a0,-1534 # 5b40 <malloc+0x188>
     146:	398050ef          	jal	54de <open>
     14a:	84aa                	mv	s1,a0
  write(fd1, "abcd", 4);
     14c:	4611                	li	a2,4
     14e:	00006597          	auipc	a1,0x6
     152:	a0258593          	addi	a1,a1,-1534 # 5b50 <malloc+0x198>
     156:	368050ef          	jal	54be <write>
  int fd2 = open("truncfile", O_TRUNC | O_WRONLY);
     15a:	40100593          	li	a1,1025
     15e:	00006517          	auipc	a0,0x6
     162:	9e250513          	addi	a0,a0,-1566 # 5b40 <malloc+0x188>
     166:	378050ef          	jal	54de <open>
     16a:	892a                	mv	s2,a0
  int n = write(fd1, "x", 1);
     16c:	4605                	li	a2,1
     16e:	00006597          	auipc	a1,0x6
     172:	9ea58593          	addi	a1,a1,-1558 # 5b58 <malloc+0x1a0>
     176:	8526                	mv	a0,s1
     178:	346050ef          	jal	54be <write>
  if (n != -1) {
     17c:	57fd                	li	a5,-1
     17e:	02f51563          	bne	a0,a5,1a8 <truncate2+0x8a>
  unlink("truncfile");
     182:	00006517          	auipc	a0,0x6
     186:	9be50513          	addi	a0,a0,-1602 # 5b40 <malloc+0x188>
     18a:	364050ef          	jal	54ee <unlink>
  close(fd1);
     18e:	8526                	mv	a0,s1
     190:	336050ef          	jal	54c6 <close>
  close(fd2);
     194:	854a                	mv	a0,s2
     196:	330050ef          	jal	54c6 <close>
}
     19a:	70a2                	ld	ra,40(sp)
     19c:	7402                	ld	s0,32(sp)
     19e:	64e2                	ld	s1,24(sp)
     1a0:	6942                	ld	s2,16(sp)
     1a2:	69a2                	ld	s3,8(sp)
     1a4:	6145                	addi	sp,sp,48
     1a6:	8082                	ret
    printf("%s: write returned %d, expected -1\n", s, n);
     1a8:	862a                	mv	a2,a0
     1aa:	85ce                	mv	a1,s3
     1ac:	00006517          	auipc	a0,0x6
     1b0:	9b450513          	addi	a0,a0,-1612 # 5b60 <malloc+0x1a8>
     1b4:	748050ef          	jal	58fc <printf>
    exit(1);
     1b8:	4505                	li	a0,1
     1ba:	2e4050ef          	jal	549e <exit>

00000000000001be <createtest>:
{
     1be:	7139                	addi	sp,sp,-64
     1c0:	fc06                	sd	ra,56(sp)
     1c2:	f822                	sd	s0,48(sp)
     1c4:	f426                	sd	s1,40(sp)
     1c6:	f04a                	sd	s2,32(sp)
     1c8:	ec4e                	sd	s3,24(sp)
     1ca:	e852                	sd	s4,16(sp)
     1cc:	0080                	addi	s0,sp,64
  name[0] = 'a';
     1ce:	06100793          	li	a5,97
     1d2:	fcf40423          	sb	a5,-56(s0)
  name[2] = '\0';
     1d6:	fc040523          	sb	zero,-54(s0)
     1da:	03000493          	li	s1,48
    fd = open(name, O_CREATE | O_RDWR);
     1de:	fc840a13          	addi	s4,s0,-56
     1e2:	20200993          	li	s3,514
  for (i = 0; i < N; i++) {
     1e6:	06400913          	li	s2,100
    name[1] = '0' + i;
     1ea:	fc9404a3          	sb	s1,-55(s0)
    fd = open(name, O_CREATE | O_RDWR);
     1ee:	85ce                	mv	a1,s3
     1f0:	8552                	mv	a0,s4
     1f2:	2ec050ef          	jal	54de <open>
    close(fd);
     1f6:	2d0050ef          	jal	54c6 <close>
  for (i = 0; i < N; i++) {
     1fa:	2485                	addiw	s1,s1,1
     1fc:	0ff4f493          	zext.b	s1,s1
     200:	ff2495e3          	bne	s1,s2,1ea <createtest+0x2c>
  name[0] = 'a';
     204:	06100793          	li	a5,97
     208:	fcf40423          	sb	a5,-56(s0)
  name[2] = '\0';
     20c:	fc040523          	sb	zero,-54(s0)
     210:	03000493          	li	s1,48
    unlink(name);
     214:	fc840993          	addi	s3,s0,-56
  for (i = 0; i < N; i++) {
     218:	06400913          	li	s2,100
    name[1] = '0' + i;
     21c:	fc9404a3          	sb	s1,-55(s0)
    unlink(name);
     220:	854e                	mv	a0,s3
     222:	2cc050ef          	jal	54ee <unlink>
  for (i = 0; i < N; i++) {
     226:	2485                	addiw	s1,s1,1
     228:	0ff4f493          	zext.b	s1,s1
     22c:	ff2498e3          	bne	s1,s2,21c <createtest+0x5e>
}
     230:	70e2                	ld	ra,56(sp)
     232:	7442                	ld	s0,48(sp)
     234:	74a2                	ld	s1,40(sp)
     236:	7902                	ld	s2,32(sp)
     238:	69e2                	ld	s3,24(sp)
     23a:	6a42                	ld	s4,16(sp)
     23c:	6121                	addi	sp,sp,64
     23e:	8082                	ret

0000000000000240 <bigwrite>:
{
     240:	711d                	addi	sp,sp,-96
     242:	ec86                	sd	ra,88(sp)
     244:	e8a2                	sd	s0,80(sp)
     246:	e4a6                	sd	s1,72(sp)
     248:	e0ca                	sd	s2,64(sp)
     24a:	fc4e                	sd	s3,56(sp)
     24c:	f852                	sd	s4,48(sp)
     24e:	f456                	sd	s5,40(sp)
     250:	f05a                	sd	s6,32(sp)
     252:	ec5e                	sd	s7,24(sp)
     254:	e862                	sd	s8,16(sp)
     256:	e466                	sd	s9,8(sp)
     258:	1080                	addi	s0,sp,96
     25a:	8caa                	mv	s9,a0
  unlink("bigwrite");
     25c:	00006517          	auipc	a0,0x6
     260:	92c50513          	addi	a0,a0,-1748 # 5b88 <malloc+0x1d0>
     264:	28a050ef          	jal	54ee <unlink>
  for (sz = 499; sz < (MAXOPBLOCKS + 2) * BSIZE; sz += 471) {
     268:	1f300493          	li	s1,499
    fd = open("bigwrite", O_CREATE | O_RDWR);
     26c:	20200b93          	li	s7,514
     270:	00006a17          	auipc	s4,0x6
     274:	918a0a13          	addi	s4,s4,-1768 # 5b88 <malloc+0x1d0>
    if (fd < 0) {
     278:	4b09                	li	s6,2
      int cc = write(fd, buf, sz);
     27a:	0000d997          	auipc	s3,0xd
     27e:	a6e98993          	addi	s3,s3,-1426 # cce8 <buf>
  for (sz = 499; sz < (MAXOPBLOCKS + 2) * BSIZE; sz += 471) {
     282:	6a8d                	lui	s5,0x3
     284:	1c9a8a93          	addi	s5,s5,457 # 31c9 <rmdot+0x55>
    fd = open("bigwrite", O_CREATE | O_RDWR);
     288:	85de                	mv	a1,s7
     28a:	8552                	mv	a0,s4
     28c:	252050ef          	jal	54de <open>
     290:	892a                	mv	s2,a0
    if (fd < 0) {
     292:	04054463          	bltz	a0,2da <bigwrite+0x9a>
     296:	8c5a                	mv	s8,s6
      int cc = write(fd, buf, sz);
     298:	8626                	mv	a2,s1
     29a:	85ce                	mv	a1,s3
     29c:	854a                	mv	a0,s2
     29e:	220050ef          	jal	54be <write>
      if (cc != sz) {
     2a2:	04951663          	bne	a0,s1,2ee <bigwrite+0xae>
    for (i = 0; i < 2; i++) {
     2a6:	3c7d                	addiw	s8,s8,-1
     2a8:	fe0c18e3          	bnez	s8,298 <bigwrite+0x58>
    close(fd);
     2ac:	854a                	mv	a0,s2
     2ae:	218050ef          	jal	54c6 <close>
    unlink("bigwrite");
     2b2:	8552                	mv	a0,s4
     2b4:	23a050ef          	jal	54ee <unlink>
  for (sz = 499; sz < (MAXOPBLOCKS + 2) * BSIZE; sz += 471) {
     2b8:	1d74849b          	addiw	s1,s1,471
     2bc:	fd5496e3          	bne	s1,s5,288 <bigwrite+0x48>
}
     2c0:	60e6                	ld	ra,88(sp)
     2c2:	6446                	ld	s0,80(sp)
     2c4:	64a6                	ld	s1,72(sp)
     2c6:	6906                	ld	s2,64(sp)
     2c8:	79e2                	ld	s3,56(sp)
     2ca:	7a42                	ld	s4,48(sp)
     2cc:	7aa2                	ld	s5,40(sp)
     2ce:	7b02                	ld	s6,32(sp)
     2d0:	6be2                	ld	s7,24(sp)
     2d2:	6c42                	ld	s8,16(sp)
     2d4:	6ca2                	ld	s9,8(sp)
     2d6:	6125                	addi	sp,sp,96
     2d8:	8082                	ret
      printf("%s: cannot create bigwrite\n", s);
     2da:	85e6                	mv	a1,s9
     2dc:	00006517          	auipc	a0,0x6
     2e0:	8bc50513          	addi	a0,a0,-1860 # 5b98 <malloc+0x1e0>
     2e4:	618050ef          	jal	58fc <printf>
      exit(1);
     2e8:	4505                	li	a0,1
     2ea:	1b4050ef          	jal	549e <exit>
        printf("%s: write(%d) ret %d\n", s, sz, cc);
     2ee:	86aa                	mv	a3,a0
     2f0:	8626                	mv	a2,s1
     2f2:	85e6                	mv	a1,s9
     2f4:	00006517          	auipc	a0,0x6
     2f8:	8c450513          	addi	a0,a0,-1852 # 5bb8 <malloc+0x200>
     2fc:	600050ef          	jal	58fc <printf>
        exit(1);
     300:	4505                	li	a0,1
     302:	19c050ef          	jal	549e <exit>

0000000000000306 <badwrite>:
// file is deleted? if the kernel has this bug, it will panic: balloc:
// out of blocks. assumed_free may need to be raised to be more than
// the number of free blocks. this test takes a long time.
void
badwrite(char *s)
{
     306:	7139                	addi	sp,sp,-64
     308:	fc06                	sd	ra,56(sp)
     30a:	f822                	sd	s0,48(sp)
     30c:	f426                	sd	s1,40(sp)
     30e:	f04a                	sd	s2,32(sp)
     310:	ec4e                	sd	s3,24(sp)
     312:	e852                	sd	s4,16(sp)
     314:	e456                	sd	s5,8(sp)
     316:	e05a                	sd	s6,0(sp)
     318:	0080                	addi	s0,sp,64
  int assumed_free = 600;

  unlink("junk");
     31a:	00006517          	auipc	a0,0x6
     31e:	8b650513          	addi	a0,a0,-1866 # 5bd0 <malloc+0x218>
     322:	1cc050ef          	jal	54ee <unlink>
     326:	25800913          	li	s2,600
  for (int i = 0; i < assumed_free; i++) {
    int fd = open("junk", O_CREATE | O_WRONLY);
     32a:	20100a93          	li	s5,513
     32e:	00006997          	auipc	s3,0x6
     332:	8a298993          	addi	s3,s3,-1886 # 5bd0 <malloc+0x218>
    if (fd < 0) {
      printf("open junk failed\n");
      exit(1);
    }
    write(fd, (char *)0xffffffffffL, 1);
     336:	4b05                	li	s6,1
     338:	5a7d                	li	s4,-1
     33a:	018a5a13          	srli	s4,s4,0x18
    int fd = open("junk", O_CREATE | O_WRONLY);
     33e:	85d6                	mv	a1,s5
     340:	854e                	mv	a0,s3
     342:	19c050ef          	jal	54de <open>
     346:	84aa                	mv	s1,a0
    if (fd < 0) {
     348:	04054d63          	bltz	a0,3a2 <badwrite+0x9c>
    write(fd, (char *)0xffffffffffL, 1);
     34c:	865a                	mv	a2,s6
     34e:	85d2                	mv	a1,s4
     350:	16e050ef          	jal	54be <write>
    close(fd);
     354:	8526                	mv	a0,s1
     356:	170050ef          	jal	54c6 <close>
    unlink("junk");
     35a:	854e                	mv	a0,s3
     35c:	192050ef          	jal	54ee <unlink>
  for (int i = 0; i < assumed_free; i++) {
     360:	397d                	addiw	s2,s2,-1
     362:	fc091ee3          	bnez	s2,33e <badwrite+0x38>
  }

  int fd = open("junk", O_CREATE | O_WRONLY);
     366:	20100593          	li	a1,513
     36a:	00006517          	auipc	a0,0x6
     36e:	86650513          	addi	a0,a0,-1946 # 5bd0 <malloc+0x218>
     372:	16c050ef          	jal	54de <open>
     376:	84aa                	mv	s1,a0
  if (fd < 0) {
     378:	02054e63          	bltz	a0,3b4 <badwrite+0xae>
    printf("open junk failed\n");
    exit(1);
  }
  if (write(fd, "x", 1) != 1) {
     37c:	4605                	li	a2,1
     37e:	00005597          	auipc	a1,0x5
     382:	7da58593          	addi	a1,a1,2010 # 5b58 <malloc+0x1a0>
     386:	138050ef          	jal	54be <write>
     38a:	4785                	li	a5,1
     38c:	02f50d63          	beq	a0,a5,3c6 <badwrite+0xc0>
    printf("write failed\n");
     390:	00006517          	auipc	a0,0x6
     394:	86050513          	addi	a0,a0,-1952 # 5bf0 <malloc+0x238>
     398:	564050ef          	jal	58fc <printf>
    exit(1);
     39c:	4505                	li	a0,1
     39e:	100050ef          	jal	549e <exit>
      printf("open junk failed\n");
     3a2:	00006517          	auipc	a0,0x6
     3a6:	83650513          	addi	a0,a0,-1994 # 5bd8 <malloc+0x220>
     3aa:	552050ef          	jal	58fc <printf>
      exit(1);
     3ae:	4505                	li	a0,1
     3b0:	0ee050ef          	jal	549e <exit>
    printf("open junk failed\n");
     3b4:	00006517          	auipc	a0,0x6
     3b8:	82450513          	addi	a0,a0,-2012 # 5bd8 <malloc+0x220>
     3bc:	540050ef          	jal	58fc <printf>
    exit(1);
     3c0:	4505                	li	a0,1
     3c2:	0dc050ef          	jal	549e <exit>
  }
  close(fd);
     3c6:	8526                	mv	a0,s1
     3c8:	0fe050ef          	jal	54c6 <close>
  unlink("junk");
     3cc:	00006517          	auipc	a0,0x6
     3d0:	80450513          	addi	a0,a0,-2044 # 5bd0 <malloc+0x218>
     3d4:	11a050ef          	jal	54ee <unlink>

  exit(0);
     3d8:	4501                	li	a0,0
     3da:	0c4050ef          	jal	549e <exit>

00000000000003de <outofinodes>:
  }
}

void
outofinodes(char *s)
{
     3de:	711d                	addi	sp,sp,-96
     3e0:	ec86                	sd	ra,88(sp)
     3e2:	e8a2                	sd	s0,80(sp)
     3e4:	e4a6                	sd	s1,72(sp)
     3e6:	e0ca                	sd	s2,64(sp)
     3e8:	fc4e                	sd	s3,56(sp)
     3ea:	f852                	sd	s4,48(sp)
     3ec:	f456                	sd	s5,40(sp)
     3ee:	1080                	addi	s0,sp,96
  int nzz = 32 * 32;
  for (int i = 0; i < nzz; i++) {
     3f0:	4481                	li	s1,0
    char name[32];
    name[0] = 'z';
     3f2:	07a00993          	li	s3,122
    name[1] = 'z';
    name[2] = '0' + (i / 32);
    name[3] = '0' + (i % 32);
    name[4] = '\0';
    unlink(name);
     3f6:	fa040913          	addi	s2,s0,-96
    int fd = open(name, O_CREATE | O_RDWR | O_TRUNC);
     3fa:	60200a13          	li	s4,1538
  for (int i = 0; i < nzz; i++) {
     3fe:	40000a93          	li	s5,1024
    name[0] = 'z';
     402:	fb340023          	sb	s3,-96(s0)
    name[1] = 'z';
     406:	fb3400a3          	sb	s3,-95(s0)
    name[2] = '0' + (i / 32);
     40a:	41f4d71b          	sraiw	a4,s1,0x1f
     40e:	01b7571b          	srliw	a4,a4,0x1b
     412:	009707bb          	addw	a5,a4,s1
     416:	4057d69b          	sraiw	a3,a5,0x5
     41a:	0306869b          	addiw	a3,a3,48
     41e:	fad40123          	sb	a3,-94(s0)
    name[3] = '0' + (i % 32);
     422:	8bfd                	andi	a5,a5,31
     424:	9f99                	subw	a5,a5,a4
     426:	0307879b          	addiw	a5,a5,48
     42a:	faf401a3          	sb	a5,-93(s0)
    name[4] = '\0';
     42e:	fa040223          	sb	zero,-92(s0)
    unlink(name);
     432:	854a                	mv	a0,s2
     434:	0ba050ef          	jal	54ee <unlink>
    int fd = open(name, O_CREATE | O_RDWR | O_TRUNC);
     438:	85d2                	mv	a1,s4
     43a:	854a                	mv	a0,s2
     43c:	0a2050ef          	jal	54de <open>
    if (fd < 0) {
     440:	00054763          	bltz	a0,44e <outofinodes+0x70>
      // failure is eventually expected.
      break;
    }
    close(fd);
     444:	082050ef          	jal	54c6 <close>
  for (int i = 0; i < nzz; i++) {
     448:	2485                	addiw	s1,s1,1
     44a:	fb549ce3          	bne	s1,s5,402 <outofinodes+0x24>
  }

  for (int i = 0; i < nzz; i++) {
     44e:	4481                	li	s1,0
    char name[32];
    name[0] = 'z';
     450:	07a00913          	li	s2,122
    name[1] = 'z';
    name[2] = '0' + (i / 32);
    name[3] = '0' + (i % 32);
    name[4] = '\0';
    unlink(name);
     454:	fa040a13          	addi	s4,s0,-96
  for (int i = 0; i < nzz; i++) {
     458:	40000993          	li	s3,1024
    name[0] = 'z';
     45c:	fb240023          	sb	s2,-96(s0)
    name[1] = 'z';
     460:	fb2400a3          	sb	s2,-95(s0)
    name[2] = '0' + (i / 32);
     464:	41f4d71b          	sraiw	a4,s1,0x1f
     468:	01b7571b          	srliw	a4,a4,0x1b
     46c:	009707bb          	addw	a5,a4,s1
     470:	4057d69b          	sraiw	a3,a5,0x5
     474:	0306869b          	addiw	a3,a3,48
     478:	fad40123          	sb	a3,-94(s0)
    name[3] = '0' + (i % 32);
     47c:	8bfd                	andi	a5,a5,31
     47e:	9f99                	subw	a5,a5,a4
     480:	0307879b          	addiw	a5,a5,48
     484:	faf401a3          	sb	a5,-93(s0)
    name[4] = '\0';
     488:	fa040223          	sb	zero,-92(s0)
    unlink(name);
     48c:	8552                	mv	a0,s4
     48e:	060050ef          	jal	54ee <unlink>
  for (int i = 0; i < nzz; i++) {
     492:	2485                	addiw	s1,s1,1
     494:	fd3494e3          	bne	s1,s3,45c <outofinodes+0x7e>
  }
}
     498:	60e6                	ld	ra,88(sp)
     49a:	6446                	ld	s0,80(sp)
     49c:	64a6                	ld	s1,72(sp)
     49e:	6906                	ld	s2,64(sp)
     4a0:	79e2                	ld	s3,56(sp)
     4a2:	7a42                	ld	s4,48(sp)
     4a4:	7aa2                	ld	s5,40(sp)
     4a6:	6125                	addi	sp,sp,96
     4a8:	8082                	ret

00000000000004aa <copyin>:
{
     4aa:	7175                	addi	sp,sp,-144
     4ac:	e506                	sd	ra,136(sp)
     4ae:	e122                	sd	s0,128(sp)
     4b0:	fca6                	sd	s1,120(sp)
     4b2:	f8ca                	sd	s2,112(sp)
     4b4:	f4ce                	sd	s3,104(sp)
     4b6:	f0d2                	sd	s4,96(sp)
     4b8:	ecd6                	sd	s5,88(sp)
     4ba:	e8da                	sd	s6,80(sp)
     4bc:	e4de                	sd	s7,72(sp)
     4be:	e0e2                	sd	s8,64(sp)
     4c0:	fc66                	sd	s9,56(sp)
     4c2:	0900                	addi	s0,sp,144
  uint64 addrs[] = {0x80000000LL, 0x3fffffe000, 0x3ffffff000, 0x4000000000,
     4c4:	00008797          	auipc	a5,0x8
     4c8:	e2478793          	addi	a5,a5,-476 # 82e8 <malloc+0x2930>
     4cc:	638c                	ld	a1,0(a5)
     4ce:	6790                	ld	a2,8(a5)
     4d0:	6b94                	ld	a3,16(a5)
     4d2:	6f98                	ld	a4,24(a5)
     4d4:	f6b43c23          	sd	a1,-136(s0)
     4d8:	f8c43023          	sd	a2,-128(s0)
     4dc:	f8d43423          	sd	a3,-120(s0)
     4e0:	f8e43823          	sd	a4,-112(s0)
     4e4:	739c                	ld	a5,32(a5)
     4e6:	f8f43c23          	sd	a5,-104(s0)
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
     4ea:	f7840913          	addi	s2,s0,-136
     4ee:	fa040c93          	addi	s9,s0,-96
    int fd = open("copyin1", O_CREATE | O_WRONLY);
     4f2:	20100b13          	li	s6,513
     4f6:	00005a97          	auipc	s5,0x5
     4fa:	70aa8a93          	addi	s5,s5,1802 # 5c00 <malloc+0x248>
    int n = write(fd, (void *)addr, 8192);
     4fe:	6a09                	lui	s4,0x2
    n = write(1, (char *)addr, 8192);
     500:	4c05                	li	s8,1
    if (pipe(fds) < 0) {
     502:	f7040b93          	addi	s7,s0,-144
    uint64 addr = addrs[ai];
     506:	00093983          	ld	s3,0(s2)
    int fd = open("copyin1", O_CREATE | O_WRONLY);
     50a:	85da                	mv	a1,s6
     50c:	8556                	mv	a0,s5
     50e:	7d1040ef          	jal	54de <open>
     512:	84aa                	mv	s1,a0
    if (fd < 0) {
     514:	06054a63          	bltz	a0,588 <copyin+0xde>
    int n = write(fd, (void *)addr, 8192);
     518:	8652                	mv	a2,s4
     51a:	85ce                	mv	a1,s3
     51c:	7a3040ef          	jal	54be <write>
    if (n >= 0) {
     520:	06055d63          	bgez	a0,59a <copyin+0xf0>
    close(fd);
     524:	8526                	mv	a0,s1
     526:	7a1040ef          	jal	54c6 <close>
    unlink("copyin1");
     52a:	8556                	mv	a0,s5
     52c:	7c3040ef          	jal	54ee <unlink>
    n = write(1, (char *)addr, 8192);
     530:	8652                	mv	a2,s4
     532:	85ce                	mv	a1,s3
     534:	8562                	mv	a0,s8
     536:	789040ef          	jal	54be <write>
    if (n > 0) {
     53a:	06a04b63          	bgtz	a0,5b0 <copyin+0x106>
    if (pipe(fds) < 0) {
     53e:	855e                	mv	a0,s7
     540:	76f040ef          	jal	54ae <pipe>
     544:	08054163          	bltz	a0,5c6 <copyin+0x11c>
    n = write(fds[1], (char *)addr, 8192);
     548:	8652                	mv	a2,s4
     54a:	85ce                	mv	a1,s3
     54c:	f7442503          	lw	a0,-140(s0)
     550:	76f040ef          	jal	54be <write>
    if (n > 0) {
     554:	08a04263          	bgtz	a0,5d8 <copyin+0x12e>
    close(fds[0]);
     558:	f7042503          	lw	a0,-144(s0)
     55c:	76b040ef          	jal	54c6 <close>
    close(fds[1]);
     560:	f7442503          	lw	a0,-140(s0)
     564:	763040ef          	jal	54c6 <close>
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
     568:	0921                	addi	s2,s2,8
     56a:	f9991ee3          	bne	s2,s9,506 <copyin+0x5c>
}
     56e:	60aa                	ld	ra,136(sp)
     570:	640a                	ld	s0,128(sp)
     572:	74e6                	ld	s1,120(sp)
     574:	7946                	ld	s2,112(sp)
     576:	79a6                	ld	s3,104(sp)
     578:	7a06                	ld	s4,96(sp)
     57a:	6ae6                	ld	s5,88(sp)
     57c:	6b46                	ld	s6,80(sp)
     57e:	6ba6                	ld	s7,72(sp)
     580:	6c06                	ld	s8,64(sp)
     582:	7ce2                	ld	s9,56(sp)
     584:	6149                	addi	sp,sp,144
     586:	8082                	ret
      printf("open(copyin1) failed\n");
     588:	00005517          	auipc	a0,0x5
     58c:	68050513          	addi	a0,a0,1664 # 5c08 <malloc+0x250>
     590:	36c050ef          	jal	58fc <printf>
      exit(1);
     594:	4505                	li	a0,1
     596:	709040ef          	jal	549e <exit>
      printf("write(fd, %p, 8192) returned %d, not -1\n", (void *)addr, n);
     59a:	862a                	mv	a2,a0
     59c:	85ce                	mv	a1,s3
     59e:	00005517          	auipc	a0,0x5
     5a2:	68250513          	addi	a0,a0,1666 # 5c20 <malloc+0x268>
     5a6:	356050ef          	jal	58fc <printf>
      exit(1);
     5aa:	4505                	li	a0,1
     5ac:	6f3040ef          	jal	549e <exit>
      printf("write(1, %p, 8192) returned %d, not -1 or 0\n", (void *)addr, n);
     5b0:	862a                	mv	a2,a0
     5b2:	85ce                	mv	a1,s3
     5b4:	00005517          	auipc	a0,0x5
     5b8:	69c50513          	addi	a0,a0,1692 # 5c50 <malloc+0x298>
     5bc:	340050ef          	jal	58fc <printf>
      exit(1);
     5c0:	4505                	li	a0,1
     5c2:	6dd040ef          	jal	549e <exit>
      printf("pipe() failed\n");
     5c6:	00005517          	auipc	a0,0x5
     5ca:	6ba50513          	addi	a0,a0,1722 # 5c80 <malloc+0x2c8>
     5ce:	32e050ef          	jal	58fc <printf>
      exit(1);
     5d2:	4505                	li	a0,1
     5d4:	6cb040ef          	jal	549e <exit>
      printf("write(pipe, %p, 8192) returned %d, not -1 or 0\n", (void *)addr,
     5d8:	862a                	mv	a2,a0
     5da:	85ce                	mv	a1,s3
     5dc:	00005517          	auipc	a0,0x5
     5e0:	6b450513          	addi	a0,a0,1716 # 5c90 <malloc+0x2d8>
     5e4:	318050ef          	jal	58fc <printf>
      exit(1);
     5e8:	4505                	li	a0,1
     5ea:	6b5040ef          	jal	549e <exit>

00000000000005ee <copyout>:
{
     5ee:	7135                	addi	sp,sp,-160
     5f0:	ed06                	sd	ra,152(sp)
     5f2:	e922                	sd	s0,144(sp)
     5f4:	e526                	sd	s1,136(sp)
     5f6:	e14a                	sd	s2,128(sp)
     5f8:	fcce                	sd	s3,120(sp)
     5fa:	f8d2                	sd	s4,112(sp)
     5fc:	f4d6                	sd	s5,104(sp)
     5fe:	f0da                	sd	s6,96(sp)
     600:	ecde                	sd	s7,88(sp)
     602:	e8e2                	sd	s8,80(sp)
     604:	e4e6                	sd	s9,72(sp)
     606:	1100                	addi	s0,sp,160
  uint64 addrs[] = {0LL,          0x80000000LL, 0x3fffffe000,
     608:	00008797          	auipc	a5,0x8
     60c:	ce078793          	addi	a5,a5,-800 # 82e8 <malloc+0x2930>
     610:	7788                	ld	a0,40(a5)
     612:	7b8c                	ld	a1,48(a5)
     614:	7f90                	ld	a2,56(a5)
     616:	63b4                	ld	a3,64(a5)
     618:	67b8                	ld	a4,72(a5)
     61a:	f6a43823          	sd	a0,-144(s0)
     61e:	f6b43c23          	sd	a1,-136(s0)
     622:	f8c43023          	sd	a2,-128(s0)
     626:	f8d43423          	sd	a3,-120(s0)
     62a:	f8e43823          	sd	a4,-112(s0)
     62e:	6bbc                	ld	a5,80(a5)
     630:	f8f43c23          	sd	a5,-104(s0)
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
     634:	f7040913          	addi	s2,s0,-144
     638:	fa040c93          	addi	s9,s0,-96
    int fd = open("README", 0);
     63c:	00005b17          	auipc	s6,0x5
     640:	684b0b13          	addi	s6,s6,1668 # 5cc0 <malloc+0x308>
    int n = read(fd, (void *)addr, 8192);
     644:	6a89                	lui	s5,0x2
    if (pipe(fds) < 0) {
     646:	f6840c13          	addi	s8,s0,-152
    n = write(fds[1], "x", 1);
     64a:	4a05                	li	s4,1
     64c:	00005b97          	auipc	s7,0x5
     650:	50cb8b93          	addi	s7,s7,1292 # 5b58 <malloc+0x1a0>
    uint64 addr = addrs[ai];
     654:	00093983          	ld	s3,0(s2)
    int fd = open("README", 0);
     658:	4581                	li	a1,0
     65a:	855a                	mv	a0,s6
     65c:	683040ef          	jal	54de <open>
     660:	84aa                	mv	s1,a0
    if (fd < 0) {
     662:	06054863          	bltz	a0,6d2 <copyout+0xe4>
    int n = read(fd, (void *)addr, 8192);
     666:	8656                	mv	a2,s5
     668:	85ce                	mv	a1,s3
     66a:	64d040ef          	jal	54b6 <read>
    if (n > 0) {
     66e:	06a04b63          	bgtz	a0,6e4 <copyout+0xf6>
    close(fd);
     672:	8526                	mv	a0,s1
     674:	653040ef          	jal	54c6 <close>
    if (pipe(fds) < 0) {
     678:	8562                	mv	a0,s8
     67a:	635040ef          	jal	54ae <pipe>
     67e:	06054e63          	bltz	a0,6fa <copyout+0x10c>
    n = write(fds[1], "x", 1);
     682:	8652                	mv	a2,s4
     684:	85de                	mv	a1,s7
     686:	f6c42503          	lw	a0,-148(s0)
     68a:	635040ef          	jal	54be <write>
    if (n != 1) {
     68e:	07451f63          	bne	a0,s4,70c <copyout+0x11e>
    n = read(fds[0], (void *)addr, 8192);
     692:	8656                	mv	a2,s5
     694:	85ce                	mv	a1,s3
     696:	f6842503          	lw	a0,-152(s0)
     69a:	61d040ef          	jal	54b6 <read>
    if (n > 0) {
     69e:	08a04063          	bgtz	a0,71e <copyout+0x130>
    close(fds[0]);
     6a2:	f6842503          	lw	a0,-152(s0)
     6a6:	621040ef          	jal	54c6 <close>
    close(fds[1]);
     6aa:	f6c42503          	lw	a0,-148(s0)
     6ae:	619040ef          	jal	54c6 <close>
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
     6b2:	0921                	addi	s2,s2,8
     6b4:	fb9910e3          	bne	s2,s9,654 <copyout+0x66>
}
     6b8:	60ea                	ld	ra,152(sp)
     6ba:	644a                	ld	s0,144(sp)
     6bc:	64aa                	ld	s1,136(sp)
     6be:	690a                	ld	s2,128(sp)
     6c0:	79e6                	ld	s3,120(sp)
     6c2:	7a46                	ld	s4,112(sp)
     6c4:	7aa6                	ld	s5,104(sp)
     6c6:	7b06                	ld	s6,96(sp)
     6c8:	6be6                	ld	s7,88(sp)
     6ca:	6c46                	ld	s8,80(sp)
     6cc:	6ca6                	ld	s9,72(sp)
     6ce:	610d                	addi	sp,sp,160
     6d0:	8082                	ret
      printf("open(README) failed\n");
     6d2:	00005517          	auipc	a0,0x5
     6d6:	5f650513          	addi	a0,a0,1526 # 5cc8 <malloc+0x310>
     6da:	222050ef          	jal	58fc <printf>
      exit(1);
     6de:	4505                	li	a0,1
     6e0:	5bf040ef          	jal	549e <exit>
      printf("read(fd, %p, 8192) returned %d, not -1 or 0\n", (void *)addr, n);
     6e4:	862a                	mv	a2,a0
     6e6:	85ce                	mv	a1,s3
     6e8:	00005517          	auipc	a0,0x5
     6ec:	5f850513          	addi	a0,a0,1528 # 5ce0 <malloc+0x328>
     6f0:	20c050ef          	jal	58fc <printf>
      exit(1);
     6f4:	4505                	li	a0,1
     6f6:	5a9040ef          	jal	549e <exit>
      printf("pipe() failed\n");
     6fa:	00005517          	auipc	a0,0x5
     6fe:	58650513          	addi	a0,a0,1414 # 5c80 <malloc+0x2c8>
     702:	1fa050ef          	jal	58fc <printf>
      exit(1);
     706:	4505                	li	a0,1
     708:	597040ef          	jal	549e <exit>
      printf("pipe write failed\n");
     70c:	00005517          	auipc	a0,0x5
     710:	60450513          	addi	a0,a0,1540 # 5d10 <malloc+0x358>
     714:	1e8050ef          	jal	58fc <printf>
      exit(1);
     718:	4505                	li	a0,1
     71a:	585040ef          	jal	549e <exit>
      printf("read(pipe, %p, 8192) returned %d, not -1 or 0\n", (void *)addr,
     71e:	862a                	mv	a2,a0
     720:	85ce                	mv	a1,s3
     722:	00005517          	auipc	a0,0x5
     726:	60650513          	addi	a0,a0,1542 # 5d28 <malloc+0x370>
     72a:	1d2050ef          	jal	58fc <printf>
      exit(1);
     72e:	4505                	li	a0,1
     730:	56f040ef          	jal	549e <exit>

0000000000000734 <truncate1>:
{
     734:	711d                	addi	sp,sp,-96
     736:	ec86                	sd	ra,88(sp)
     738:	e8a2                	sd	s0,80(sp)
     73a:	e4a6                	sd	s1,72(sp)
     73c:	e0ca                	sd	s2,64(sp)
     73e:	fc4e                	sd	s3,56(sp)
     740:	f852                	sd	s4,48(sp)
     742:	f456                	sd	s5,40(sp)
     744:	1080                	addi	s0,sp,96
     746:	8a2a                	mv	s4,a0
  unlink("truncfile");
     748:	00005517          	auipc	a0,0x5
     74c:	3f850513          	addi	a0,a0,1016 # 5b40 <malloc+0x188>
     750:	59f040ef          	jal	54ee <unlink>
  int fd1 = open("truncfile", O_CREATE | O_WRONLY | O_TRUNC);
     754:	60100593          	li	a1,1537
     758:	00005517          	auipc	a0,0x5
     75c:	3e850513          	addi	a0,a0,1000 # 5b40 <malloc+0x188>
     760:	57f040ef          	jal	54de <open>
     764:	84aa                	mv	s1,a0
  write(fd1, "abcd", 4);
     766:	4611                	li	a2,4
     768:	00005597          	auipc	a1,0x5
     76c:	3e858593          	addi	a1,a1,1000 # 5b50 <malloc+0x198>
     770:	54f040ef          	jal	54be <write>
  close(fd1);
     774:	8526                	mv	a0,s1
     776:	551040ef          	jal	54c6 <close>
  int fd2 = open("truncfile", O_RDONLY);
     77a:	4581                	li	a1,0
     77c:	00005517          	auipc	a0,0x5
     780:	3c450513          	addi	a0,a0,964 # 5b40 <malloc+0x188>
     784:	55b040ef          	jal	54de <open>
     788:	84aa                	mv	s1,a0
  int n = read(fd2, buf, sizeof(buf));
     78a:	02000613          	li	a2,32
     78e:	fa040593          	addi	a1,s0,-96
     792:	525040ef          	jal	54b6 <read>
  if (n != 4) {
     796:	4791                	li	a5,4
     798:	0af51863          	bne	a0,a5,848 <truncate1+0x114>
  fd1 = open("truncfile", O_WRONLY | O_TRUNC);
     79c:	40100593          	li	a1,1025
     7a0:	00005517          	auipc	a0,0x5
     7a4:	3a050513          	addi	a0,a0,928 # 5b40 <malloc+0x188>
     7a8:	537040ef          	jal	54de <open>
     7ac:	89aa                	mv	s3,a0
  int fd3 = open("truncfile", O_RDONLY);
     7ae:	4581                	li	a1,0
     7b0:	00005517          	auipc	a0,0x5
     7b4:	39050513          	addi	a0,a0,912 # 5b40 <malloc+0x188>
     7b8:	527040ef          	jal	54de <open>
     7bc:	892a                	mv	s2,a0
  n = read(fd3, buf, sizeof(buf));
     7be:	02000613          	li	a2,32
     7c2:	fa040593          	addi	a1,s0,-96
     7c6:	4f1040ef          	jal	54b6 <read>
     7ca:	8aaa                	mv	s5,a0
  if (n != 0) {
     7cc:	e949                	bnez	a0,85e <truncate1+0x12a>
  n = read(fd2, buf, sizeof(buf));
     7ce:	02000613          	li	a2,32
     7d2:	fa040593          	addi	a1,s0,-96
     7d6:	8526                	mv	a0,s1
     7d8:	4df040ef          	jal	54b6 <read>
     7dc:	8aaa                	mv	s5,a0
  if (n != 0) {
     7de:	e155                	bnez	a0,882 <truncate1+0x14e>
  write(fd1, "abcdef", 6);
     7e0:	4619                	li	a2,6
     7e2:	00005597          	auipc	a1,0x5
     7e6:	5d658593          	addi	a1,a1,1494 # 5db8 <malloc+0x400>
     7ea:	854e                	mv	a0,s3
     7ec:	4d3040ef          	jal	54be <write>
  n = read(fd3, buf, sizeof(buf));
     7f0:	02000613          	li	a2,32
     7f4:	fa040593          	addi	a1,s0,-96
     7f8:	854a                	mv	a0,s2
     7fa:	4bd040ef          	jal	54b6 <read>
  if (n != 6) {
     7fe:	4799                	li	a5,6
     800:	0af51363          	bne	a0,a5,8a6 <truncate1+0x172>
  n = read(fd2, buf, sizeof(buf));
     804:	02000613          	li	a2,32
     808:	fa040593          	addi	a1,s0,-96
     80c:	8526                	mv	a0,s1
     80e:	4a9040ef          	jal	54b6 <read>
  if (n != 2) {
     812:	4789                	li	a5,2
     814:	0af51463          	bne	a0,a5,8bc <truncate1+0x188>
  unlink("truncfile");
     818:	00005517          	auipc	a0,0x5
     81c:	32850513          	addi	a0,a0,808 # 5b40 <malloc+0x188>
     820:	4cf040ef          	jal	54ee <unlink>
  close(fd1);
     824:	854e                	mv	a0,s3
     826:	4a1040ef          	jal	54c6 <close>
  close(fd2);
     82a:	8526                	mv	a0,s1
     82c:	49b040ef          	jal	54c6 <close>
  close(fd3);
     830:	854a                	mv	a0,s2
     832:	495040ef          	jal	54c6 <close>
}
     836:	60e6                	ld	ra,88(sp)
     838:	6446                	ld	s0,80(sp)
     83a:	64a6                	ld	s1,72(sp)
     83c:	6906                	ld	s2,64(sp)
     83e:	79e2                	ld	s3,56(sp)
     840:	7a42                	ld	s4,48(sp)
     842:	7aa2                	ld	s5,40(sp)
     844:	6125                	addi	sp,sp,96
     846:	8082                	ret
    printf("%s: read %d bytes, wanted 4\n", s, n);
     848:	862a                	mv	a2,a0
     84a:	85d2                	mv	a1,s4
     84c:	00005517          	auipc	a0,0x5
     850:	50c50513          	addi	a0,a0,1292 # 5d58 <malloc+0x3a0>
     854:	0a8050ef          	jal	58fc <printf>
    exit(1);
     858:	4505                	li	a0,1
     85a:	445040ef          	jal	549e <exit>
    printf("aaa fd3=%d\n", fd3);
     85e:	85ca                	mv	a1,s2
     860:	00005517          	auipc	a0,0x5
     864:	51850513          	addi	a0,a0,1304 # 5d78 <malloc+0x3c0>
     868:	094050ef          	jal	58fc <printf>
    printf("%s: read %d bytes, wanted 0\n", s, n);
     86c:	8656                	mv	a2,s5
     86e:	85d2                	mv	a1,s4
     870:	00005517          	auipc	a0,0x5
     874:	51850513          	addi	a0,a0,1304 # 5d88 <malloc+0x3d0>
     878:	084050ef          	jal	58fc <printf>
    exit(1);
     87c:	4505                	li	a0,1
     87e:	421040ef          	jal	549e <exit>
    printf("bbb fd2=%d\n", fd2);
     882:	85a6                	mv	a1,s1
     884:	00005517          	auipc	a0,0x5
     888:	52450513          	addi	a0,a0,1316 # 5da8 <malloc+0x3f0>
     88c:	070050ef          	jal	58fc <printf>
    printf("%s: read %d bytes, wanted 0\n", s, n);
     890:	8656                	mv	a2,s5
     892:	85d2                	mv	a1,s4
     894:	00005517          	auipc	a0,0x5
     898:	4f450513          	addi	a0,a0,1268 # 5d88 <malloc+0x3d0>
     89c:	060050ef          	jal	58fc <printf>
    exit(1);
     8a0:	4505                	li	a0,1
     8a2:	3fd040ef          	jal	549e <exit>
    printf("%s: read %d bytes, wanted 6\n", s, n);
     8a6:	862a                	mv	a2,a0
     8a8:	85d2                	mv	a1,s4
     8aa:	00005517          	auipc	a0,0x5
     8ae:	51650513          	addi	a0,a0,1302 # 5dc0 <malloc+0x408>
     8b2:	04a050ef          	jal	58fc <printf>
    exit(1);
     8b6:	4505                	li	a0,1
     8b8:	3e7040ef          	jal	549e <exit>
    printf("%s: read %d bytes, wanted 2\n", s, n);
     8bc:	862a                	mv	a2,a0
     8be:	85d2                	mv	a1,s4
     8c0:	00005517          	auipc	a0,0x5
     8c4:	52050513          	addi	a0,a0,1312 # 5de0 <malloc+0x428>
     8c8:	034050ef          	jal	58fc <printf>
    exit(1);
     8cc:	4505                	li	a0,1
     8ce:	3d1040ef          	jal	549e <exit>

00000000000008d2 <writetest>:
{
     8d2:	715d                	addi	sp,sp,-80
     8d4:	e486                	sd	ra,72(sp)
     8d6:	e0a2                	sd	s0,64(sp)
     8d8:	fc26                	sd	s1,56(sp)
     8da:	f84a                	sd	s2,48(sp)
     8dc:	f44e                	sd	s3,40(sp)
     8de:	f052                	sd	s4,32(sp)
     8e0:	ec56                	sd	s5,24(sp)
     8e2:	e85a                	sd	s6,16(sp)
     8e4:	e45e                	sd	s7,8(sp)
     8e6:	0880                	addi	s0,sp,80
     8e8:	8baa                	mv	s7,a0
  fd = open("small", O_CREATE | O_RDWR);
     8ea:	20200593          	li	a1,514
     8ee:	00005517          	auipc	a0,0x5
     8f2:	51250513          	addi	a0,a0,1298 # 5e00 <malloc+0x448>
     8f6:	3e9040ef          	jal	54de <open>
  if (fd < 0) {
     8fa:	08054f63          	bltz	a0,998 <writetest+0xc6>
     8fe:	89aa                	mv	s3,a0
     900:	4901                	li	s2,0
    if (write(fd, "aaaaaaaaaa", SZ) != SZ) {
     902:	44a9                	li	s1,10
     904:	00005a17          	auipc	s4,0x5
     908:	524a0a13          	addi	s4,s4,1316 # 5e28 <malloc+0x470>
    if (write(fd, "bbbbbbbbbb", SZ) != SZ) {
     90c:	00005b17          	auipc	s6,0x5
     910:	554b0b13          	addi	s6,s6,1364 # 5e60 <malloc+0x4a8>
  for (i = 0; i < N; i++) {
     914:	06400a93          	li	s5,100
    if (write(fd, "aaaaaaaaaa", SZ) != SZ) {
     918:	8626                	mv	a2,s1
     91a:	85d2                	mv	a1,s4
     91c:	854e                	mv	a0,s3
     91e:	3a1040ef          	jal	54be <write>
     922:	08951563          	bne	a0,s1,9ac <writetest+0xda>
    if (write(fd, "bbbbbbbbbb", SZ) != SZ) {
     926:	8626                	mv	a2,s1
     928:	85da                	mv	a1,s6
     92a:	854e                	mv	a0,s3
     92c:	393040ef          	jal	54be <write>
     930:	08951963          	bne	a0,s1,9c2 <writetest+0xf0>
  for (i = 0; i < N; i++) {
     934:	2905                	addiw	s2,s2,1
     936:	ff5911e3          	bne	s2,s5,918 <writetest+0x46>
  close(fd);
     93a:	854e                	mv	a0,s3
     93c:	38b040ef          	jal	54c6 <close>
  fd = open("small", O_RDONLY);
     940:	4581                	li	a1,0
     942:	00005517          	auipc	a0,0x5
     946:	4be50513          	addi	a0,a0,1214 # 5e00 <malloc+0x448>
     94a:	395040ef          	jal	54de <open>
     94e:	84aa                	mv	s1,a0
  if (fd < 0) {
     950:	08054463          	bltz	a0,9d8 <writetest+0x106>
  i = read(fd, buf, N * SZ * 2);
     954:	7d000613          	li	a2,2000
     958:	0000c597          	auipc	a1,0xc
     95c:	39058593          	addi	a1,a1,912 # cce8 <buf>
     960:	357040ef          	jal	54b6 <read>
  if (i != N * SZ * 2) {
     964:	7d000793          	li	a5,2000
     968:	08f51263          	bne	a0,a5,9ec <writetest+0x11a>
  close(fd);
     96c:	8526                	mv	a0,s1
     96e:	359040ef          	jal	54c6 <close>
  if (unlink("small") < 0) {
     972:	00005517          	auipc	a0,0x5
     976:	48e50513          	addi	a0,a0,1166 # 5e00 <malloc+0x448>
     97a:	375040ef          	jal	54ee <unlink>
     97e:	08054163          	bltz	a0,a00 <writetest+0x12e>
}
     982:	60a6                	ld	ra,72(sp)
     984:	6406                	ld	s0,64(sp)
     986:	74e2                	ld	s1,56(sp)
     988:	7942                	ld	s2,48(sp)
     98a:	79a2                	ld	s3,40(sp)
     98c:	7a02                	ld	s4,32(sp)
     98e:	6ae2                	ld	s5,24(sp)
     990:	6b42                	ld	s6,16(sp)
     992:	6ba2                	ld	s7,8(sp)
     994:	6161                	addi	sp,sp,80
     996:	8082                	ret
    printf("%s: error: creat small failed!\n", s);
     998:	85de                	mv	a1,s7
     99a:	00005517          	auipc	a0,0x5
     99e:	46e50513          	addi	a0,a0,1134 # 5e08 <malloc+0x450>
     9a2:	75b040ef          	jal	58fc <printf>
    exit(1);
     9a6:	4505                	li	a0,1
     9a8:	2f7040ef          	jal	549e <exit>
      printf("%s: error: write aa %d new file failed\n", s, i);
     9ac:	864a                	mv	a2,s2
     9ae:	85de                	mv	a1,s7
     9b0:	00005517          	auipc	a0,0x5
     9b4:	48850513          	addi	a0,a0,1160 # 5e38 <malloc+0x480>
     9b8:	745040ef          	jal	58fc <printf>
      exit(1);
     9bc:	4505                	li	a0,1
     9be:	2e1040ef          	jal	549e <exit>
      printf("%s: error: write bb %d new file failed\n", s, i);
     9c2:	864a                	mv	a2,s2
     9c4:	85de                	mv	a1,s7
     9c6:	00005517          	auipc	a0,0x5
     9ca:	4aa50513          	addi	a0,a0,1194 # 5e70 <malloc+0x4b8>
     9ce:	72f040ef          	jal	58fc <printf>
      exit(1);
     9d2:	4505                	li	a0,1
     9d4:	2cb040ef          	jal	549e <exit>
    printf("%s: error: open small failed!\n", s);
     9d8:	85de                	mv	a1,s7
     9da:	00005517          	auipc	a0,0x5
     9de:	4be50513          	addi	a0,a0,1214 # 5e98 <malloc+0x4e0>
     9e2:	71b040ef          	jal	58fc <printf>
    exit(1);
     9e6:	4505                	li	a0,1
     9e8:	2b7040ef          	jal	549e <exit>
    printf("%s: read failed\n", s);
     9ec:	85de                	mv	a1,s7
     9ee:	00005517          	auipc	a0,0x5
     9f2:	4ca50513          	addi	a0,a0,1226 # 5eb8 <malloc+0x500>
     9f6:	707040ef          	jal	58fc <printf>
    exit(1);
     9fa:	4505                	li	a0,1
     9fc:	2a3040ef          	jal	549e <exit>
    printf("%s: unlink small failed\n", s);
     a00:	85de                	mv	a1,s7
     a02:	00005517          	auipc	a0,0x5
     a06:	4ce50513          	addi	a0,a0,1230 # 5ed0 <malloc+0x518>
     a0a:	6f3040ef          	jal	58fc <printf>
    exit(1);
     a0e:	4505                	li	a0,1
     a10:	28f040ef          	jal	549e <exit>

0000000000000a14 <writebig>:
{
     a14:	7139                	addi	sp,sp,-64
     a16:	fc06                	sd	ra,56(sp)
     a18:	f822                	sd	s0,48(sp)
     a1a:	f426                	sd	s1,40(sp)
     a1c:	f04a                	sd	s2,32(sp)
     a1e:	ec4e                	sd	s3,24(sp)
     a20:	e852                	sd	s4,16(sp)
     a22:	e456                	sd	s5,8(sp)
     a24:	e05a                	sd	s6,0(sp)
     a26:	0080                	addi	s0,sp,64
     a28:	8b2a                	mv	s6,a0
  fd = open("big", O_CREATE | O_RDWR);
     a2a:	20200593          	li	a1,514
     a2e:	00005517          	auipc	a0,0x5
     a32:	4c250513          	addi	a0,a0,1218 # 5ef0 <malloc+0x538>
     a36:	2a9040ef          	jal	54de <open>
  if (fd < 0) {
     a3a:	06054a63          	bltz	a0,aae <writebig+0x9a>
     a3e:	8a2a                	mv	s4,a0
     a40:	4481                	li	s1,0
    ((int *)buf)[0] = i;
     a42:	0000c997          	auipc	s3,0xc
     a46:	2a698993          	addi	s3,s3,678 # cce8 <buf>
    if (write(fd, buf, BSIZE) != BSIZE) {
     a4a:	40000913          	li	s2,1024
  for (i = 0; i < MAXFILE; i++) {
     a4e:	10c00a93          	li	s5,268
    ((int *)buf)[0] = i;
     a52:	0099a023          	sw	s1,0(s3)
    if (write(fd, buf, BSIZE) != BSIZE) {
     a56:	864a                	mv	a2,s2
     a58:	85ce                	mv	a1,s3
     a5a:	8552                	mv	a0,s4
     a5c:	263040ef          	jal	54be <write>
     a60:	07251163          	bne	a0,s2,ac2 <writebig+0xae>
  for (i = 0; i < MAXFILE; i++) {
     a64:	2485                	addiw	s1,s1,1
     a66:	ff5496e3          	bne	s1,s5,a52 <writebig+0x3e>
  close(fd);
     a6a:	8552                	mv	a0,s4
     a6c:	25b040ef          	jal	54c6 <close>
  fd = open("big", O_RDONLY);
     a70:	4581                	li	a1,0
     a72:	00005517          	auipc	a0,0x5
     a76:	47e50513          	addi	a0,a0,1150 # 5ef0 <malloc+0x538>
     a7a:	265040ef          	jal	54de <open>
     a7e:	8a2a                	mv	s4,a0
  n = 0;
     a80:	4481                	li	s1,0
    i = read(fd, buf, BSIZE);
     a82:	40000993          	li	s3,1024
     a86:	0000c917          	auipc	s2,0xc
     a8a:	26290913          	addi	s2,s2,610 # cce8 <buf>
  if (fd < 0) {
     a8e:	04054563          	bltz	a0,ad8 <writebig+0xc4>
    i = read(fd, buf, BSIZE);
     a92:	864e                	mv	a2,s3
     a94:	85ca                	mv	a1,s2
     a96:	8552                	mv	a0,s4
     a98:	21f040ef          	jal	54b6 <read>
    if (i == 0) {
     a9c:	c921                	beqz	a0,aec <writebig+0xd8>
    } else if (i != BSIZE) {
     a9e:	09351b63          	bne	a0,s3,b34 <writebig+0x120>
    if (((int *)buf)[0] != n) {
     aa2:	00092683          	lw	a3,0(s2)
     aa6:	0a969263          	bne	a3,s1,b4a <writebig+0x136>
    n++;
     aaa:	2485                	addiw	s1,s1,1
    i = read(fd, buf, BSIZE);
     aac:	b7dd                	j	a92 <writebig+0x7e>
    printf("%s: error: creat big failed!\n", s);
     aae:	85da                	mv	a1,s6
     ab0:	00005517          	auipc	a0,0x5
     ab4:	44850513          	addi	a0,a0,1096 # 5ef8 <malloc+0x540>
     ab8:	645040ef          	jal	58fc <printf>
    exit(1);
     abc:	4505                	li	a0,1
     abe:	1e1040ef          	jal	549e <exit>
      printf("%s: error: write big file failed i=%d\n", s, i);
     ac2:	8626                	mv	a2,s1
     ac4:	85da                	mv	a1,s6
     ac6:	00005517          	auipc	a0,0x5
     aca:	45250513          	addi	a0,a0,1106 # 5f18 <malloc+0x560>
     ace:	62f040ef          	jal	58fc <printf>
      exit(1);
     ad2:	4505                	li	a0,1
     ad4:	1cb040ef          	jal	549e <exit>
    printf("%s: error: open big failed!\n", s);
     ad8:	85da                	mv	a1,s6
     ada:	00005517          	auipc	a0,0x5
     ade:	46650513          	addi	a0,a0,1126 # 5f40 <malloc+0x588>
     ae2:	61b040ef          	jal	58fc <printf>
    exit(1);
     ae6:	4505                	li	a0,1
     ae8:	1b7040ef          	jal	549e <exit>
      if (n != MAXFILE) {
     aec:	10c00793          	li	a5,268
     af0:	02f49763          	bne	s1,a5,b1e <writebig+0x10a>
  close(fd);
     af4:	8552                	mv	a0,s4
     af6:	1d1040ef          	jal	54c6 <close>
  if (unlink("big") < 0) {
     afa:	00005517          	auipc	a0,0x5
     afe:	3f650513          	addi	a0,a0,1014 # 5ef0 <malloc+0x538>
     b02:	1ed040ef          	jal	54ee <unlink>
     b06:	04054d63          	bltz	a0,b60 <writebig+0x14c>
}
     b0a:	70e2                	ld	ra,56(sp)
     b0c:	7442                	ld	s0,48(sp)
     b0e:	74a2                	ld	s1,40(sp)
     b10:	7902                	ld	s2,32(sp)
     b12:	69e2                	ld	s3,24(sp)
     b14:	6a42                	ld	s4,16(sp)
     b16:	6aa2                	ld	s5,8(sp)
     b18:	6b02                	ld	s6,0(sp)
     b1a:	6121                	addi	sp,sp,64
     b1c:	8082                	ret
        printf("%s: read only %d blocks from big", s, n);
     b1e:	8626                	mv	a2,s1
     b20:	85da                	mv	a1,s6
     b22:	00005517          	auipc	a0,0x5
     b26:	43e50513          	addi	a0,a0,1086 # 5f60 <malloc+0x5a8>
     b2a:	5d3040ef          	jal	58fc <printf>
        exit(1);
     b2e:	4505                	li	a0,1
     b30:	16f040ef          	jal	549e <exit>
      printf("%s: read failed %d\n", s, i);
     b34:	862a                	mv	a2,a0
     b36:	85da                	mv	a1,s6
     b38:	00005517          	auipc	a0,0x5
     b3c:	45050513          	addi	a0,a0,1104 # 5f88 <malloc+0x5d0>
     b40:	5bd040ef          	jal	58fc <printf>
      exit(1);
     b44:	4505                	li	a0,1
     b46:	159040ef          	jal	549e <exit>
      printf("%s: read content of block %d is %d\n", s, n, ((int *)buf)[0]);
     b4a:	8626                	mv	a2,s1
     b4c:	85da                	mv	a1,s6
     b4e:	00005517          	auipc	a0,0x5
     b52:	45250513          	addi	a0,a0,1106 # 5fa0 <malloc+0x5e8>
     b56:	5a7040ef          	jal	58fc <printf>
      exit(1);
     b5a:	4505                	li	a0,1
     b5c:	143040ef          	jal	549e <exit>
    printf("%s: unlink big failed\n", s);
     b60:	85da                	mv	a1,s6
     b62:	00005517          	auipc	a0,0x5
     b66:	46650513          	addi	a0,a0,1126 # 5fc8 <malloc+0x610>
     b6a:	593040ef          	jal	58fc <printf>
    exit(1);
     b6e:	4505                	li	a0,1
     b70:	12f040ef          	jal	549e <exit>

0000000000000b74 <unlinkread>:
{
     b74:	7179                	addi	sp,sp,-48
     b76:	f406                	sd	ra,40(sp)
     b78:	f022                	sd	s0,32(sp)
     b7a:	ec26                	sd	s1,24(sp)
     b7c:	e84a                	sd	s2,16(sp)
     b7e:	e44e                	sd	s3,8(sp)
     b80:	1800                	addi	s0,sp,48
     b82:	89aa                	mv	s3,a0
  fd = open("unlinkread", O_CREATE | O_RDWR);
     b84:	20200593          	li	a1,514
     b88:	00005517          	auipc	a0,0x5
     b8c:	45850513          	addi	a0,a0,1112 # 5fe0 <malloc+0x628>
     b90:	14f040ef          	jal	54de <open>
  if (fd < 0) {
     b94:	0a054f63          	bltz	a0,c52 <unlinkread+0xde>
     b98:	84aa                	mv	s1,a0
  write(fd, "hello", SZ);
     b9a:	4615                	li	a2,5
     b9c:	00005597          	auipc	a1,0x5
     ba0:	47458593          	addi	a1,a1,1140 # 6010 <malloc+0x658>
     ba4:	11b040ef          	jal	54be <write>
  close(fd);
     ba8:	8526                	mv	a0,s1
     baa:	11d040ef          	jal	54c6 <close>
  fd = open("unlinkread", O_RDWR);
     bae:	4589                	li	a1,2
     bb0:	00005517          	auipc	a0,0x5
     bb4:	43050513          	addi	a0,a0,1072 # 5fe0 <malloc+0x628>
     bb8:	127040ef          	jal	54de <open>
     bbc:	84aa                	mv	s1,a0
  if (fd < 0) {
     bbe:	0a054463          	bltz	a0,c66 <unlinkread+0xf2>
  if (unlink("unlinkread") != 0) {
     bc2:	00005517          	auipc	a0,0x5
     bc6:	41e50513          	addi	a0,a0,1054 # 5fe0 <malloc+0x628>
     bca:	125040ef          	jal	54ee <unlink>
     bce:	e555                	bnez	a0,c7a <unlinkread+0x106>
  fd1 = open("unlinkread", O_CREATE | O_RDWR);
     bd0:	20200593          	li	a1,514
     bd4:	00005517          	auipc	a0,0x5
     bd8:	40c50513          	addi	a0,a0,1036 # 5fe0 <malloc+0x628>
     bdc:	103040ef          	jal	54de <open>
     be0:	892a                	mv	s2,a0
  write(fd1, "yyy", 3);
     be2:	460d                	li	a2,3
     be4:	00005597          	auipc	a1,0x5
     be8:	47458593          	addi	a1,a1,1140 # 6058 <malloc+0x6a0>
     bec:	0d3040ef          	jal	54be <write>
  close(fd1);
     bf0:	854a                	mv	a0,s2
     bf2:	0d5040ef          	jal	54c6 <close>
  if (read(fd, buf, sizeof(buf)) != SZ) {
     bf6:	660d                	lui	a2,0x3
     bf8:	0000c597          	auipc	a1,0xc
     bfc:	0f058593          	addi	a1,a1,240 # cce8 <buf>
     c00:	8526                	mv	a0,s1
     c02:	0b5040ef          	jal	54b6 <read>
     c06:	4795                	li	a5,5
     c08:	08f51363          	bne	a0,a5,c8e <unlinkread+0x11a>
  if (buf[0] != 'h') {
     c0c:	0000c717          	auipc	a4,0xc
     c10:	0dc74703          	lbu	a4,220(a4) # cce8 <buf>
     c14:	06800793          	li	a5,104
     c18:	08f71563          	bne	a4,a5,ca2 <unlinkread+0x12e>
  if (write(fd, buf, 10) != 10) {
     c1c:	4629                	li	a2,10
     c1e:	0000c597          	auipc	a1,0xc
     c22:	0ca58593          	addi	a1,a1,202 # cce8 <buf>
     c26:	8526                	mv	a0,s1
     c28:	097040ef          	jal	54be <write>
     c2c:	47a9                	li	a5,10
     c2e:	08f51463          	bne	a0,a5,cb6 <unlinkread+0x142>
  close(fd);
     c32:	8526                	mv	a0,s1
     c34:	093040ef          	jal	54c6 <close>
  unlink("unlinkread");
     c38:	00005517          	auipc	a0,0x5
     c3c:	3a850513          	addi	a0,a0,936 # 5fe0 <malloc+0x628>
     c40:	0af040ef          	jal	54ee <unlink>
}
     c44:	70a2                	ld	ra,40(sp)
     c46:	7402                	ld	s0,32(sp)
     c48:	64e2                	ld	s1,24(sp)
     c4a:	6942                	ld	s2,16(sp)
     c4c:	69a2                	ld	s3,8(sp)
     c4e:	6145                	addi	sp,sp,48
     c50:	8082                	ret
    printf("%s: create unlinkread failed\n", s);
     c52:	85ce                	mv	a1,s3
     c54:	00005517          	auipc	a0,0x5
     c58:	39c50513          	addi	a0,a0,924 # 5ff0 <malloc+0x638>
     c5c:	4a1040ef          	jal	58fc <printf>
    exit(1);
     c60:	4505                	li	a0,1
     c62:	03d040ef          	jal	549e <exit>
    printf("%s: open unlinkread failed\n", s);
     c66:	85ce                	mv	a1,s3
     c68:	00005517          	auipc	a0,0x5
     c6c:	3b050513          	addi	a0,a0,944 # 6018 <malloc+0x660>
     c70:	48d040ef          	jal	58fc <printf>
    exit(1);
     c74:	4505                	li	a0,1
     c76:	029040ef          	jal	549e <exit>
    printf("%s: unlink unlinkread failed\n", s);
     c7a:	85ce                	mv	a1,s3
     c7c:	00005517          	auipc	a0,0x5
     c80:	3bc50513          	addi	a0,a0,956 # 6038 <malloc+0x680>
     c84:	479040ef          	jal	58fc <printf>
    exit(1);
     c88:	4505                	li	a0,1
     c8a:	015040ef          	jal	549e <exit>
    printf("%s: unlinkread read failed", s);
     c8e:	85ce                	mv	a1,s3
     c90:	00005517          	auipc	a0,0x5
     c94:	3d050513          	addi	a0,a0,976 # 6060 <malloc+0x6a8>
     c98:	465040ef          	jal	58fc <printf>
    exit(1);
     c9c:	4505                	li	a0,1
     c9e:	001040ef          	jal	549e <exit>
    printf("%s: unlinkread wrong data\n", s);
     ca2:	85ce                	mv	a1,s3
     ca4:	00005517          	auipc	a0,0x5
     ca8:	3dc50513          	addi	a0,a0,988 # 6080 <malloc+0x6c8>
     cac:	451040ef          	jal	58fc <printf>
    exit(1);
     cb0:	4505                	li	a0,1
     cb2:	7ec040ef          	jal	549e <exit>
    printf("%s: unlinkread write failed\n", s);
     cb6:	85ce                	mv	a1,s3
     cb8:	00005517          	auipc	a0,0x5
     cbc:	3e850513          	addi	a0,a0,1000 # 60a0 <malloc+0x6e8>
     cc0:	43d040ef          	jal	58fc <printf>
    exit(1);
     cc4:	4505                	li	a0,1
     cc6:	7d8040ef          	jal	549e <exit>

0000000000000cca <linktest>:
{
     cca:	1101                	addi	sp,sp,-32
     ccc:	ec06                	sd	ra,24(sp)
     cce:	e822                	sd	s0,16(sp)
     cd0:	e426                	sd	s1,8(sp)
     cd2:	e04a                	sd	s2,0(sp)
     cd4:	1000                	addi	s0,sp,32
     cd6:	892a                	mv	s2,a0
  unlink("lf1");
     cd8:	00005517          	auipc	a0,0x5
     cdc:	3e850513          	addi	a0,a0,1000 # 60c0 <malloc+0x708>
     ce0:	00f040ef          	jal	54ee <unlink>
  unlink("lf2");
     ce4:	00005517          	auipc	a0,0x5
     ce8:	3e450513          	addi	a0,a0,996 # 60c8 <malloc+0x710>
     cec:	003040ef          	jal	54ee <unlink>
  fd = open("lf1", O_CREATE | O_RDWR);
     cf0:	20200593          	li	a1,514
     cf4:	00005517          	auipc	a0,0x5
     cf8:	3cc50513          	addi	a0,a0,972 # 60c0 <malloc+0x708>
     cfc:	7e2040ef          	jal	54de <open>
  if (fd < 0) {
     d00:	0c054f63          	bltz	a0,dde <linktest+0x114>
     d04:	84aa                	mv	s1,a0
  if (write(fd, "hello", SZ) != SZ) {
     d06:	4615                	li	a2,5
     d08:	00005597          	auipc	a1,0x5
     d0c:	30858593          	addi	a1,a1,776 # 6010 <malloc+0x658>
     d10:	7ae040ef          	jal	54be <write>
     d14:	4795                	li	a5,5
     d16:	0cf51e63          	bne	a0,a5,df2 <linktest+0x128>
  close(fd);
     d1a:	8526                	mv	a0,s1
     d1c:	7aa040ef          	jal	54c6 <close>
  if (link("lf1", "lf2") < 0) {
     d20:	00005597          	auipc	a1,0x5
     d24:	3a858593          	addi	a1,a1,936 # 60c8 <malloc+0x710>
     d28:	00005517          	auipc	a0,0x5
     d2c:	39850513          	addi	a0,a0,920 # 60c0 <malloc+0x708>
     d30:	7ce040ef          	jal	54fe <link>
     d34:	0c054963          	bltz	a0,e06 <linktest+0x13c>
  unlink("lf1");
     d38:	00005517          	auipc	a0,0x5
     d3c:	38850513          	addi	a0,a0,904 # 60c0 <malloc+0x708>
     d40:	7ae040ef          	jal	54ee <unlink>
  if (open("lf1", 0) >= 0) {
     d44:	4581                	li	a1,0
     d46:	00005517          	auipc	a0,0x5
     d4a:	37a50513          	addi	a0,a0,890 # 60c0 <malloc+0x708>
     d4e:	790040ef          	jal	54de <open>
     d52:	0c055463          	bgez	a0,e1a <linktest+0x150>
  fd = open("lf2", 0);
     d56:	4581                	li	a1,0
     d58:	00005517          	auipc	a0,0x5
     d5c:	37050513          	addi	a0,a0,880 # 60c8 <malloc+0x710>
     d60:	77e040ef          	jal	54de <open>
     d64:	84aa                	mv	s1,a0
  if (fd < 0) {
     d66:	0c054463          	bltz	a0,e2e <linktest+0x164>
  if (read(fd, buf, sizeof(buf)) != SZ) {
     d6a:	660d                	lui	a2,0x3
     d6c:	0000c597          	auipc	a1,0xc
     d70:	f7c58593          	addi	a1,a1,-132 # cce8 <buf>
     d74:	742040ef          	jal	54b6 <read>
     d78:	4795                	li	a5,5
     d7a:	0cf51463          	bne	a0,a5,e42 <linktest+0x178>
  close(fd);
     d7e:	8526                	mv	a0,s1
     d80:	746040ef          	jal	54c6 <close>
  if (link("lf2", "lf2") >= 0) {
     d84:	00005597          	auipc	a1,0x5
     d88:	34458593          	addi	a1,a1,836 # 60c8 <malloc+0x710>
     d8c:	852e                	mv	a0,a1
     d8e:	770040ef          	jal	54fe <link>
     d92:	0c055263          	bgez	a0,e56 <linktest+0x18c>
  unlink("lf2");
     d96:	00005517          	auipc	a0,0x5
     d9a:	33250513          	addi	a0,a0,818 # 60c8 <malloc+0x710>
     d9e:	750040ef          	jal	54ee <unlink>
  if (link("lf2", "lf1") >= 0) {
     da2:	00005597          	auipc	a1,0x5
     da6:	31e58593          	addi	a1,a1,798 # 60c0 <malloc+0x708>
     daa:	00005517          	auipc	a0,0x5
     dae:	31e50513          	addi	a0,a0,798 # 60c8 <malloc+0x710>
     db2:	74c040ef          	jal	54fe <link>
     db6:	0a055a63          	bgez	a0,e6a <linktest+0x1a0>
  if (link(".", "lf1") >= 0) {
     dba:	00005597          	auipc	a1,0x5
     dbe:	30658593          	addi	a1,a1,774 # 60c0 <malloc+0x708>
     dc2:	00005517          	auipc	a0,0x5
     dc6:	40e50513          	addi	a0,a0,1038 # 61d0 <malloc+0x818>
     dca:	734040ef          	jal	54fe <link>
     dce:	0a055863          	bgez	a0,e7e <linktest+0x1b4>
}
     dd2:	60e2                	ld	ra,24(sp)
     dd4:	6442                	ld	s0,16(sp)
     dd6:	64a2                	ld	s1,8(sp)
     dd8:	6902                	ld	s2,0(sp)
     dda:	6105                	addi	sp,sp,32
     ddc:	8082                	ret
    printf("%s: create lf1 failed\n", s);
     dde:	85ca                	mv	a1,s2
     de0:	00005517          	auipc	a0,0x5
     de4:	2f050513          	addi	a0,a0,752 # 60d0 <malloc+0x718>
     de8:	315040ef          	jal	58fc <printf>
    exit(1);
     dec:	4505                	li	a0,1
     dee:	6b0040ef          	jal	549e <exit>
    printf("%s: write lf1 failed\n", s);
     df2:	85ca                	mv	a1,s2
     df4:	00005517          	auipc	a0,0x5
     df8:	2f450513          	addi	a0,a0,756 # 60e8 <malloc+0x730>
     dfc:	301040ef          	jal	58fc <printf>
    exit(1);
     e00:	4505                	li	a0,1
     e02:	69c040ef          	jal	549e <exit>
    printf("%s: link lf1 lf2 failed\n", s);
     e06:	85ca                	mv	a1,s2
     e08:	00005517          	auipc	a0,0x5
     e0c:	2f850513          	addi	a0,a0,760 # 6100 <malloc+0x748>
     e10:	2ed040ef          	jal	58fc <printf>
    exit(1);
     e14:	4505                	li	a0,1
     e16:	688040ef          	jal	549e <exit>
    printf("%s: unlinked lf1 but it is still there!\n", s);
     e1a:	85ca                	mv	a1,s2
     e1c:	00005517          	auipc	a0,0x5
     e20:	30450513          	addi	a0,a0,772 # 6120 <malloc+0x768>
     e24:	2d9040ef          	jal	58fc <printf>
    exit(1);
     e28:	4505                	li	a0,1
     e2a:	674040ef          	jal	549e <exit>
    printf("%s: open lf2 failed\n", s);
     e2e:	85ca                	mv	a1,s2
     e30:	00005517          	auipc	a0,0x5
     e34:	32050513          	addi	a0,a0,800 # 6150 <malloc+0x798>
     e38:	2c5040ef          	jal	58fc <printf>
    exit(1);
     e3c:	4505                	li	a0,1
     e3e:	660040ef          	jal	549e <exit>
    printf("%s: read lf2 failed\n", s);
     e42:	85ca                	mv	a1,s2
     e44:	00005517          	auipc	a0,0x5
     e48:	32450513          	addi	a0,a0,804 # 6168 <malloc+0x7b0>
     e4c:	2b1040ef          	jal	58fc <printf>
    exit(1);
     e50:	4505                	li	a0,1
     e52:	64c040ef          	jal	549e <exit>
    printf("%s: link lf2 lf2 succeeded! oops\n", s);
     e56:	85ca                	mv	a1,s2
     e58:	00005517          	auipc	a0,0x5
     e5c:	32850513          	addi	a0,a0,808 # 6180 <malloc+0x7c8>
     e60:	29d040ef          	jal	58fc <printf>
    exit(1);
     e64:	4505                	li	a0,1
     e66:	638040ef          	jal	549e <exit>
    printf("%s: link non-existent succeeded! oops\n", s);
     e6a:	85ca                	mv	a1,s2
     e6c:	00005517          	auipc	a0,0x5
     e70:	33c50513          	addi	a0,a0,828 # 61a8 <malloc+0x7f0>
     e74:	289040ef          	jal	58fc <printf>
    exit(1);
     e78:	4505                	li	a0,1
     e7a:	624040ef          	jal	549e <exit>
    printf("%s: link . lf1 succeeded! oops\n", s);
     e7e:	85ca                	mv	a1,s2
     e80:	00005517          	auipc	a0,0x5
     e84:	35850513          	addi	a0,a0,856 # 61d8 <malloc+0x820>
     e88:	275040ef          	jal	58fc <printf>
    exit(1);
     e8c:	4505                	li	a0,1
     e8e:	610040ef          	jal	549e <exit>

0000000000000e92 <validatetest>:
{
     e92:	7139                	addi	sp,sp,-64
     e94:	fc06                	sd	ra,56(sp)
     e96:	f822                	sd	s0,48(sp)
     e98:	f426                	sd	s1,40(sp)
     e9a:	f04a                	sd	s2,32(sp)
     e9c:	ec4e                	sd	s3,24(sp)
     e9e:	e852                	sd	s4,16(sp)
     ea0:	e456                	sd	s5,8(sp)
     ea2:	e05a                	sd	s6,0(sp)
     ea4:	0080                	addi	s0,sp,64
     ea6:	8b2a                	mv	s6,a0
  for (p = 0; p <= (uint)hi; p += PGSIZE) {
     ea8:	4481                	li	s1,0
    if (link("nosuchfile", (char *)p) != -1) {
     eaa:	00005997          	auipc	s3,0x5
     eae:	34e98993          	addi	s3,s3,846 # 61f8 <malloc+0x840>
     eb2:	597d                	li	s2,-1
  for (p = 0; p <= (uint)hi; p += PGSIZE) {
     eb4:	6a85                	lui	s5,0x1
     eb6:	00114a37          	lui	s4,0x114
    if (link("nosuchfile", (char *)p) != -1) {
     eba:	85a6                	mv	a1,s1
     ebc:	854e                	mv	a0,s3
     ebe:	640040ef          	jal	54fe <link>
     ec2:	01251f63          	bne	a0,s2,ee0 <validatetest+0x4e>
  for (p = 0; p <= (uint)hi; p += PGSIZE) {
     ec6:	94d6                	add	s1,s1,s5
     ec8:	ff4499e3          	bne	s1,s4,eba <validatetest+0x28>
}
     ecc:	70e2                	ld	ra,56(sp)
     ece:	7442                	ld	s0,48(sp)
     ed0:	74a2                	ld	s1,40(sp)
     ed2:	7902                	ld	s2,32(sp)
     ed4:	69e2                	ld	s3,24(sp)
     ed6:	6a42                	ld	s4,16(sp)
     ed8:	6aa2                	ld	s5,8(sp)
     eda:	6b02                	ld	s6,0(sp)
     edc:	6121                	addi	sp,sp,64
     ede:	8082                	ret
      printf("%s: link should not succeed\n", s);
     ee0:	85da                	mv	a1,s6
     ee2:	00005517          	auipc	a0,0x5
     ee6:	32650513          	addi	a0,a0,806 # 6208 <malloc+0x850>
     eea:	213040ef          	jal	58fc <printf>
      exit(1);
     eee:	4505                	li	a0,1
     ef0:	5ae040ef          	jal	549e <exit>

0000000000000ef4 <bigdir>:
{
     ef4:	711d                	addi	sp,sp,-96
     ef6:	ec86                	sd	ra,88(sp)
     ef8:	e8a2                	sd	s0,80(sp)
     efa:	e4a6                	sd	s1,72(sp)
     efc:	e0ca                	sd	s2,64(sp)
     efe:	fc4e                	sd	s3,56(sp)
     f00:	f852                	sd	s4,48(sp)
     f02:	f456                	sd	s5,40(sp)
     f04:	f05a                	sd	s6,32(sp)
     f06:	ec5e                	sd	s7,24(sp)
     f08:	1080                	addi	s0,sp,96
     f0a:	8baa                	mv	s7,a0
  unlink("bd");
     f0c:	00005517          	auipc	a0,0x5
     f10:	31c50513          	addi	a0,a0,796 # 6228 <malloc+0x870>
     f14:	5da040ef          	jal	54ee <unlink>
  fd = open("bd", O_CREATE);
     f18:	20000593          	li	a1,512
     f1c:	00005517          	auipc	a0,0x5
     f20:	30c50513          	addi	a0,a0,780 # 6228 <malloc+0x870>
     f24:	5ba040ef          	jal	54de <open>
  if (fd < 0) {
     f28:	0c054463          	bltz	a0,ff0 <bigdir+0xfc>
  close(fd);
     f2c:	59a040ef          	jal	54c6 <close>
  for (i = 0; i < N; i++) {
     f30:	4901                	li	s2,0
    name[0] = 'x';
     f32:	07800a93          	li	s5,120
    if (link("bd", name) != 0) {
     f36:	fa040a13          	addi	s4,s0,-96
     f3a:	00005997          	auipc	s3,0x5
     f3e:	2ee98993          	addi	s3,s3,750 # 6228 <malloc+0x870>
  for (i = 0; i < N; i++) {
     f42:	1f400b13          	li	s6,500
    name[0] = 'x';
     f46:	fb540023          	sb	s5,-96(s0)
    name[1] = '0' + (i / 64);
     f4a:	41f9571b          	sraiw	a4,s2,0x1f
     f4e:	01a7571b          	srliw	a4,a4,0x1a
     f52:	012707bb          	addw	a5,a4,s2
     f56:	4067d69b          	sraiw	a3,a5,0x6
     f5a:	0306869b          	addiw	a3,a3,48
     f5e:	fad400a3          	sb	a3,-95(s0)
    name[2] = '0' + (i % 64);
     f62:	03f7f793          	andi	a5,a5,63
     f66:	9f99                	subw	a5,a5,a4
     f68:	0307879b          	addiw	a5,a5,48
     f6c:	faf40123          	sb	a5,-94(s0)
    name[3] = '\0';
     f70:	fa0401a3          	sb	zero,-93(s0)
    if (link("bd", name) != 0) {
     f74:	85d2                	mv	a1,s4
     f76:	854e                	mv	a0,s3
     f78:	586040ef          	jal	54fe <link>
     f7c:	84aa                	mv	s1,a0
     f7e:	e159                	bnez	a0,1004 <bigdir+0x110>
  for (i = 0; i < N; i++) {
     f80:	2905                	addiw	s2,s2,1
     f82:	fd6912e3          	bne	s2,s6,f46 <bigdir+0x52>
  unlink("bd");
     f86:	00005517          	auipc	a0,0x5
     f8a:	2a250513          	addi	a0,a0,674 # 6228 <malloc+0x870>
     f8e:	560040ef          	jal	54ee <unlink>
    name[0] = 'x';
     f92:	07800993          	li	s3,120
    if (unlink(name) != 0) {
     f96:	fa040913          	addi	s2,s0,-96
  for (i = 0; i < N; i++) {
     f9a:	1f400a13          	li	s4,500
    name[0] = 'x';
     f9e:	fb340023          	sb	s3,-96(s0)
    name[1] = '0' + (i / 64);
     fa2:	41f4d71b          	sraiw	a4,s1,0x1f
     fa6:	01a7571b          	srliw	a4,a4,0x1a
     faa:	009707bb          	addw	a5,a4,s1
     fae:	4067d69b          	sraiw	a3,a5,0x6
     fb2:	0306869b          	addiw	a3,a3,48
     fb6:	fad400a3          	sb	a3,-95(s0)
    name[2] = '0' + (i % 64);
     fba:	03f7f793          	andi	a5,a5,63
     fbe:	9f99                	subw	a5,a5,a4
     fc0:	0307879b          	addiw	a5,a5,48
     fc4:	faf40123          	sb	a5,-94(s0)
    name[3] = '\0';
     fc8:	fa0401a3          	sb	zero,-93(s0)
    if (unlink(name) != 0) {
     fcc:	854a                	mv	a0,s2
     fce:	520040ef          	jal	54ee <unlink>
     fd2:	e531                	bnez	a0,101e <bigdir+0x12a>
  for (i = 0; i < N; i++) {
     fd4:	2485                	addiw	s1,s1,1
     fd6:	fd4494e3          	bne	s1,s4,f9e <bigdir+0xaa>
}
     fda:	60e6                	ld	ra,88(sp)
     fdc:	6446                	ld	s0,80(sp)
     fde:	64a6                	ld	s1,72(sp)
     fe0:	6906                	ld	s2,64(sp)
     fe2:	79e2                	ld	s3,56(sp)
     fe4:	7a42                	ld	s4,48(sp)
     fe6:	7aa2                	ld	s5,40(sp)
     fe8:	7b02                	ld	s6,32(sp)
     fea:	6be2                	ld	s7,24(sp)
     fec:	6125                	addi	sp,sp,96
     fee:	8082                	ret
    printf("%s: bigdir create failed\n", s);
     ff0:	85de                	mv	a1,s7
     ff2:	00005517          	auipc	a0,0x5
     ff6:	23e50513          	addi	a0,a0,574 # 6230 <malloc+0x878>
     ffa:	103040ef          	jal	58fc <printf>
    exit(1);
     ffe:	4505                	li	a0,1
    1000:	49e040ef          	jal	549e <exit>
      printf("%s: bigdir i=%d link(bd, %s) failed\n", s, i, name);
    1004:	fa040693          	addi	a3,s0,-96
    1008:	864a                	mv	a2,s2
    100a:	85de                	mv	a1,s7
    100c:	00005517          	auipc	a0,0x5
    1010:	24450513          	addi	a0,a0,580 # 6250 <malloc+0x898>
    1014:	0e9040ef          	jal	58fc <printf>
      exit(1);
    1018:	4505                	li	a0,1
    101a:	484040ef          	jal	549e <exit>
      printf("%s: bigdir unlink failed", s);
    101e:	85de                	mv	a1,s7
    1020:	00005517          	auipc	a0,0x5
    1024:	25850513          	addi	a0,a0,600 # 6278 <malloc+0x8c0>
    1028:	0d5040ef          	jal	58fc <printf>
      exit(1);
    102c:	4505                	li	a0,1
    102e:	470040ef          	jal	549e <exit>

0000000000001032 <pgbug>:
{
    1032:	7179                	addi	sp,sp,-48
    1034:	f406                	sd	ra,40(sp)
    1036:	f022                	sd	s0,32(sp)
    1038:	ec26                	sd	s1,24(sp)
    103a:	1800                	addi	s0,sp,48
  argv[0] = 0;
    103c:	fc043c23          	sd	zero,-40(s0)
  exec(big, argv);
    1040:	00008497          	auipc	s1,0x8
    1044:	fc048493          	addi	s1,s1,-64 # 9000 <big>
    1048:	fd840593          	addi	a1,s0,-40
    104c:	6088                	ld	a0,0(s1)
    104e:	488040ef          	jal	54d6 <exec>
  pipe(big);
    1052:	6088                	ld	a0,0(s1)
    1054:	45a040ef          	jal	54ae <pipe>
  exit(0);
    1058:	4501                	li	a0,0
    105a:	444040ef          	jal	549e <exit>

000000000000105e <badarg>:
{
    105e:	7139                	addi	sp,sp,-64
    1060:	fc06                	sd	ra,56(sp)
    1062:	f822                	sd	s0,48(sp)
    1064:	f426                	sd	s1,40(sp)
    1066:	f04a                	sd	s2,32(sp)
    1068:	ec4e                	sd	s3,24(sp)
    106a:	e852                	sd	s4,16(sp)
    106c:	0080                	addi	s0,sp,64
    106e:	64b1                	lui	s1,0xc
    1070:	35048493          	addi	s1,s1,848 # c350 <uninit+0x1d78>
    argv[0] = (char *)0xffffffff;
    1074:	597d                	li	s2,-1
    1076:	02095913          	srli	s2,s2,0x20
    exec("echo", argv);
    107a:	fc040a13          	addi	s4,s0,-64
    107e:	00005997          	auipc	s3,0x5
    1082:	a6a98993          	addi	s3,s3,-1430 # 5ae8 <malloc+0x130>
    argv[0] = (char *)0xffffffff;
    1086:	fd243023          	sd	s2,-64(s0)
    argv[1] = 0;
    108a:	fc043423          	sd	zero,-56(s0)
    exec("echo", argv);
    108e:	85d2                	mv	a1,s4
    1090:	854e                	mv	a0,s3
    1092:	444040ef          	jal	54d6 <exec>
  for (int i = 0; i < 50000; i++) {
    1096:	34fd                	addiw	s1,s1,-1
    1098:	f4fd                	bnez	s1,1086 <badarg+0x28>
  exit(0);
    109a:	4501                	li	a0,0
    109c:	402040ef          	jal	549e <exit>

00000000000010a0 <copyinstr2>:
{
    10a0:	7155                	addi	sp,sp,-208
    10a2:	e586                	sd	ra,200(sp)
    10a4:	e1a2                	sd	s0,192(sp)
    10a6:	0980                	addi	s0,sp,208
  for (int i = 0; i < MAXPATH; i++)
    10a8:	f6840793          	addi	a5,s0,-152
    10ac:	fe840693          	addi	a3,s0,-24
    b[i] = 'x';
    10b0:	07800713          	li	a4,120
    10b4:	00e78023          	sb	a4,0(a5)
  for (int i = 0; i < MAXPATH; i++)
    10b8:	0785                	addi	a5,a5,1
    10ba:	fed79de3          	bne	a5,a3,10b4 <copyinstr2+0x14>
  b[MAXPATH] = '\0';
    10be:	fe040423          	sb	zero,-24(s0)
  int ret = unlink(b);
    10c2:	f6840513          	addi	a0,s0,-152
    10c6:	428040ef          	jal	54ee <unlink>
  if (ret != -1) {
    10ca:	57fd                	li	a5,-1
    10cc:	0cf51263          	bne	a0,a5,1190 <copyinstr2+0xf0>
  int fd = open(b, O_CREATE | O_WRONLY);
    10d0:	20100593          	li	a1,513
    10d4:	f6840513          	addi	a0,s0,-152
    10d8:	406040ef          	jal	54de <open>
  if (fd != -1) {
    10dc:	57fd                	li	a5,-1
    10de:	0cf51563          	bne	a0,a5,11a8 <copyinstr2+0x108>
  ret = link(b, b);
    10e2:	f6840513          	addi	a0,s0,-152
    10e6:	85aa                	mv	a1,a0
    10e8:	416040ef          	jal	54fe <link>
  if (ret != -1) {
    10ec:	57fd                	li	a5,-1
    10ee:	0cf51963          	bne	a0,a5,11c0 <copyinstr2+0x120>
  char *args[] = {"xx", 0};
    10f2:	00006797          	auipc	a5,0x6
    10f6:	26e78793          	addi	a5,a5,622 # 7360 <malloc+0x19a8>
    10fa:	f4f43c23          	sd	a5,-168(s0)
    10fe:	f6043023          	sd	zero,-160(s0)
  ret = exec(b, args);
    1102:	f5840593          	addi	a1,s0,-168
    1106:	f6840513          	addi	a0,s0,-152
    110a:	3cc040ef          	jal	54d6 <exec>
  if (ret != -1) {
    110e:	57fd                	li	a5,-1
    1110:	0cf51563          	bne	a0,a5,11da <copyinstr2+0x13a>
  int pid = fork();
    1114:	382040ef          	jal	5496 <fork>
  if (pid < 0) {
    1118:	0c054d63          	bltz	a0,11f2 <copyinstr2+0x152>
  if (pid == 0) {
    111c:	0e051863          	bnez	a0,120c <copyinstr2+0x16c>
    1120:	00008797          	auipc	a5,0x8
    1124:	4b078793          	addi	a5,a5,1200 # 95d0 <big.0>
    1128:	00009697          	auipc	a3,0x9
    112c:	4a868693          	addi	a3,a3,1192 # a5d0 <big.0+0x1000>
      big[i] = 'x';
    1130:	07800713          	li	a4,120
    1134:	00e78023          	sb	a4,0(a5)
    for (int i = 0; i < PGSIZE; i++)
    1138:	0785                	addi	a5,a5,1
    113a:	fed79de3          	bne	a5,a3,1134 <copyinstr2+0x94>
    big[PGSIZE] = '\0';
    113e:	00009797          	auipc	a5,0x9
    1142:	48078923          	sb	zero,1170(a5) # a5d0 <big.0+0x1000>
    char *args2[] = {big, big, big, 0};
    1146:	00007797          	auipc	a5,0x7
    114a:	1a278793          	addi	a5,a5,418 # 82e8 <malloc+0x2930>
    114e:	6fb0                	ld	a2,88(a5)
    1150:	73b4                	ld	a3,96(a5)
    1152:	77b8                	ld	a4,104(a5)
    1154:	f2c43823          	sd	a2,-208(s0)
    1158:	f2d43c23          	sd	a3,-200(s0)
    115c:	f4e43023          	sd	a4,-192(s0)
    1160:	7bbc                	ld	a5,112(a5)
    1162:	f4f43423          	sd	a5,-184(s0)
    ret = exec("echo", args2);
    1166:	f3040593          	addi	a1,s0,-208
    116a:	00005517          	auipc	a0,0x5
    116e:	97e50513          	addi	a0,a0,-1666 # 5ae8 <malloc+0x130>
    1172:	364040ef          	jal	54d6 <exec>
    if (ret != -1) {
    1176:	57fd                	li	a5,-1
    1178:	08f50663          	beq	a0,a5,1204 <copyinstr2+0x164>
      printf("exec(echo, BIG) returned %d, not -1\n", fd);
    117c:	85be                	mv	a1,a5
    117e:	00005517          	auipc	a0,0x5
    1182:	1a250513          	addi	a0,a0,418 # 6320 <malloc+0x968>
    1186:	776040ef          	jal	58fc <printf>
      exit(1);
    118a:	4505                	li	a0,1
    118c:	312040ef          	jal	549e <exit>
    printf("unlink(%s) returned %d, not -1\n", b, ret);
    1190:	862a                	mv	a2,a0
    1192:	f6840593          	addi	a1,s0,-152
    1196:	00005517          	auipc	a0,0x5
    119a:	10250513          	addi	a0,a0,258 # 6298 <malloc+0x8e0>
    119e:	75e040ef          	jal	58fc <printf>
    exit(1);
    11a2:	4505                	li	a0,1
    11a4:	2fa040ef          	jal	549e <exit>
    printf("open(%s) returned %d, not -1\n", b, fd);
    11a8:	862a                	mv	a2,a0
    11aa:	f6840593          	addi	a1,s0,-152
    11ae:	00005517          	auipc	a0,0x5
    11b2:	10a50513          	addi	a0,a0,266 # 62b8 <malloc+0x900>
    11b6:	746040ef          	jal	58fc <printf>
    exit(1);
    11ba:	4505                	li	a0,1
    11bc:	2e2040ef          	jal	549e <exit>
    printf("link(%s, %s) returned %d, not -1\n", b, b, ret);
    11c0:	f6840593          	addi	a1,s0,-152
    11c4:	86aa                	mv	a3,a0
    11c6:	862e                	mv	a2,a1
    11c8:	00005517          	auipc	a0,0x5
    11cc:	11050513          	addi	a0,a0,272 # 62d8 <malloc+0x920>
    11d0:	72c040ef          	jal	58fc <printf>
    exit(1);
    11d4:	4505                	li	a0,1
    11d6:	2c8040ef          	jal	549e <exit>
    printf("exec(%s) returned %d, not -1\n", b, fd);
    11da:	863e                	mv	a2,a5
    11dc:	f6840593          	addi	a1,s0,-152
    11e0:	00005517          	auipc	a0,0x5
    11e4:	12050513          	addi	a0,a0,288 # 6300 <malloc+0x948>
    11e8:	714040ef          	jal	58fc <printf>
    exit(1);
    11ec:	4505                	li	a0,1
    11ee:	2b0040ef          	jal	549e <exit>
    printf("fork failed\n");
    11f2:	00007517          	auipc	a0,0x7
    11f6:	84650513          	addi	a0,a0,-1978 # 7a38 <malloc+0x2080>
    11fa:	702040ef          	jal	58fc <printf>
    exit(1);
    11fe:	4505                	li	a0,1
    1200:	29e040ef          	jal	549e <exit>
    exit(747); // OK
    1204:	2eb00513          	li	a0,747
    1208:	296040ef          	jal	549e <exit>
  int st = 0;
    120c:	f4042a23          	sw	zero,-172(s0)
  wait(&st);
    1210:	f5440513          	addi	a0,s0,-172
    1214:	292040ef          	jal	54a6 <wait>
  if (st != 747) {
    1218:	f5442703          	lw	a4,-172(s0)
    121c:	2eb00793          	li	a5,747
    1220:	00f71663          	bne	a4,a5,122c <copyinstr2+0x18c>
}
    1224:	60ae                	ld	ra,200(sp)
    1226:	640e                	ld	s0,192(sp)
    1228:	6169                	addi	sp,sp,208
    122a:	8082                	ret
    printf("exec(echo, BIG) succeeded, should have failed\n");
    122c:	00005517          	auipc	a0,0x5
    1230:	11c50513          	addi	a0,a0,284 # 6348 <malloc+0x990>
    1234:	6c8040ef          	jal	58fc <printf>
    exit(1);
    1238:	4505                	li	a0,1
    123a:	264040ef          	jal	549e <exit>

000000000000123e <truncate3>:
{
    123e:	7175                	addi	sp,sp,-144
    1240:	e506                	sd	ra,136(sp)
    1242:	e122                	sd	s0,128(sp)
    1244:	fc66                	sd	s9,56(sp)
    1246:	0900                	addi	s0,sp,144
    1248:	8caa                	mv	s9,a0
  close(open("truncfile", O_CREATE | O_TRUNC | O_WRONLY));
    124a:	60100593          	li	a1,1537
    124e:	00005517          	auipc	a0,0x5
    1252:	8f250513          	addi	a0,a0,-1806 # 5b40 <malloc+0x188>
    1256:	288040ef          	jal	54de <open>
    125a:	26c040ef          	jal	54c6 <close>
  pid = fork();
    125e:	238040ef          	jal	5496 <fork>
  if (pid < 0) {
    1262:	06054d63          	bltz	a0,12dc <truncate3+0x9e>
  if (pid == 0) {
    1266:	e171                	bnez	a0,132a <truncate3+0xec>
    1268:	fca6                	sd	s1,120(sp)
    126a:	f8ca                	sd	s2,112(sp)
    126c:	f4ce                	sd	s3,104(sp)
    126e:	f0d2                	sd	s4,96(sp)
    1270:	ecd6                	sd	s5,88(sp)
    1272:	e8da                	sd	s6,80(sp)
    1274:	e4de                	sd	s7,72(sp)
    1276:	e0e2                	sd	s8,64(sp)
    1278:	06400913          	li	s2,100
      int fd = open("truncfile", O_WRONLY);
    127c:	4a85                	li	s5,1
    127e:	00005997          	auipc	s3,0x5
    1282:	8c298993          	addi	s3,s3,-1854 # 5b40 <malloc+0x188>
      int n = write(fd, "1234567890", 10);
    1286:	4a29                	li	s4,10
    1288:	00005b17          	auipc	s6,0x5
    128c:	120b0b13          	addi	s6,s6,288 # 63a8 <malloc+0x9f0>
      read(fd, buf, sizeof(buf));
    1290:	f7840c13          	addi	s8,s0,-136
    1294:	02000b93          	li	s7,32
      int fd = open("truncfile", O_WRONLY);
    1298:	85d6                	mv	a1,s5
    129a:	854e                	mv	a0,s3
    129c:	242040ef          	jal	54de <open>
    12a0:	84aa                	mv	s1,a0
      if (fd < 0) {
    12a2:	04054f63          	bltz	a0,1300 <truncate3+0xc2>
      int n = write(fd, "1234567890", 10);
    12a6:	8652                	mv	a2,s4
    12a8:	85da                	mv	a1,s6
    12aa:	214040ef          	jal	54be <write>
      if (n != 10) {
    12ae:	07451363          	bne	a0,s4,1314 <truncate3+0xd6>
      close(fd);
    12b2:	8526                	mv	a0,s1
    12b4:	212040ef          	jal	54c6 <close>
      fd = open("truncfile", O_RDONLY);
    12b8:	4581                	li	a1,0
    12ba:	854e                	mv	a0,s3
    12bc:	222040ef          	jal	54de <open>
    12c0:	84aa                	mv	s1,a0
      read(fd, buf, sizeof(buf));
    12c2:	865e                	mv	a2,s7
    12c4:	85e2                	mv	a1,s8
    12c6:	1f0040ef          	jal	54b6 <read>
      close(fd);
    12ca:	8526                	mv	a0,s1
    12cc:	1fa040ef          	jal	54c6 <close>
    for (int i = 0; i < 100; i++) {
    12d0:	397d                	addiw	s2,s2,-1
    12d2:	fc0913e3          	bnez	s2,1298 <truncate3+0x5a>
    exit(0);
    12d6:	4501                	li	a0,0
    12d8:	1c6040ef          	jal	549e <exit>
    12dc:	fca6                	sd	s1,120(sp)
    12de:	f8ca                	sd	s2,112(sp)
    12e0:	f4ce                	sd	s3,104(sp)
    12e2:	f0d2                	sd	s4,96(sp)
    12e4:	ecd6                	sd	s5,88(sp)
    12e6:	e8da                	sd	s6,80(sp)
    12e8:	e4de                	sd	s7,72(sp)
    12ea:	e0e2                	sd	s8,64(sp)
    printf("%s: fork failed\n", s);
    12ec:	85e6                	mv	a1,s9
    12ee:	00005517          	auipc	a0,0x5
    12f2:	08a50513          	addi	a0,a0,138 # 6378 <malloc+0x9c0>
    12f6:	606040ef          	jal	58fc <printf>
    exit(1);
    12fa:	4505                	li	a0,1
    12fc:	1a2040ef          	jal	549e <exit>
        printf("%s: open failed\n", s);
    1300:	85e6                	mv	a1,s9
    1302:	00005517          	auipc	a0,0x5
    1306:	08e50513          	addi	a0,a0,142 # 6390 <malloc+0x9d8>
    130a:	5f2040ef          	jal	58fc <printf>
        exit(1);
    130e:	4505                	li	a0,1
    1310:	18e040ef          	jal	549e <exit>
        printf("%s: write got %d, expected 10\n", s, n);
    1314:	862a                	mv	a2,a0
    1316:	85e6                	mv	a1,s9
    1318:	00005517          	auipc	a0,0x5
    131c:	0a050513          	addi	a0,a0,160 # 63b8 <malloc+0xa00>
    1320:	5dc040ef          	jal	58fc <printf>
        exit(1);
    1324:	4505                	li	a0,1
    1326:	178040ef          	jal	549e <exit>
    132a:	fca6                	sd	s1,120(sp)
    132c:	f8ca                	sd	s2,112(sp)
    132e:	f4ce                	sd	s3,104(sp)
    1330:	f0d2                	sd	s4,96(sp)
    1332:	ecd6                	sd	s5,88(sp)
    1334:	e8da                	sd	s6,80(sp)
  if (pid == 0) {
    1336:	09600913          	li	s2,150
    int fd = open("truncfile", O_CREATE | O_WRONLY | O_TRUNC);
    133a:	60100a93          	li	s5,1537
    133e:	00005a17          	auipc	s4,0x5
    1342:	802a0a13          	addi	s4,s4,-2046 # 5b40 <malloc+0x188>
    int n = write(fd, "xxx", 3);
    1346:	498d                	li	s3,3
    1348:	00005b17          	auipc	s6,0x5
    134c:	090b0b13          	addi	s6,s6,144 # 63d8 <malloc+0xa20>
    int fd = open("truncfile", O_CREATE | O_WRONLY | O_TRUNC);
    1350:	85d6                	mv	a1,s5
    1352:	8552                	mv	a0,s4
    1354:	18a040ef          	jal	54de <open>
    1358:	84aa                	mv	s1,a0
    if (fd < 0) {
    135a:	02054e63          	bltz	a0,1396 <truncate3+0x158>
    int n = write(fd, "xxx", 3);
    135e:	864e                	mv	a2,s3
    1360:	85da                	mv	a1,s6
    1362:	15c040ef          	jal	54be <write>
    if (n != 3) {
    1366:	05351463          	bne	a0,s3,13ae <truncate3+0x170>
    close(fd);
    136a:	8526                	mv	a0,s1
    136c:	15a040ef          	jal	54c6 <close>
  for (int i = 0; i < 150; i++) {
    1370:	397d                	addiw	s2,s2,-1
    1372:	fc091fe3          	bnez	s2,1350 <truncate3+0x112>
    1376:	e4de                	sd	s7,72(sp)
    1378:	e0e2                	sd	s8,64(sp)
  wait(&xstatus);
    137a:	f9c40513          	addi	a0,s0,-100
    137e:	128040ef          	jal	54a6 <wait>
  unlink("truncfile");
    1382:	00004517          	auipc	a0,0x4
    1386:	7be50513          	addi	a0,a0,1982 # 5b40 <malloc+0x188>
    138a:	164040ef          	jal	54ee <unlink>
  exit(xstatus);
    138e:	f9c42503          	lw	a0,-100(s0)
    1392:	10c040ef          	jal	549e <exit>
    1396:	e4de                	sd	s7,72(sp)
    1398:	e0e2                	sd	s8,64(sp)
      printf("%s: open failed\n", s);
    139a:	85e6                	mv	a1,s9
    139c:	00005517          	auipc	a0,0x5
    13a0:	ff450513          	addi	a0,a0,-12 # 6390 <malloc+0x9d8>
    13a4:	558040ef          	jal	58fc <printf>
      exit(1);
    13a8:	4505                	li	a0,1
    13aa:	0f4040ef          	jal	549e <exit>
    13ae:	e4de                	sd	s7,72(sp)
    13b0:	e0e2                	sd	s8,64(sp)
      printf("%s: write got %d, expected 3\n", s, n);
    13b2:	862a                	mv	a2,a0
    13b4:	85e6                	mv	a1,s9
    13b6:	00005517          	auipc	a0,0x5
    13ba:	02a50513          	addi	a0,a0,42 # 63e0 <malloc+0xa28>
    13be:	53e040ef          	jal	58fc <printf>
      exit(1);
    13c2:	4505                	li	a0,1
    13c4:	0da040ef          	jal	549e <exit>

00000000000013c8 <pipe1>:
{
    13c8:	711d                	addi	sp,sp,-96
    13ca:	ec86                	sd	ra,88(sp)
    13cc:	e8a2                	sd	s0,80(sp)
    13ce:	e862                	sd	s8,16(sp)
    13d0:	1080                	addi	s0,sp,96
    13d2:	8c2a                	mv	s8,a0
  if (pipe(fds) != 0) {
    13d4:	fa840513          	addi	a0,s0,-88
    13d8:	0d6040ef          	jal	54ae <pipe>
    13dc:	e925                	bnez	a0,144c <pipe1+0x84>
    13de:	e4a6                	sd	s1,72(sp)
    13e0:	fc4e                	sd	s3,56(sp)
    13e2:	84aa                	mv	s1,a0
  pid = fork();
    13e4:	0b2040ef          	jal	5496 <fork>
    13e8:	89aa                	mv	s3,a0
  if (pid == 0) {
    13ea:	c151                	beqz	a0,146e <pipe1+0xa6>
  } else if (pid > 0) {
    13ec:	16a05063          	blez	a0,154c <pipe1+0x184>
    13f0:	e0ca                	sd	s2,64(sp)
    13f2:	f852                	sd	s4,48(sp)
    close(fds[1]);
    13f4:	fac42503          	lw	a0,-84(s0)
    13f8:	0ce040ef          	jal	54c6 <close>
    total = 0;
    13fc:	89a6                	mv	s3,s1
    cc = 1;
    13fe:	4905                	li	s2,1
    while ((n = read(fds[0], buf, cc)) > 0) {
    1400:	0000ca17          	auipc	s4,0xc
    1404:	8e8a0a13          	addi	s4,s4,-1816 # cce8 <buf>
    1408:	864a                	mv	a2,s2
    140a:	85d2                	mv	a1,s4
    140c:	fa842503          	lw	a0,-88(s0)
    1410:	0a6040ef          	jal	54b6 <read>
    1414:	85aa                	mv	a1,a0
    1416:	0ea05963          	blez	a0,1508 <pipe1+0x140>
    141a:	0000c797          	auipc	a5,0xc
    141e:	8ce78793          	addi	a5,a5,-1842 # cce8 <buf>
    1422:	00b4863b          	addw	a2,s1,a1
        if ((buf[i] & 0xff) != (seq++ & 0xff)) {
    1426:	0007c683          	lbu	a3,0(a5)
    142a:	0ff4f713          	zext.b	a4,s1
    142e:	0ae69d63          	bne	a3,a4,14e8 <pipe1+0x120>
    1432:	2485                	addiw	s1,s1,1
      for (i = 0; i < n; i++) {
    1434:	0785                	addi	a5,a5,1
    1436:	fec498e3          	bne	s1,a2,1426 <pipe1+0x5e>
      total += n;
    143a:	00b989bb          	addw	s3,s3,a1
      cc = cc * 2;
    143e:	0019191b          	slliw	s2,s2,0x1
      if (cc > sizeof(buf))
    1442:	678d                	lui	a5,0x3
    1444:	fd27f2e3          	bgeu	a5,s2,1408 <pipe1+0x40>
        cc = sizeof(buf);
    1448:	893e                	mv	s2,a5
    144a:	bf7d                	j	1408 <pipe1+0x40>
    144c:	e4a6                	sd	s1,72(sp)
    144e:	e0ca                	sd	s2,64(sp)
    1450:	fc4e                	sd	s3,56(sp)
    1452:	f852                	sd	s4,48(sp)
    1454:	f456                	sd	s5,40(sp)
    1456:	f05a                	sd	s6,32(sp)
    1458:	ec5e                	sd	s7,24(sp)
    printf("%s: pipe() failed\n", s);
    145a:	85e2                	mv	a1,s8
    145c:	00005517          	auipc	a0,0x5
    1460:	fa450513          	addi	a0,a0,-92 # 6400 <malloc+0xa48>
    1464:	498040ef          	jal	58fc <printf>
    exit(1);
    1468:	4505                	li	a0,1
    146a:	034040ef          	jal	549e <exit>
    146e:	e0ca                	sd	s2,64(sp)
    1470:	f852                	sd	s4,48(sp)
    1472:	f456                	sd	s5,40(sp)
    1474:	f05a                	sd	s6,32(sp)
    1476:	ec5e                	sd	s7,24(sp)
    close(fds[0]);
    1478:	fa842503          	lw	a0,-88(s0)
    147c:	04a040ef          	jal	54c6 <close>
    for (n = 0; n < N; n++) {
    1480:	0000cb17          	auipc	s6,0xc
    1484:	868b0b13          	addi	s6,s6,-1944 # cce8 <buf>
    1488:	416004bb          	negw	s1,s6
    148c:	0ff4f493          	zext.b	s1,s1
    1490:	409b0913          	addi	s2,s6,1033
      if (write(fds[1], buf, SZ) != SZ) {
    1494:	40900a13          	li	s4,1033
    1498:	8bda                	mv	s7,s6
    for (n = 0; n < N; n++) {
    149a:	6a85                	lui	s5,0x1
    149c:	42da8a93          	addi	s5,s5,1069 # 142d <pipe1+0x65>
{
    14a0:	87da                	mv	a5,s6
        buf[i] = seq++;
    14a2:	0097873b          	addw	a4,a5,s1
    14a6:	00e78023          	sb	a4,0(a5) # 3000 <subdir+0x47a>
      for (i = 0; i < SZ; i++)
    14aa:	0785                	addi	a5,a5,1
    14ac:	ff279be3          	bne	a5,s2,14a2 <pipe1+0xda>
      if (write(fds[1], buf, SZ) != SZ) {
    14b0:	8652                	mv	a2,s4
    14b2:	85de                	mv	a1,s7
    14b4:	fac42503          	lw	a0,-84(s0)
    14b8:	006040ef          	jal	54be <write>
    14bc:	01451c63          	bne	a0,s4,14d4 <pipe1+0x10c>
    14c0:	4099899b          	addiw	s3,s3,1033
    for (n = 0; n < N; n++) {
    14c4:	24a5                	addiw	s1,s1,9
    14c6:	0ff4f493          	zext.b	s1,s1
    14ca:	fd599be3          	bne	s3,s5,14a0 <pipe1+0xd8>
    exit(0);
    14ce:	4501                	li	a0,0
    14d0:	7cf030ef          	jal	549e <exit>
        printf("%s: pipe1 oops 1\n", s);
    14d4:	85e2                	mv	a1,s8
    14d6:	00005517          	auipc	a0,0x5
    14da:	f4250513          	addi	a0,a0,-190 # 6418 <malloc+0xa60>
    14de:	41e040ef          	jal	58fc <printf>
        exit(1);
    14e2:	4505                	li	a0,1
    14e4:	7bb030ef          	jal	549e <exit>
          printf("%s: pipe1 oops 2\n", s);
    14e8:	85e2                	mv	a1,s8
    14ea:	00005517          	auipc	a0,0x5
    14ee:	f4650513          	addi	a0,a0,-186 # 6430 <malloc+0xa78>
    14f2:	40a040ef          	jal	58fc <printf>
          return;
    14f6:	64a6                	ld	s1,72(sp)
    14f8:	6906                	ld	s2,64(sp)
    14fa:	79e2                	ld	s3,56(sp)
    14fc:	7a42                	ld	s4,48(sp)
}
    14fe:	60e6                	ld	ra,88(sp)
    1500:	6446                	ld	s0,80(sp)
    1502:	6c42                	ld	s8,16(sp)
    1504:	6125                	addi	sp,sp,96
    1506:	8082                	ret
    if (total != N * SZ) {
    1508:	6785                	lui	a5,0x1
    150a:	42d78793          	addi	a5,a5,1069 # 142d <pipe1+0x65>
    150e:	02f98063          	beq	s3,a5,152e <pipe1+0x166>
    1512:	f456                	sd	s5,40(sp)
    1514:	f05a                	sd	s6,32(sp)
    1516:	ec5e                	sd	s7,24(sp)
      printf("%s: pipe1 oops 3 total %d\n", s, total);
    1518:	864e                	mv	a2,s3
    151a:	85e2                	mv	a1,s8
    151c:	00005517          	auipc	a0,0x5
    1520:	f2c50513          	addi	a0,a0,-212 # 6448 <malloc+0xa90>
    1524:	3d8040ef          	jal	58fc <printf>
      exit(1);
    1528:	4505                	li	a0,1
    152a:	775030ef          	jal	549e <exit>
    152e:	f456                	sd	s5,40(sp)
    1530:	f05a                	sd	s6,32(sp)
    1532:	ec5e                	sd	s7,24(sp)
    close(fds[0]);
    1534:	fa842503          	lw	a0,-88(s0)
    1538:	78f030ef          	jal	54c6 <close>
    wait(&xstatus);
    153c:	fa440513          	addi	a0,s0,-92
    1540:	767030ef          	jal	54a6 <wait>
    exit(xstatus);
    1544:	fa442503          	lw	a0,-92(s0)
    1548:	757030ef          	jal	549e <exit>
    154c:	e0ca                	sd	s2,64(sp)
    154e:	f852                	sd	s4,48(sp)
    1550:	f456                	sd	s5,40(sp)
    1552:	f05a                	sd	s6,32(sp)
    1554:	ec5e                	sd	s7,24(sp)
    printf("%s: fork() failed\n", s);
    1556:	85e2                	mv	a1,s8
    1558:	00005517          	auipc	a0,0x5
    155c:	f1050513          	addi	a0,a0,-240 # 6468 <malloc+0xab0>
    1560:	39c040ef          	jal	58fc <printf>
    exit(1);
    1564:	4505                	li	a0,1
    1566:	739030ef          	jal	549e <exit>

000000000000156a <exitwait>:
{
    156a:	715d                	addi	sp,sp,-80
    156c:	e486                	sd	ra,72(sp)
    156e:	e0a2                	sd	s0,64(sp)
    1570:	fc26                	sd	s1,56(sp)
    1572:	f84a                	sd	s2,48(sp)
    1574:	f44e                	sd	s3,40(sp)
    1576:	f052                	sd	s4,32(sp)
    1578:	ec56                	sd	s5,24(sp)
    157a:	0880                	addi	s0,sp,80
    157c:	8aaa                	mv	s5,a0
  for (i = 0; i < 100; i++) {
    157e:	4901                	li	s2,0
      if (wait(&xstate) != pid) {
    1580:	fbc40993          	addi	s3,s0,-68
  for (i = 0; i < 100; i++) {
    1584:	06400a13          	li	s4,100
    pid = fork();
    1588:	70f030ef          	jal	5496 <fork>
    158c:	84aa                	mv	s1,a0
    if (pid < 0) {
    158e:	02054863          	bltz	a0,15be <exitwait+0x54>
    if (pid) {
    1592:	c525                	beqz	a0,15fa <exitwait+0x90>
      if (wait(&xstate) != pid) {
    1594:	854e                	mv	a0,s3
    1596:	711030ef          	jal	54a6 <wait>
    159a:	02951c63          	bne	a0,s1,15d2 <exitwait+0x68>
      if (i != xstate) {
    159e:	fbc42783          	lw	a5,-68(s0)
    15a2:	05279263          	bne	a5,s2,15e6 <exitwait+0x7c>
  for (i = 0; i < 100; i++) {
    15a6:	2905                	addiw	s2,s2,1
    15a8:	ff4910e3          	bne	s2,s4,1588 <exitwait+0x1e>
}
    15ac:	60a6                	ld	ra,72(sp)
    15ae:	6406                	ld	s0,64(sp)
    15b0:	74e2                	ld	s1,56(sp)
    15b2:	7942                	ld	s2,48(sp)
    15b4:	79a2                	ld	s3,40(sp)
    15b6:	7a02                	ld	s4,32(sp)
    15b8:	6ae2                	ld	s5,24(sp)
    15ba:	6161                	addi	sp,sp,80
    15bc:	8082                	ret
      printf("%s: fork failed\n", s);
    15be:	85d6                	mv	a1,s5
    15c0:	00005517          	auipc	a0,0x5
    15c4:	db850513          	addi	a0,a0,-584 # 6378 <malloc+0x9c0>
    15c8:	334040ef          	jal	58fc <printf>
      exit(1);
    15cc:	4505                	li	a0,1
    15ce:	6d1030ef          	jal	549e <exit>
        printf("%s: wait wrong pid\n", s);
    15d2:	85d6                	mv	a1,s5
    15d4:	00005517          	auipc	a0,0x5
    15d8:	eac50513          	addi	a0,a0,-340 # 6480 <malloc+0xac8>
    15dc:	320040ef          	jal	58fc <printf>
        exit(1);
    15e0:	4505                	li	a0,1
    15e2:	6bd030ef          	jal	549e <exit>
        printf("%s: wait wrong exit status\n", s);
    15e6:	85d6                	mv	a1,s5
    15e8:	00005517          	auipc	a0,0x5
    15ec:	eb050513          	addi	a0,a0,-336 # 6498 <malloc+0xae0>
    15f0:	30c040ef          	jal	58fc <printf>
        exit(1);
    15f4:	4505                	li	a0,1
    15f6:	6a9030ef          	jal	549e <exit>
      exit(i);
    15fa:	854a                	mv	a0,s2
    15fc:	6a3030ef          	jal	549e <exit>

0000000000001600 <twochildren>:
{
    1600:	1101                	addi	sp,sp,-32
    1602:	ec06                	sd	ra,24(sp)
    1604:	e822                	sd	s0,16(sp)
    1606:	e426                	sd	s1,8(sp)
    1608:	e04a                	sd	s2,0(sp)
    160a:	1000                	addi	s0,sp,32
    160c:	892a                	mv	s2,a0
    160e:	3e800493          	li	s1,1000
    int pid1 = fork();
    1612:	685030ef          	jal	5496 <fork>
    if (pid1 < 0) {
    1616:	02054663          	bltz	a0,1642 <twochildren+0x42>
    if (pid1 == 0) {
    161a:	cd15                	beqz	a0,1656 <twochildren+0x56>
      int pid2 = fork();
    161c:	67b030ef          	jal	5496 <fork>
      if (pid2 < 0) {
    1620:	02054d63          	bltz	a0,165a <twochildren+0x5a>
      if (pid2 == 0) {
    1624:	c529                	beqz	a0,166e <twochildren+0x6e>
        wait(0);
    1626:	4501                	li	a0,0
    1628:	67f030ef          	jal	54a6 <wait>
        wait(0);
    162c:	4501                	li	a0,0
    162e:	679030ef          	jal	54a6 <wait>
  for (int i = 0; i < 1000; i++) {
    1632:	34fd                	addiw	s1,s1,-1
    1634:	fcf9                	bnez	s1,1612 <twochildren+0x12>
}
    1636:	60e2                	ld	ra,24(sp)
    1638:	6442                	ld	s0,16(sp)
    163a:	64a2                	ld	s1,8(sp)
    163c:	6902                	ld	s2,0(sp)
    163e:	6105                	addi	sp,sp,32
    1640:	8082                	ret
      printf("%s: fork failed\n", s);
    1642:	85ca                	mv	a1,s2
    1644:	00005517          	auipc	a0,0x5
    1648:	d3450513          	addi	a0,a0,-716 # 6378 <malloc+0x9c0>
    164c:	2b0040ef          	jal	58fc <printf>
      exit(1);
    1650:	4505                	li	a0,1
    1652:	64d030ef          	jal	549e <exit>
      exit(0);
    1656:	649030ef          	jal	549e <exit>
        printf("%s: fork failed\n", s);
    165a:	85ca                	mv	a1,s2
    165c:	00005517          	auipc	a0,0x5
    1660:	d1c50513          	addi	a0,a0,-740 # 6378 <malloc+0x9c0>
    1664:	298040ef          	jal	58fc <printf>
        exit(1);
    1668:	4505                	li	a0,1
    166a:	635030ef          	jal	549e <exit>
        exit(0);
    166e:	631030ef          	jal	549e <exit>

0000000000001672 <forkfork>:
{
    1672:	7179                	addi	sp,sp,-48
    1674:	f406                	sd	ra,40(sp)
    1676:	f022                	sd	s0,32(sp)
    1678:	ec26                	sd	s1,24(sp)
    167a:	1800                	addi	s0,sp,48
    167c:	84aa                	mv	s1,a0
    int pid = fork();
    167e:	619030ef          	jal	5496 <fork>
    if (pid < 0) {
    1682:	02054b63          	bltz	a0,16b8 <forkfork+0x46>
    if (pid == 0) {
    1686:	c139                	beqz	a0,16cc <forkfork+0x5a>
    int pid = fork();
    1688:	60f030ef          	jal	5496 <fork>
    if (pid < 0) {
    168c:	02054663          	bltz	a0,16b8 <forkfork+0x46>
    if (pid == 0) {
    1690:	cd15                	beqz	a0,16cc <forkfork+0x5a>
    wait(&xstatus);
    1692:	fdc40513          	addi	a0,s0,-36
    1696:	611030ef          	jal	54a6 <wait>
    if (xstatus != 0) {
    169a:	fdc42783          	lw	a5,-36(s0)
    169e:	ebb9                	bnez	a5,16f4 <forkfork+0x82>
    wait(&xstatus);
    16a0:	fdc40513          	addi	a0,s0,-36
    16a4:	603030ef          	jal	54a6 <wait>
    if (xstatus != 0) {
    16a8:	fdc42783          	lw	a5,-36(s0)
    16ac:	e7a1                	bnez	a5,16f4 <forkfork+0x82>
}
    16ae:	70a2                	ld	ra,40(sp)
    16b0:	7402                	ld	s0,32(sp)
    16b2:	64e2                	ld	s1,24(sp)
    16b4:	6145                	addi	sp,sp,48
    16b6:	8082                	ret
      printf("%s: fork failed", s);
    16b8:	85a6                	mv	a1,s1
    16ba:	00005517          	auipc	a0,0x5
    16be:	dfe50513          	addi	a0,a0,-514 # 64b8 <malloc+0xb00>
    16c2:	23a040ef          	jal	58fc <printf>
      exit(1);
    16c6:	4505                	li	a0,1
    16c8:	5d7030ef          	jal	549e <exit>
{
    16cc:	0c800493          	li	s1,200
        int pid1 = fork();
    16d0:	5c7030ef          	jal	5496 <fork>
        if (pid1 < 0) {
    16d4:	00054b63          	bltz	a0,16ea <forkfork+0x78>
        if (pid1 == 0) {
    16d8:	cd01                	beqz	a0,16f0 <forkfork+0x7e>
        wait(0);
    16da:	4501                	li	a0,0
    16dc:	5cb030ef          	jal	54a6 <wait>
      for (int j = 0; j < 200; j++) {
    16e0:	34fd                	addiw	s1,s1,-1
    16e2:	f4fd                	bnez	s1,16d0 <forkfork+0x5e>
      exit(0);
    16e4:	4501                	li	a0,0
    16e6:	5b9030ef          	jal	549e <exit>
          exit(1);
    16ea:	4505                	li	a0,1
    16ec:	5b3030ef          	jal	549e <exit>
          exit(0);
    16f0:	5af030ef          	jal	549e <exit>
      printf("%s: fork in child failed", s);
    16f4:	85a6                	mv	a1,s1
    16f6:	00005517          	auipc	a0,0x5
    16fa:	dd250513          	addi	a0,a0,-558 # 64c8 <malloc+0xb10>
    16fe:	1fe040ef          	jal	58fc <printf>
      exit(1);
    1702:	4505                	li	a0,1
    1704:	59b030ef          	jal	549e <exit>

0000000000001708 <reparent2>:
{
    1708:	1101                	addi	sp,sp,-32
    170a:	ec06                	sd	ra,24(sp)
    170c:	e822                	sd	s0,16(sp)
    170e:	e426                	sd	s1,8(sp)
    1710:	1000                	addi	s0,sp,32
    1712:	32000493          	li	s1,800
    int pid1 = fork();
    1716:	581030ef          	jal	5496 <fork>
    if (pid1 < 0) {
    171a:	00054b63          	bltz	a0,1730 <reparent2+0x28>
    if (pid1 == 0) {
    171e:	c115                	beqz	a0,1742 <reparent2+0x3a>
    wait(0);
    1720:	4501                	li	a0,0
    1722:	585030ef          	jal	54a6 <wait>
  for (int i = 0; i < 800; i++) {
    1726:	34fd                	addiw	s1,s1,-1
    1728:	f4fd                	bnez	s1,1716 <reparent2+0xe>
  exit(0);
    172a:	4501                	li	a0,0
    172c:	573030ef          	jal	549e <exit>
      printf("fork failed\n");
    1730:	00006517          	auipc	a0,0x6
    1734:	30850513          	addi	a0,a0,776 # 7a38 <malloc+0x2080>
    1738:	1c4040ef          	jal	58fc <printf>
      exit(1);
    173c:	4505                	li	a0,1
    173e:	561030ef          	jal	549e <exit>
      fork();
    1742:	555030ef          	jal	5496 <fork>
      fork();
    1746:	551030ef          	jal	5496 <fork>
      exit(0);
    174a:	4501                	li	a0,0
    174c:	553030ef          	jal	549e <exit>

0000000000001750 <createdelete>:
{
    1750:	7135                	addi	sp,sp,-160
    1752:	ed06                	sd	ra,152(sp)
    1754:	e922                	sd	s0,144(sp)
    1756:	e526                	sd	s1,136(sp)
    1758:	e14a                	sd	s2,128(sp)
    175a:	fcce                	sd	s3,120(sp)
    175c:	f8d2                	sd	s4,112(sp)
    175e:	f4d6                	sd	s5,104(sp)
    1760:	f0da                	sd	s6,96(sp)
    1762:	ecde                	sd	s7,88(sp)
    1764:	e8e2                	sd	s8,80(sp)
    1766:	e4e6                	sd	s9,72(sp)
    1768:	e0ea                	sd	s10,64(sp)
    176a:	fc6e                	sd	s11,56(sp)
    176c:	1100                	addi	s0,sp,160
    176e:	8daa                	mv	s11,a0
  for (pi = 0; pi < NCHILD; pi++) {
    1770:	4901                	li	s2,0
    1772:	4991                	li	s3,4
    pid = fork();
    1774:	523030ef          	jal	5496 <fork>
    1778:	84aa                	mv	s1,a0
    if (pid < 0) {
    177a:	04054063          	bltz	a0,17ba <createdelete+0x6a>
    if (pid == 0) {
    177e:	c921                	beqz	a0,17ce <createdelete+0x7e>
  for (pi = 0; pi < NCHILD; pi++) {
    1780:	2905                	addiw	s2,s2,1
    1782:	ff3919e3          	bne	s2,s3,1774 <createdelete+0x24>
    1786:	4491                	li	s1,4
    wait(&xstatus);
    1788:	f6c40913          	addi	s2,s0,-148
    178c:	854a                	mv	a0,s2
    178e:	519030ef          	jal	54a6 <wait>
    if (xstatus != 0)
    1792:	f6c42a83          	lw	s5,-148(s0)
    1796:	0c0a9263          	bnez	s5,185a <createdelete+0x10a>
  for (pi = 0; pi < NCHILD; pi++) {
    179a:	34fd                	addiw	s1,s1,-1
    179c:	f8e5                	bnez	s1,178c <createdelete+0x3c>
  name[0] = name[1] = name[2] = 0;
    179e:	f6040923          	sb	zero,-142(s0)
    17a2:	03000993          	li	s3,48
    17a6:	5a7d                	li	s4,-1
      if ((i == 0 || i >= N / 2) && fd < 0) {
    17a8:	4d25                	li	s10,9
    17aa:	07000c93          	li	s9,112
      fd = open(name, 0);
    17ae:	f7040c13          	addi	s8,s0,-144
      } else if ((i >= 1 && i < N / 2) && fd >= 0) {
    17b2:	4ba1                	li	s7,8
    for (pi = 0; pi < NCHILD; pi++) {
    17b4:	07400b13          	li	s6,116
    17b8:	aa39                	j	18d6 <createdelete+0x186>
      printf("%s: fork failed\n", s);
    17ba:	85ee                	mv	a1,s11
    17bc:	00005517          	auipc	a0,0x5
    17c0:	bbc50513          	addi	a0,a0,-1092 # 6378 <malloc+0x9c0>
    17c4:	138040ef          	jal	58fc <printf>
      exit(1);
    17c8:	4505                	li	a0,1
    17ca:	4d5030ef          	jal	549e <exit>
      name[0] = 'p' + pi;
    17ce:	0709091b          	addiw	s2,s2,112
    17d2:	f7240823          	sb	s2,-144(s0)
      name[2] = '\0';
    17d6:	f6040923          	sb	zero,-142(s0)
        fd = open(name, O_CREATE | O_RDWR);
    17da:	f7040913          	addi	s2,s0,-144
    17de:	20200993          	li	s3,514
      for (i = 0; i < N; i++) {
    17e2:	4a51                	li	s4,20
    17e4:	a815                	j	1818 <createdelete+0xc8>
          printf("%s: create failed\n", s);
    17e6:	85ee                	mv	a1,s11
    17e8:	00005517          	auipc	a0,0x5
    17ec:	d0050513          	addi	a0,a0,-768 # 64e8 <malloc+0xb30>
    17f0:	10c040ef          	jal	58fc <printf>
          exit(1);
    17f4:	4505                	li	a0,1
    17f6:	4a9030ef          	jal	549e <exit>
          name[1] = '0' + (i / 2);
    17fa:	01f4d79b          	srliw	a5,s1,0x1f
    17fe:	9fa5                	addw	a5,a5,s1
    1800:	4017d79b          	sraiw	a5,a5,0x1
    1804:	0307879b          	addiw	a5,a5,48
    1808:	f6f408a3          	sb	a5,-143(s0)
          if (unlink(name) < 0) {
    180c:	854a                	mv	a0,s2
    180e:	4e1030ef          	jal	54ee <unlink>
    1812:	02054a63          	bltz	a0,1846 <createdelete+0xf6>
      for (i = 0; i < N; i++) {
    1816:	2485                	addiw	s1,s1,1
        name[1] = '0' + i;
    1818:	0304879b          	addiw	a5,s1,48
    181c:	f6f408a3          	sb	a5,-143(s0)
        fd = open(name, O_CREATE | O_RDWR);
    1820:	85ce                	mv	a1,s3
    1822:	854a                	mv	a0,s2
    1824:	4bb030ef          	jal	54de <open>
        if (fd < 0) {
    1828:	fa054fe3          	bltz	a0,17e6 <createdelete+0x96>
        close(fd);
    182c:	49b030ef          	jal	54c6 <close>
        if (i > 0 && (i % 2) == 0) {
    1830:	fe9053e3          	blez	s1,1816 <createdelete+0xc6>
    1834:	0014f793          	andi	a5,s1,1
    1838:	d3e9                	beqz	a5,17fa <createdelete+0xaa>
      for (i = 0; i < N; i++) {
    183a:	2485                	addiw	s1,s1,1
    183c:	fd449ee3          	bne	s1,s4,1818 <createdelete+0xc8>
      exit(0);
    1840:	4501                	li	a0,0
    1842:	45d030ef          	jal	549e <exit>
            printf("%s: unlink failed\n", s);
    1846:	85ee                	mv	a1,s11
    1848:	00005517          	auipc	a0,0x5
    184c:	cb850513          	addi	a0,a0,-840 # 6500 <malloc+0xb48>
    1850:	0ac040ef          	jal	58fc <printf>
            exit(1);
    1854:	4505                	li	a0,1
    1856:	449030ef          	jal	549e <exit>
      exit(1);
    185a:	4505                	li	a0,1
    185c:	443030ef          	jal	549e <exit>
        printf("%s: oops createdelete %s didn't exist\n", s, name);
    1860:	f7040613          	addi	a2,s0,-144
    1864:	85ee                	mv	a1,s11
    1866:	00005517          	auipc	a0,0x5
    186a:	cb250513          	addi	a0,a0,-846 # 6518 <malloc+0xb60>
    186e:	08e040ef          	jal	58fc <printf>
        exit(1);
    1872:	4505                	li	a0,1
    1874:	42b030ef          	jal	549e <exit>
      } else if ((i >= 1 && i < N / 2) && fd >= 0) {
    1878:	02054063          	bltz	a0,1898 <createdelete+0x148>
        printf("%s: oops createdelete %s did exist\n", s, name);
    187c:	f7040613          	addi	a2,s0,-144
    1880:	85ee                	mv	a1,s11
    1882:	00005517          	auipc	a0,0x5
    1886:	cbe50513          	addi	a0,a0,-834 # 6540 <malloc+0xb88>
    188a:	072040ef          	jal	58fc <printf>
        exit(1);
    188e:	4505                	li	a0,1
    1890:	40f030ef          	jal	549e <exit>
        close(fd);
    1894:	433030ef          	jal	54c6 <close>
    for (pi = 0; pi < NCHILD; pi++) {
    1898:	2485                	addiw	s1,s1,1
    189a:	0ff4f493          	zext.b	s1,s1
    189e:	03648463          	beq	s1,s6,18c6 <createdelete+0x176>
      name[0] = 'p' + pi;
    18a2:	f6940823          	sb	s1,-144(s0)
      name[1] = '0' + i;
    18a6:	f73408a3          	sb	s3,-143(s0)
      fd = open(name, 0);
    18aa:	4581                	li	a1,0
    18ac:	8562                	mv	a0,s8
    18ae:	431030ef          	jal	54de <open>
      if ((i == 0 || i >= N / 2) && fd < 0) {
    18b2:	01f5579b          	srliw	a5,a0,0x1f
    18b6:	00f977b3          	and	a5,s2,a5
    18ba:	f3dd                	bnez	a5,1860 <createdelete+0x110>
      } else if ((i >= 1 && i < N / 2) && fd >= 0) {
    18bc:	fb4bfee3          	bgeu	s7,s4,1878 <createdelete+0x128>
      if (fd >= 0)
    18c0:	fc054ce3          	bltz	a0,1898 <createdelete+0x148>
    18c4:	bfc1                	j	1894 <createdelete+0x144>
  for (i = 0; i < N; i++) {
    18c6:	2a85                	addiw	s5,s5,1
    18c8:	2a05                	addiw	s4,s4,1
    18ca:	2985                	addiw	s3,s3,1
    18cc:	0ff9f993          	zext.b	s3,s3
    18d0:	47d1                	li	a5,20
    18d2:	00fa8a63          	beq	s5,a5,18e6 <createdelete+0x196>
      if ((i == 0 || i >= N / 2) && fd < 0) {
    18d6:	001ab913          	seqz	s2,s5
    18da:	015d27b3          	slt	a5,s10,s5
    18de:	00f96933          	or	s2,s2,a5
    18e2:	84e6                	mv	s1,s9
    18e4:	bf7d                	j	18a2 <createdelete+0x152>
  for (i = 0; i < N; i++) {
    18e6:	03000913          	li	s2,48
  name[0] = name[1] = name[2] = 0;
    18ea:	07000b13          	li	s6,112
      unlink(name);
    18ee:	f7040a13          	addi	s4,s0,-144
    for (pi = 0; pi < NCHILD; pi++) {
    18f2:	07400993          	li	s3,116
  for (i = 0; i < N; i++) {
    18f6:	04400a93          	li	s5,68
  name[0] = name[1] = name[2] = 0;
    18fa:	84da                	mv	s1,s6
      name[0] = 'p' + pi;
    18fc:	f6940823          	sb	s1,-144(s0)
      name[1] = '0' + i;
    1900:	f72408a3          	sb	s2,-143(s0)
      unlink(name);
    1904:	8552                	mv	a0,s4
    1906:	3e9030ef          	jal	54ee <unlink>
    for (pi = 0; pi < NCHILD; pi++) {
    190a:	2485                	addiw	s1,s1,1
    190c:	0ff4f493          	zext.b	s1,s1
    1910:	ff3496e3          	bne	s1,s3,18fc <createdelete+0x1ac>
  for (i = 0; i < N; i++) {
    1914:	2905                	addiw	s2,s2,1
    1916:	0ff97913          	zext.b	s2,s2
    191a:	ff5910e3          	bne	s2,s5,18fa <createdelete+0x1aa>
}
    191e:	60ea                	ld	ra,152(sp)
    1920:	644a                	ld	s0,144(sp)
    1922:	64aa                	ld	s1,136(sp)
    1924:	690a                	ld	s2,128(sp)
    1926:	79e6                	ld	s3,120(sp)
    1928:	7a46                	ld	s4,112(sp)
    192a:	7aa6                	ld	s5,104(sp)
    192c:	7b06                	ld	s6,96(sp)
    192e:	6be6                	ld	s7,88(sp)
    1930:	6c46                	ld	s8,80(sp)
    1932:	6ca6                	ld	s9,72(sp)
    1934:	6d06                	ld	s10,64(sp)
    1936:	7de2                	ld	s11,56(sp)
    1938:	610d                	addi	sp,sp,160
    193a:	8082                	ret

000000000000193c <linkunlink>:
{
    193c:	711d                	addi	sp,sp,-96
    193e:	ec86                	sd	ra,88(sp)
    1940:	e8a2                	sd	s0,80(sp)
    1942:	e4a6                	sd	s1,72(sp)
    1944:	e0ca                	sd	s2,64(sp)
    1946:	fc4e                	sd	s3,56(sp)
    1948:	f852                	sd	s4,48(sp)
    194a:	f456                	sd	s5,40(sp)
    194c:	f05a                	sd	s6,32(sp)
    194e:	ec5e                	sd	s7,24(sp)
    1950:	e862                	sd	s8,16(sp)
    1952:	e466                	sd	s9,8(sp)
    1954:	e06a                	sd	s10,0(sp)
    1956:	1080                	addi	s0,sp,96
    1958:	84aa                	mv	s1,a0
  unlink("x");
    195a:	00004517          	auipc	a0,0x4
    195e:	1fe50513          	addi	a0,a0,510 # 5b58 <malloc+0x1a0>
    1962:	38d030ef          	jal	54ee <unlink>
  pid = fork();
    1966:	331030ef          	jal	5496 <fork>
  if (pid < 0) {
    196a:	04054663          	bltz	a0,19b6 <linkunlink+0x7a>
    196e:	8d2a                	mv	s10,a0
  unsigned int x = (pid ? 1 : 97);
    1970:	00153913          	seqz	s2,a0
    1974:	41200933          	neg	s2,s2
    1978:	06097913          	andi	s2,s2,96
    197c:	0905                	addi	s2,s2,1
    197e:	06400493          	li	s1,100
    x = x * 1103515245 + 12345;
    1982:	41c65ab7          	lui	s5,0x41c65
    1986:	e6da8a9b          	addiw	s5,s5,-403 # 41c64e6d <base+0x41c55185>
    198a:	6a0d                	lui	s4,0x3
    198c:	039a0a1b          	addiw	s4,s4,57 # 3039 <subdir+0x4b3>
    if ((x % 3) == 0) {
    1990:	000ab9b7          	lui	s3,0xab
    1994:	aab98993          	addi	s3,s3,-1365 # aaaab <base+0x9adc3>
    1998:	09b2                	slli	s3,s3,0xc
    199a:	aab98993          	addi	s3,s3,-1365
    } else if ((x % 3) == 1) {
    199e:	4b85                	li	s7,1
      unlink("x");
    19a0:	00004b17          	auipc	s6,0x4
    19a4:	1b8b0b13          	addi	s6,s6,440 # 5b58 <malloc+0x1a0>
      link("cat", "x");
    19a8:	00005c97          	auipc	s9,0x5
    19ac:	bc0c8c93          	addi	s9,s9,-1088 # 6568 <malloc+0xbb0>
      close(open("x", O_RDWR | O_CREATE));
    19b0:	20200c13          	li	s8,514
    19b4:	a03d                	j	19e2 <linkunlink+0xa6>
    printf("%s: fork failed\n", s);
    19b6:	85a6                	mv	a1,s1
    19b8:	00005517          	auipc	a0,0x5
    19bc:	9c050513          	addi	a0,a0,-1600 # 6378 <malloc+0x9c0>
    19c0:	73d030ef          	jal	58fc <printf>
    exit(1);
    19c4:	4505                	li	a0,1
    19c6:	2d9030ef          	jal	549e <exit>
      close(open("x", O_RDWR | O_CREATE));
    19ca:	85e2                	mv	a1,s8
    19cc:	855a                	mv	a0,s6
    19ce:	311030ef          	jal	54de <open>
    19d2:	2f5030ef          	jal	54c6 <close>
    19d6:	a021                	j	19de <linkunlink+0xa2>
      unlink("x");
    19d8:	855a                	mv	a0,s6
    19da:	315030ef          	jal	54ee <unlink>
  for (i = 0; i < 100; i++) {
    19de:	34fd                	addiw	s1,s1,-1
    19e0:	c885                	beqz	s1,1a10 <linkunlink+0xd4>
    x = x * 1103515245 + 12345;
    19e2:	035907bb          	mulw	a5,s2,s5
    19e6:	00fa07bb          	addw	a5,s4,a5
    19ea:	893e                	mv	s2,a5
    if ((x % 3) == 0) {
    19ec:	02079713          	slli	a4,a5,0x20
    19f0:	9301                	srli	a4,a4,0x20
    19f2:	03370733          	mul	a4,a4,s3
    19f6:	9305                	srli	a4,a4,0x21
    19f8:	0017169b          	slliw	a3,a4,0x1
    19fc:	9f35                	addw	a4,a4,a3
    19fe:	9f99                	subw	a5,a5,a4
    1a00:	d7e9                	beqz	a5,19ca <linkunlink+0x8e>
    } else if ((x % 3) == 1) {
    1a02:	fd779be3          	bne	a5,s7,19d8 <linkunlink+0x9c>
      link("cat", "x");
    1a06:	85da                	mv	a1,s6
    1a08:	8566                	mv	a0,s9
    1a0a:	2f5030ef          	jal	54fe <link>
    1a0e:	bfc1                	j	19de <linkunlink+0xa2>
  if (pid)
    1a10:	020d0363          	beqz	s10,1a36 <linkunlink+0xfa>
    wait(0);
    1a14:	4501                	li	a0,0
    1a16:	291030ef          	jal	54a6 <wait>
}
    1a1a:	60e6                	ld	ra,88(sp)
    1a1c:	6446                	ld	s0,80(sp)
    1a1e:	64a6                	ld	s1,72(sp)
    1a20:	6906                	ld	s2,64(sp)
    1a22:	79e2                	ld	s3,56(sp)
    1a24:	7a42                	ld	s4,48(sp)
    1a26:	7aa2                	ld	s5,40(sp)
    1a28:	7b02                	ld	s6,32(sp)
    1a2a:	6be2                	ld	s7,24(sp)
    1a2c:	6c42                	ld	s8,16(sp)
    1a2e:	6ca2                	ld	s9,8(sp)
    1a30:	6d02                	ld	s10,0(sp)
    1a32:	6125                	addi	sp,sp,96
    1a34:	8082                	ret
    exit(0);
    1a36:	4501                	li	a0,0
    1a38:	267030ef          	jal	549e <exit>

0000000000001a3c <forktest>:
{
    1a3c:	7179                	addi	sp,sp,-48
    1a3e:	f406                	sd	ra,40(sp)
    1a40:	f022                	sd	s0,32(sp)
    1a42:	ec26                	sd	s1,24(sp)
    1a44:	e84a                	sd	s2,16(sp)
    1a46:	e44e                	sd	s3,8(sp)
    1a48:	1800                	addi	s0,sp,48
    1a4a:	89aa                	mv	s3,a0
  for (n = 0; n < N; n++) {
    1a4c:	4481                	li	s1,0
    1a4e:	3e800913          	li	s2,1000
    pid = fork();
    1a52:	245030ef          	jal	5496 <fork>
    if (pid < 0)
    1a56:	06054063          	bltz	a0,1ab6 <forktest+0x7a>
    if (pid == 0)
    1a5a:	cd11                	beqz	a0,1a76 <forktest+0x3a>
  for (n = 0; n < N; n++) {
    1a5c:	2485                	addiw	s1,s1,1
    1a5e:	ff249ae3          	bne	s1,s2,1a52 <forktest+0x16>
    printf("%s: fork claimed to work 1000 times!\n", s);
    1a62:	85ce                	mv	a1,s3
    1a64:	00005517          	auipc	a0,0x5
    1a68:	b5450513          	addi	a0,a0,-1196 # 65b8 <malloc+0xc00>
    1a6c:	691030ef          	jal	58fc <printf>
    exit(1);
    1a70:	4505                	li	a0,1
    1a72:	22d030ef          	jal	549e <exit>
      exit(0);
    1a76:	229030ef          	jal	549e <exit>
    printf("%s: no fork at all!\n", s);
    1a7a:	85ce                	mv	a1,s3
    1a7c:	00005517          	auipc	a0,0x5
    1a80:	af450513          	addi	a0,a0,-1292 # 6570 <malloc+0xbb8>
    1a84:	679030ef          	jal	58fc <printf>
    exit(1);
    1a88:	4505                	li	a0,1
    1a8a:	215030ef          	jal	549e <exit>
      printf("%s: wait stopped early\n", s);
    1a8e:	85ce                	mv	a1,s3
    1a90:	00005517          	auipc	a0,0x5
    1a94:	af850513          	addi	a0,a0,-1288 # 6588 <malloc+0xbd0>
    1a98:	665030ef          	jal	58fc <printf>
      exit(1);
    1a9c:	4505                	li	a0,1
    1a9e:	201030ef          	jal	549e <exit>
    printf("%s: wait got too many\n", s);
    1aa2:	85ce                	mv	a1,s3
    1aa4:	00005517          	auipc	a0,0x5
    1aa8:	afc50513          	addi	a0,a0,-1284 # 65a0 <malloc+0xbe8>
    1aac:	651030ef          	jal	58fc <printf>
    exit(1);
    1ab0:	4505                	li	a0,1
    1ab2:	1ed030ef          	jal	549e <exit>
  if (n == 0) {
    1ab6:	d0f1                	beqz	s1,1a7a <forktest+0x3e>
  for (; n > 0; n--) {
    1ab8:	00905963          	blez	s1,1aca <forktest+0x8e>
    if (wait(0) < 0) {
    1abc:	4501                	li	a0,0
    1abe:	1e9030ef          	jal	54a6 <wait>
    1ac2:	fc0546e3          	bltz	a0,1a8e <forktest+0x52>
  for (; n > 0; n--) {
    1ac6:	34fd                	addiw	s1,s1,-1
    1ac8:	f8f5                	bnez	s1,1abc <forktest+0x80>
  if (wait(0) != -1) {
    1aca:	4501                	li	a0,0
    1acc:	1db030ef          	jal	54a6 <wait>
    1ad0:	57fd                	li	a5,-1
    1ad2:	fcf518e3          	bne	a0,a5,1aa2 <forktest+0x66>
}
    1ad6:	70a2                	ld	ra,40(sp)
    1ad8:	7402                	ld	s0,32(sp)
    1ada:	64e2                	ld	s1,24(sp)
    1adc:	6942                	ld	s2,16(sp)
    1ade:	69a2                	ld	s3,8(sp)
    1ae0:	6145                	addi	sp,sp,48
    1ae2:	8082                	ret

0000000000001ae4 <kernmem>:
{
    1ae4:	715d                	addi	sp,sp,-80
    1ae6:	e486                	sd	ra,72(sp)
    1ae8:	e0a2                	sd	s0,64(sp)
    1aea:	fc26                	sd	s1,56(sp)
    1aec:	f84a                	sd	s2,48(sp)
    1aee:	f44e                	sd	s3,40(sp)
    1af0:	f052                	sd	s4,32(sp)
    1af2:	ec56                	sd	s5,24(sp)
    1af4:	e85a                	sd	s6,16(sp)
    1af6:	0880                	addi	s0,sp,80
    1af8:	8b2a                	mv	s6,a0
  for (a = (char *)(KERNBASE); a < (char *)(KERNBASE + 2000000); a += 50000) {
    1afa:	4485                	li	s1,1
    1afc:	04fe                	slli	s1,s1,0x1f
    wait(&xstatus);
    1afe:	fbc40a93          	addi	s5,s0,-68
    if (xstatus != -1) // did kernel kill child?
    1b02:	5a7d                	li	s4,-1
  for (a = (char *)(KERNBASE); a < (char *)(KERNBASE + 2000000); a += 50000) {
    1b04:	69b1                	lui	s3,0xc
    1b06:	35098993          	addi	s3,s3,848 # c350 <uninit+0x1d78>
    1b0a:	1003d937          	lui	s2,0x1003d
    1b0e:	090e                	slli	s2,s2,0x3
    1b10:	48090913          	addi	s2,s2,1152 # 1003d480 <base+0x1002d798>
    pid = fork();
    1b14:	183030ef          	jal	5496 <fork>
    if (pid < 0) {
    1b18:	02054763          	bltz	a0,1b46 <kernmem+0x62>
    if (pid == 0) {
    1b1c:	cd1d                	beqz	a0,1b5a <kernmem+0x76>
    wait(&xstatus);
    1b1e:	8556                	mv	a0,s5
    1b20:	187030ef          	jal	54a6 <wait>
    if (xstatus != -1) // did kernel kill child?
    1b24:	fbc42783          	lw	a5,-68(s0)
    1b28:	05479663          	bne	a5,s4,1b74 <kernmem+0x90>
  for (a = (char *)(KERNBASE); a < (char *)(KERNBASE + 2000000); a += 50000) {
    1b2c:	94ce                	add	s1,s1,s3
    1b2e:	ff2493e3          	bne	s1,s2,1b14 <kernmem+0x30>
}
    1b32:	60a6                	ld	ra,72(sp)
    1b34:	6406                	ld	s0,64(sp)
    1b36:	74e2                	ld	s1,56(sp)
    1b38:	7942                	ld	s2,48(sp)
    1b3a:	79a2                	ld	s3,40(sp)
    1b3c:	7a02                	ld	s4,32(sp)
    1b3e:	6ae2                	ld	s5,24(sp)
    1b40:	6b42                	ld	s6,16(sp)
    1b42:	6161                	addi	sp,sp,80
    1b44:	8082                	ret
      printf("%s: fork failed\n", s);
    1b46:	85da                	mv	a1,s6
    1b48:	00005517          	auipc	a0,0x5
    1b4c:	83050513          	addi	a0,a0,-2000 # 6378 <malloc+0x9c0>
    1b50:	5ad030ef          	jal	58fc <printf>
      exit(1);
    1b54:	4505                	li	a0,1
    1b56:	149030ef          	jal	549e <exit>
      printf("%s: oops could read %p = %x\n", s, a, *a);
    1b5a:	0004c683          	lbu	a3,0(s1)
    1b5e:	8626                	mv	a2,s1
    1b60:	85da                	mv	a1,s6
    1b62:	00005517          	auipc	a0,0x5
    1b66:	a7e50513          	addi	a0,a0,-1410 # 65e0 <malloc+0xc28>
    1b6a:	593030ef          	jal	58fc <printf>
      exit(1);
    1b6e:	4505                	li	a0,1
    1b70:	12f030ef          	jal	549e <exit>
      exit(1);
    1b74:	4505                	li	a0,1
    1b76:	129030ef          	jal	549e <exit>

0000000000001b7a <MAXVAplus>:
{
    1b7a:	7139                	addi	sp,sp,-64
    1b7c:	fc06                	sd	ra,56(sp)
    1b7e:	f822                	sd	s0,48(sp)
    1b80:	0080                	addi	s0,sp,64
  volatile uint64 a = MAXVA;
    1b82:	4785                	li	a5,1
    1b84:	179a                	slli	a5,a5,0x26
    1b86:	fcf43423          	sd	a5,-56(s0)
  for (; a != 0; a <<= 1) {
    1b8a:	fc843783          	ld	a5,-56(s0)
    1b8e:	cf9d                	beqz	a5,1bcc <MAXVAplus+0x52>
    1b90:	f426                	sd	s1,40(sp)
    1b92:	f04a                	sd	s2,32(sp)
    1b94:	ec4e                	sd	s3,24(sp)
    1b96:	89aa                	mv	s3,a0
    wait(&xstatus);
    1b98:	fc440913          	addi	s2,s0,-60
    if (xstatus != -1) // did kernel kill child?
    1b9c:	54fd                	li	s1,-1
    pid = fork();
    1b9e:	0f9030ef          	jal	5496 <fork>
    if (pid < 0) {
    1ba2:	02054963          	bltz	a0,1bd4 <MAXVAplus+0x5a>
    if (pid == 0) {
    1ba6:	c129                	beqz	a0,1be8 <MAXVAplus+0x6e>
    wait(&xstatus);
    1ba8:	854a                	mv	a0,s2
    1baa:	0fd030ef          	jal	54a6 <wait>
    if (xstatus != -1) // did kernel kill child?
    1bae:	fc442783          	lw	a5,-60(s0)
    1bb2:	04979d63          	bne	a5,s1,1c0c <MAXVAplus+0x92>
  for (; a != 0; a <<= 1) {
    1bb6:	fc843783          	ld	a5,-56(s0)
    1bba:	0786                	slli	a5,a5,0x1
    1bbc:	fcf43423          	sd	a5,-56(s0)
    1bc0:	fc843783          	ld	a5,-56(s0)
    1bc4:	ffe9                	bnez	a5,1b9e <MAXVAplus+0x24>
    1bc6:	74a2                	ld	s1,40(sp)
    1bc8:	7902                	ld	s2,32(sp)
    1bca:	69e2                	ld	s3,24(sp)
}
    1bcc:	70e2                	ld	ra,56(sp)
    1bce:	7442                	ld	s0,48(sp)
    1bd0:	6121                	addi	sp,sp,64
    1bd2:	8082                	ret
      printf("%s: fork failed\n", s);
    1bd4:	85ce                	mv	a1,s3
    1bd6:	00004517          	auipc	a0,0x4
    1bda:	7a250513          	addi	a0,a0,1954 # 6378 <malloc+0x9c0>
    1bde:	51f030ef          	jal	58fc <printf>
      exit(1);
    1be2:	4505                	li	a0,1
    1be4:	0bb030ef          	jal	549e <exit>
      *(char *)a = 99;
    1be8:	fc843783          	ld	a5,-56(s0)
    1bec:	06300713          	li	a4,99
    1bf0:	00e78023          	sb	a4,0(a5)
      printf("%s: oops wrote %p\n", s, (void *)a);
    1bf4:	fc843603          	ld	a2,-56(s0)
    1bf8:	85ce                	mv	a1,s3
    1bfa:	00005517          	auipc	a0,0x5
    1bfe:	a0650513          	addi	a0,a0,-1530 # 6600 <malloc+0xc48>
    1c02:	4fb030ef          	jal	58fc <printf>
      exit(1);
    1c06:	4505                	li	a0,1
    1c08:	097030ef          	jal	549e <exit>
      exit(1);
    1c0c:	4505                	li	a0,1
    1c0e:	091030ef          	jal	549e <exit>

0000000000001c12 <stacktest>:
{
    1c12:	7179                	addi	sp,sp,-48
    1c14:	f406                	sd	ra,40(sp)
    1c16:	f022                	sd	s0,32(sp)
    1c18:	ec26                	sd	s1,24(sp)
    1c1a:	1800                	addi	s0,sp,48
    1c1c:	84aa                	mv	s1,a0
  pid = fork();
    1c1e:	079030ef          	jal	5496 <fork>
  if (pid == 0) {
    1c22:	cd11                	beqz	a0,1c3e <stacktest+0x2c>
  } else if (pid < 0) {
    1c24:	02054c63          	bltz	a0,1c5c <stacktest+0x4a>
  wait(&xstatus);
    1c28:	fdc40513          	addi	a0,s0,-36
    1c2c:	07b030ef          	jal	54a6 <wait>
  if (xstatus == -1) // kernel killed child?
    1c30:	fdc42503          	lw	a0,-36(s0)
    1c34:	57fd                	li	a5,-1
    1c36:	02f50d63          	beq	a0,a5,1c70 <stacktest+0x5e>
    exit(xstatus);
    1c3a:	065030ef          	jal	549e <exit>

static inline uint64
r_sp()
{
  uint64 x;
  asm volatile("mv %0, sp" : "=r"(x));
    1c3e:	870a                	mv	a4,sp
    printf("%s: stacktest: read below stack %d\n", s, *sp);
    1c40:	77fd                	lui	a5,0xfffff
    1c42:	97ba                	add	a5,a5,a4
    1c44:	0007c603          	lbu	a2,0(a5) # fffffffffffff000 <base+0xfffffffffffef318>
    1c48:	85a6                	mv	a1,s1
    1c4a:	00005517          	auipc	a0,0x5
    1c4e:	9ce50513          	addi	a0,a0,-1586 # 6618 <malloc+0xc60>
    1c52:	4ab030ef          	jal	58fc <printf>
    exit(1);
    1c56:	4505                	li	a0,1
    1c58:	047030ef          	jal	549e <exit>
    printf("%s: fork failed\n", s);
    1c5c:	85a6                	mv	a1,s1
    1c5e:	00004517          	auipc	a0,0x4
    1c62:	71a50513          	addi	a0,a0,1818 # 6378 <malloc+0x9c0>
    1c66:	497030ef          	jal	58fc <printf>
    exit(1);
    1c6a:	4505                	li	a0,1
    1c6c:	033030ef          	jal	549e <exit>
    exit(0);
    1c70:	4501                	li	a0,0
    1c72:	02d030ef          	jal	549e <exit>

0000000000001c76 <nowrite>:
{
    1c76:	7159                	addi	sp,sp,-112
    1c78:	f486                	sd	ra,104(sp)
    1c7a:	f0a2                	sd	s0,96(sp)
    1c7c:	eca6                	sd	s1,88(sp)
    1c7e:	e8ca                	sd	s2,80(sp)
    1c80:	e4ce                	sd	s3,72(sp)
    1c82:	e0d2                	sd	s4,64(sp)
    1c84:	1880                	addi	s0,sp,112
    1c86:	8a2a                	mv	s4,a0
  uint64 addrs[] = {0,
    1c88:	00006797          	auipc	a5,0x6
    1c8c:	66078793          	addi	a5,a5,1632 # 82e8 <malloc+0x2930>
    1c90:	7788                	ld	a0,40(a5)
    1c92:	7b8c                	ld	a1,48(a5)
    1c94:	7f90                	ld	a2,56(a5)
    1c96:	63b4                	ld	a3,64(a5)
    1c98:	67b8                	ld	a4,72(a5)
    1c9a:	f8a43c23          	sd	a0,-104(s0)
    1c9e:	fab43023          	sd	a1,-96(s0)
    1ca2:	fac43423          	sd	a2,-88(s0)
    1ca6:	fad43823          	sd	a3,-80(s0)
    1caa:	fae43c23          	sd	a4,-72(s0)
    1cae:	6bbc                	ld	a5,80(a5)
    1cb0:	fcf43023          	sd	a5,-64(s0)
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
    1cb4:	4481                	li	s1,0
    wait(&xstatus);
    1cb6:	fcc40913          	addi	s2,s0,-52
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
    1cba:	4999                	li	s3,6
    pid = fork();
    1cbc:	7da030ef          	jal	5496 <fork>
    if (pid == 0) {
    1cc0:	cd19                	beqz	a0,1cde <nowrite+0x68>
    } else if (pid < 0) {
    1cc2:	04054063          	bltz	a0,1d02 <nowrite+0x8c>
    wait(&xstatus);
    1cc6:	854a                	mv	a0,s2
    1cc8:	7de030ef          	jal	54a6 <wait>
    if (xstatus == 0) {
    1ccc:	fcc42783          	lw	a5,-52(s0)
    1cd0:	c3b9                	beqz	a5,1d16 <nowrite+0xa0>
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
    1cd2:	2485                	addiw	s1,s1,1
    1cd4:	ff3494e3          	bne	s1,s3,1cbc <nowrite+0x46>
  exit(0);
    1cd8:	4501                	li	a0,0
    1cda:	7c4030ef          	jal	549e <exit>
      volatile int *addr = (int *)addrs[ai];
    1cde:	048e                	slli	s1,s1,0x3
    1ce0:	fd040793          	addi	a5,s0,-48
    1ce4:	94be                	add	s1,s1,a5
    1ce6:	fc84b603          	ld	a2,-56(s1)
      *addr = 10;
    1cea:	47a9                	li	a5,10
    1cec:	c21c                	sw	a5,0(a2)
      printf("%s: write to %p did not fail!\n", s, addr);
    1cee:	85d2                	mv	a1,s4
    1cf0:	00005517          	auipc	a0,0x5
    1cf4:	95050513          	addi	a0,a0,-1712 # 6640 <malloc+0xc88>
    1cf8:	405030ef          	jal	58fc <printf>
      exit(0);
    1cfc:	4501                	li	a0,0
    1cfe:	7a0030ef          	jal	549e <exit>
      printf("%s: fork failed\n", s);
    1d02:	85d2                	mv	a1,s4
    1d04:	00004517          	auipc	a0,0x4
    1d08:	67450513          	addi	a0,a0,1652 # 6378 <malloc+0x9c0>
    1d0c:	3f1030ef          	jal	58fc <printf>
      exit(1);
    1d10:	4505                	li	a0,1
    1d12:	78c030ef          	jal	549e <exit>
      exit(1);
    1d16:	4505                	li	a0,1
    1d18:	786030ef          	jal	549e <exit>

0000000000001d1c <manywrites>:
{
    1d1c:	7159                	addi	sp,sp,-112
    1d1e:	f486                	sd	ra,104(sp)
    1d20:	f0a2                	sd	s0,96(sp)
    1d22:	eca6                	sd	s1,88(sp)
    1d24:	e8ca                	sd	s2,80(sp)
    1d26:	e4ce                	sd	s3,72(sp)
    1d28:	ec66                	sd	s9,24(sp)
    1d2a:	1880                	addi	s0,sp,112
    1d2c:	8caa                	mv	s9,a0
  for (int ci = 0; ci < nchildren; ci++) {
    1d2e:	4901                	li	s2,0
    1d30:	4991                	li	s3,4
    int pid = fork();
    1d32:	764030ef          	jal	5496 <fork>
    1d36:	84aa                	mv	s1,a0
    if (pid < 0) {
    1d38:	02054c63          	bltz	a0,1d70 <manywrites+0x54>
    if (pid == 0) {
    1d3c:	c929                	beqz	a0,1d8e <manywrites+0x72>
  for (int ci = 0; ci < nchildren; ci++) {
    1d3e:	2905                	addiw	s2,s2,1
    1d40:	ff3919e3          	bne	s2,s3,1d32 <manywrites+0x16>
    1d44:	4491                	li	s1,4
    wait(&st);
    1d46:	f9840913          	addi	s2,s0,-104
    int st = 0;
    1d4a:	f8042c23          	sw	zero,-104(s0)
    wait(&st);
    1d4e:	854a                	mv	a0,s2
    1d50:	756030ef          	jal	54a6 <wait>
    if (st != 0)
    1d54:	f9842503          	lw	a0,-104(s0)
    1d58:	0e051763          	bnez	a0,1e46 <manywrites+0x12a>
  for (int ci = 0; ci < nchildren; ci++) {
    1d5c:	34fd                	addiw	s1,s1,-1
    1d5e:	f4f5                	bnez	s1,1d4a <manywrites+0x2e>
    1d60:	e0d2                	sd	s4,64(sp)
    1d62:	fc56                	sd	s5,56(sp)
    1d64:	f85a                	sd	s6,48(sp)
    1d66:	f45e                	sd	s7,40(sp)
    1d68:	f062                	sd	s8,32(sp)
    1d6a:	e86a                	sd	s10,16(sp)
  exit(0);
    1d6c:	732030ef          	jal	549e <exit>
    1d70:	e0d2                	sd	s4,64(sp)
    1d72:	fc56                	sd	s5,56(sp)
    1d74:	f85a                	sd	s6,48(sp)
    1d76:	f45e                	sd	s7,40(sp)
    1d78:	f062                	sd	s8,32(sp)
    1d7a:	e86a                	sd	s10,16(sp)
      printf("fork failed\n");
    1d7c:	00006517          	auipc	a0,0x6
    1d80:	cbc50513          	addi	a0,a0,-836 # 7a38 <malloc+0x2080>
    1d84:	379030ef          	jal	58fc <printf>
      exit(1);
    1d88:	4505                	li	a0,1
    1d8a:	714030ef          	jal	549e <exit>
    1d8e:	e0d2                	sd	s4,64(sp)
    1d90:	fc56                	sd	s5,56(sp)
    1d92:	f85a                	sd	s6,48(sp)
    1d94:	f45e                	sd	s7,40(sp)
    1d96:	f062                	sd	s8,32(sp)
    1d98:	e86a                	sd	s10,16(sp)
      name[0] = 'b';
    1d9a:	06200793          	li	a5,98
    1d9e:	f8f40c23          	sb	a5,-104(s0)
      name[1] = 'a' + ci;
    1da2:	0619079b          	addiw	a5,s2,97
    1da6:	f8f40ca3          	sb	a5,-103(s0)
      name[2] = '\0';
    1daa:	f8040d23          	sb	zero,-102(s0)
      unlink(name);
    1dae:	f9840513          	addi	a0,s0,-104
    1db2:	73c030ef          	jal	54ee <unlink>
    1db6:	47f9                	li	a5,30
    1db8:	8d3e                	mv	s10,a5
          int fd = open(name, O_CREATE | O_RDWR);
    1dba:	f9840b93          	addi	s7,s0,-104
    1dbe:	20200b13          	li	s6,514
          int cc = write(fd, buf, sz);
    1dc2:	6a8d                	lui	s5,0x3
    1dc4:	0000bc17          	auipc	s8,0xb
    1dc8:	f24c0c13          	addi	s8,s8,-220 # cce8 <buf>
        for (int i = 0; i < ci + 1; i++) {
    1dcc:	8a26                	mv	s4,s1
    1dce:	02094563          	bltz	s2,1df8 <manywrites+0xdc>
          int fd = open(name, O_CREATE | O_RDWR);
    1dd2:	85da                	mv	a1,s6
    1dd4:	855e                	mv	a0,s7
    1dd6:	708030ef          	jal	54de <open>
    1dda:	89aa                	mv	s3,a0
          if (fd < 0) {
    1ddc:	02054d63          	bltz	a0,1e16 <manywrites+0xfa>
          int cc = write(fd, buf, sz);
    1de0:	8656                	mv	a2,s5
    1de2:	85e2                	mv	a1,s8
    1de4:	6da030ef          	jal	54be <write>
          if (cc != sz) {
    1de8:	05551363          	bne	a0,s5,1e2e <manywrites+0x112>
          close(fd);
    1dec:	854e                	mv	a0,s3
    1dee:	6d8030ef          	jal	54c6 <close>
        for (int i = 0; i < ci + 1; i++) {
    1df2:	2a05                	addiw	s4,s4,1
    1df4:	fd495fe3          	bge	s2,s4,1dd2 <manywrites+0xb6>
        unlink(name);
    1df8:	f9840513          	addi	a0,s0,-104
    1dfc:	6f2030ef          	jal	54ee <unlink>
      for (int iters = 0; iters < howmany; iters++) {
    1e00:	fffd079b          	addiw	a5,s10,-1
    1e04:	8d3e                	mv	s10,a5
    1e06:	f3f9                	bnez	a5,1dcc <manywrites+0xb0>
      unlink(name);
    1e08:	f9840513          	addi	a0,s0,-104
    1e0c:	6e2030ef          	jal	54ee <unlink>
      exit(0);
    1e10:	4501                	li	a0,0
    1e12:	68c030ef          	jal	549e <exit>
            printf("%s: cannot create %s\n", s, name);
    1e16:	f9840613          	addi	a2,s0,-104
    1e1a:	85e6                	mv	a1,s9
    1e1c:	00005517          	auipc	a0,0x5
    1e20:	84450513          	addi	a0,a0,-1980 # 6660 <malloc+0xca8>
    1e24:	2d9030ef          	jal	58fc <printf>
            exit(1);
    1e28:	4505                	li	a0,1
    1e2a:	674030ef          	jal	549e <exit>
            printf("%s: write(%d) ret %d\n", s, sz, cc);
    1e2e:	86aa                	mv	a3,a0
    1e30:	660d                	lui	a2,0x3
    1e32:	85e6                	mv	a1,s9
    1e34:	00004517          	auipc	a0,0x4
    1e38:	d8450513          	addi	a0,a0,-636 # 5bb8 <malloc+0x200>
    1e3c:	2c1030ef          	jal	58fc <printf>
            exit(1);
    1e40:	4505                	li	a0,1
    1e42:	65c030ef          	jal	549e <exit>
    1e46:	e0d2                	sd	s4,64(sp)
    1e48:	fc56                	sd	s5,56(sp)
    1e4a:	f85a                	sd	s6,48(sp)
    1e4c:	f45e                	sd	s7,40(sp)
    1e4e:	f062                	sd	s8,32(sp)
    1e50:	e86a                	sd	s10,16(sp)
      exit(st);
    1e52:	64c030ef          	jal	549e <exit>

0000000000001e56 <copyinstr3>:
{
    1e56:	7179                	addi	sp,sp,-48
    1e58:	f406                	sd	ra,40(sp)
    1e5a:	f022                	sd	s0,32(sp)
    1e5c:	ec26                	sd	s1,24(sp)
    1e5e:	1800                	addi	s0,sp,48
  sbrk(8192);
    1e60:	6509                	lui	a0,0x2
    1e62:	608030ef          	jal	546a <sbrk>
  uint64 top = (uint64)sbrk(0);
    1e66:	4501                	li	a0,0
    1e68:	602030ef          	jal	546a <sbrk>
  if ((top % PGSIZE) != 0) {
    1e6c:	03451793          	slli	a5,a0,0x34
    1e70:	e7bd                	bnez	a5,1ede <copyinstr3+0x88>
  top = (uint64)sbrk(0);
    1e72:	4501                	li	a0,0
    1e74:	5f6030ef          	jal	546a <sbrk>
  if (top % PGSIZE) {
    1e78:	03451793          	slli	a5,a0,0x34
    1e7c:	ebad                	bnez	a5,1eee <copyinstr3+0x98>
  char *b = (char *)(top - 1);
    1e7e:	fff50493          	addi	s1,a0,-1 # 1fff <rwsbrk+0xa5>
  *b = 'x';
    1e82:	07800793          	li	a5,120
    1e86:	fef50fa3          	sb	a5,-1(a0)
  int ret = unlink(b);
    1e8a:	8526                	mv	a0,s1
    1e8c:	662030ef          	jal	54ee <unlink>
  if (ret != -1) {
    1e90:	57fd                	li	a5,-1
    1e92:	06f51763          	bne	a0,a5,1f00 <copyinstr3+0xaa>
  int fd = open(b, O_CREATE | O_WRONLY);
    1e96:	20100593          	li	a1,513
    1e9a:	8526                	mv	a0,s1
    1e9c:	642030ef          	jal	54de <open>
  if (fd != -1) {
    1ea0:	57fd                	li	a5,-1
    1ea2:	06f51a63          	bne	a0,a5,1f16 <copyinstr3+0xc0>
  ret = link(b, b);
    1ea6:	85a6                	mv	a1,s1
    1ea8:	8526                	mv	a0,s1
    1eaa:	654030ef          	jal	54fe <link>
  if (ret != -1) {
    1eae:	57fd                	li	a5,-1
    1eb0:	06f51e63          	bne	a0,a5,1f2c <copyinstr3+0xd6>
  char *args[] = {"xx", 0};
    1eb4:	00005797          	auipc	a5,0x5
    1eb8:	4ac78793          	addi	a5,a5,1196 # 7360 <malloc+0x19a8>
    1ebc:	fcf43823          	sd	a5,-48(s0)
    1ec0:	fc043c23          	sd	zero,-40(s0)
  ret = exec(b, args);
    1ec4:	fd040593          	addi	a1,s0,-48
    1ec8:	8526                	mv	a0,s1
    1eca:	60c030ef          	jal	54d6 <exec>
  if (ret != -1) {
    1ece:	57fd                	li	a5,-1
    1ed0:	06f51a63          	bne	a0,a5,1f44 <copyinstr3+0xee>
}
    1ed4:	70a2                	ld	ra,40(sp)
    1ed6:	7402                	ld	s0,32(sp)
    1ed8:	64e2                	ld	s1,24(sp)
    1eda:	6145                	addi	sp,sp,48
    1edc:	8082                	ret
    sbrk(PGSIZE - (top % PGSIZE));
    1ede:	0347d513          	srli	a0,a5,0x34
    1ee2:	6785                	lui	a5,0x1
    1ee4:	40a7853b          	subw	a0,a5,a0
    1ee8:	582030ef          	jal	546a <sbrk>
    1eec:	b759                	j	1e72 <copyinstr3+0x1c>
    printf("oops\n");
    1eee:	00004517          	auipc	a0,0x4
    1ef2:	78a50513          	addi	a0,a0,1930 # 6678 <malloc+0xcc0>
    1ef6:	207030ef          	jal	58fc <printf>
    exit(1);
    1efa:	4505                	li	a0,1
    1efc:	5a2030ef          	jal	549e <exit>
    printf("unlink(%s) returned %d, not -1\n", b, ret);
    1f00:	862a                	mv	a2,a0
    1f02:	85a6                	mv	a1,s1
    1f04:	00004517          	auipc	a0,0x4
    1f08:	39450513          	addi	a0,a0,916 # 6298 <malloc+0x8e0>
    1f0c:	1f1030ef          	jal	58fc <printf>
    exit(1);
    1f10:	4505                	li	a0,1
    1f12:	58c030ef          	jal	549e <exit>
    printf("open(%s) returned %d, not -1\n", b, fd);
    1f16:	862a                	mv	a2,a0
    1f18:	85a6                	mv	a1,s1
    1f1a:	00004517          	auipc	a0,0x4
    1f1e:	39e50513          	addi	a0,a0,926 # 62b8 <malloc+0x900>
    1f22:	1db030ef          	jal	58fc <printf>
    exit(1);
    1f26:	4505                	li	a0,1
    1f28:	576030ef          	jal	549e <exit>
    printf("link(%s, %s) returned %d, not -1\n", b, b, ret);
    1f2c:	86aa                	mv	a3,a0
    1f2e:	8626                	mv	a2,s1
    1f30:	85a6                	mv	a1,s1
    1f32:	00004517          	auipc	a0,0x4
    1f36:	3a650513          	addi	a0,a0,934 # 62d8 <malloc+0x920>
    1f3a:	1c3030ef          	jal	58fc <printf>
    exit(1);
    1f3e:	4505                	li	a0,1
    1f40:	55e030ef          	jal	549e <exit>
    printf("exec(%s) returned %d, not -1\n", b, fd);
    1f44:	863e                	mv	a2,a5
    1f46:	85a6                	mv	a1,s1
    1f48:	00004517          	auipc	a0,0x4
    1f4c:	3b850513          	addi	a0,a0,952 # 6300 <malloc+0x948>
    1f50:	1ad030ef          	jal	58fc <printf>
    exit(1);
    1f54:	4505                	li	a0,1
    1f56:	548030ef          	jal	549e <exit>

0000000000001f5a <rwsbrk>:
{
    1f5a:	1101                	addi	sp,sp,-32
    1f5c:	ec06                	sd	ra,24(sp)
    1f5e:	e822                	sd	s0,16(sp)
    1f60:	1000                	addi	s0,sp,32
  uint64 a = (uint64)sbrk(8192);
    1f62:	6509                	lui	a0,0x2
    1f64:	506030ef          	jal	546a <sbrk>
  if (a == (uint64)SBRK_ERROR) {
    1f68:	57fd                	li	a5,-1
    1f6a:	04f50a63          	beq	a0,a5,1fbe <rwsbrk+0x64>
    1f6e:	e426                	sd	s1,8(sp)
    1f70:	84aa                	mv	s1,a0
  if (sbrk(-8192) == SBRK_ERROR) {
    1f72:	7579                	lui	a0,0xffffe
    1f74:	4f6030ef          	jal	546a <sbrk>
    1f78:	57fd                	li	a5,-1
    1f7a:	04f50d63          	beq	a0,a5,1fd4 <rwsbrk+0x7a>
    1f7e:	e04a                	sd	s2,0(sp)
  fd = open("rwsbrk", O_CREATE | O_WRONLY);
    1f80:	20100593          	li	a1,513
    1f84:	00004517          	auipc	a0,0x4
    1f88:	73450513          	addi	a0,a0,1844 # 66b8 <malloc+0xd00>
    1f8c:	552030ef          	jal	54de <open>
    1f90:	892a                	mv	s2,a0
  if (fd < 0) {
    1f92:	04054b63          	bltz	a0,1fe8 <rwsbrk+0x8e>
  n = write(fd, (void *)(a + PGSIZE), 1024);
    1f96:	6785                	lui	a5,0x1
    1f98:	94be                	add	s1,s1,a5
    1f9a:	40000613          	li	a2,1024
    1f9e:	85a6                	mv	a1,s1
    1fa0:	51e030ef          	jal	54be <write>
    1fa4:	862a                	mv	a2,a0
  if (n >= 0) {
    1fa6:	04054a63          	bltz	a0,1ffa <rwsbrk+0xa0>
    printf("write(fd, %p, 1024) returned %d, not -1\n", (void *)a + PGSIZE, n);
    1faa:	85a6                	mv	a1,s1
    1fac:	00004517          	auipc	a0,0x4
    1fb0:	72c50513          	addi	a0,a0,1836 # 66d8 <malloc+0xd20>
    1fb4:	149030ef          	jal	58fc <printf>
    exit(1);
    1fb8:	4505                	li	a0,1
    1fba:	4e4030ef          	jal	549e <exit>
    1fbe:	e426                	sd	s1,8(sp)
    1fc0:	e04a                	sd	s2,0(sp)
    printf("sbrk(rwsbrk) failed\n");
    1fc2:	00004517          	auipc	a0,0x4
    1fc6:	6be50513          	addi	a0,a0,1726 # 6680 <malloc+0xcc8>
    1fca:	133030ef          	jal	58fc <printf>
    exit(1);
    1fce:	4505                	li	a0,1
    1fd0:	4ce030ef          	jal	549e <exit>
    1fd4:	e04a                	sd	s2,0(sp)
    printf("sbrk(rwsbrk) shrink failed\n");
    1fd6:	00004517          	auipc	a0,0x4
    1fda:	6c250513          	addi	a0,a0,1730 # 6698 <malloc+0xce0>
    1fde:	11f030ef          	jal	58fc <printf>
    exit(1);
    1fe2:	4505                	li	a0,1
    1fe4:	4ba030ef          	jal	549e <exit>
    printf("open(rwsbrk) failed\n");
    1fe8:	00004517          	auipc	a0,0x4
    1fec:	6d850513          	addi	a0,a0,1752 # 66c0 <malloc+0xd08>
    1ff0:	10d030ef          	jal	58fc <printf>
    exit(1);
    1ff4:	4505                	li	a0,1
    1ff6:	4a8030ef          	jal	549e <exit>
  close(fd);
    1ffa:	854a                	mv	a0,s2
    1ffc:	4ca030ef          	jal	54c6 <close>
  unlink("rwsbrk");
    2000:	00004517          	auipc	a0,0x4
    2004:	6b850513          	addi	a0,a0,1720 # 66b8 <malloc+0xd00>
    2008:	4e6030ef          	jal	54ee <unlink>
  fd = open("README", O_RDONLY);
    200c:	4581                	li	a1,0
    200e:	00004517          	auipc	a0,0x4
    2012:	cb250513          	addi	a0,a0,-846 # 5cc0 <malloc+0x308>
    2016:	4c8030ef          	jal	54de <open>
    201a:	892a                	mv	s2,a0
  if (fd < 0) {
    201c:	02054363          	bltz	a0,2042 <rwsbrk+0xe8>
  n = read(fd, (void *)(a + PGSIZE), 10);
    2020:	4629                	li	a2,10
    2022:	85a6                	mv	a1,s1
    2024:	492030ef          	jal	54b6 <read>
    2028:	862a                	mv	a2,a0
  if (n >= 0) {
    202a:	02054563          	bltz	a0,2054 <rwsbrk+0xfa>
    printf("read(fd, %p, 10) returned %d, not -1\n", (void *)a + PGSIZE, n);
    202e:	85a6                	mv	a1,s1
    2030:	00004517          	auipc	a0,0x4
    2034:	6d850513          	addi	a0,a0,1752 # 6708 <malloc+0xd50>
    2038:	0c5030ef          	jal	58fc <printf>
    exit(1);
    203c:	4505                	li	a0,1
    203e:	460030ef          	jal	549e <exit>
    printf("open(README) failed\n");
    2042:	00004517          	auipc	a0,0x4
    2046:	c8650513          	addi	a0,a0,-890 # 5cc8 <malloc+0x310>
    204a:	0b3030ef          	jal	58fc <printf>
    exit(1);
    204e:	4505                	li	a0,1
    2050:	44e030ef          	jal	549e <exit>
  close(fd);
    2054:	854a                	mv	a0,s2
    2056:	470030ef          	jal	54c6 <close>
  exit(0);
    205a:	4501                	li	a0,0
    205c:	442030ef          	jal	549e <exit>

0000000000002060 <sbrkbasic>:
{
    2060:	715d                	addi	sp,sp,-80
    2062:	e486                	sd	ra,72(sp)
    2064:	e0a2                	sd	s0,64(sp)
    2066:	ec56                	sd	s5,24(sp)
    2068:	0880                	addi	s0,sp,80
    206a:	8aaa                	mv	s5,a0
  pid = fork();
    206c:	42a030ef          	jal	5496 <fork>
  if (pid < 0) {
    2070:	02054c63          	bltz	a0,20a8 <sbrkbasic+0x48>
  if (pid == 0) {
    2074:	ed31                	bnez	a0,20d0 <sbrkbasic+0x70>
    a = sbrk(TOOMUCH);
    2076:	40000537          	lui	a0,0x40000
    207a:	3f0030ef          	jal	546a <sbrk>
    if (a == (char *)SBRK_ERROR) {
    207e:	57fd                	li	a5,-1
    2080:	04f50163          	beq	a0,a5,20c2 <sbrkbasic+0x62>
    2084:	fc26                	sd	s1,56(sp)
    2086:	f84a                	sd	s2,48(sp)
    2088:	f44e                	sd	s3,40(sp)
    208a:	f052                	sd	s4,32(sp)
    for (b = a; b < a + TOOMUCH; b += PGSIZE) {
    208c:	400007b7          	lui	a5,0x40000
    2090:	97aa                	add	a5,a5,a0
      *b = 99;
    2092:	06300693          	li	a3,99
    for (b = a; b < a + TOOMUCH; b += PGSIZE) {
    2096:	6705                	lui	a4,0x1
      *b = 99;
    2098:	00d50023          	sb	a3,0(a0) # 40000000 <base+0x3fff0318>
    for (b = a; b < a + TOOMUCH; b += PGSIZE) {
    209c:	953a                	add	a0,a0,a4
    209e:	fef51de3          	bne	a0,a5,2098 <sbrkbasic+0x38>
    exit(1);
    20a2:	4505                	li	a0,1
    20a4:	3fa030ef          	jal	549e <exit>
    20a8:	fc26                	sd	s1,56(sp)
    20aa:	f84a                	sd	s2,48(sp)
    20ac:	f44e                	sd	s3,40(sp)
    20ae:	f052                	sd	s4,32(sp)
    printf("fork failed in sbrkbasic\n");
    20b0:	00004517          	auipc	a0,0x4
    20b4:	68050513          	addi	a0,a0,1664 # 6730 <malloc+0xd78>
    20b8:	045030ef          	jal	58fc <printf>
    exit(1);
    20bc:	4505                	li	a0,1
    20be:	3e0030ef          	jal	549e <exit>
    20c2:	fc26                	sd	s1,56(sp)
    20c4:	f84a                	sd	s2,48(sp)
    20c6:	f44e                	sd	s3,40(sp)
    20c8:	f052                	sd	s4,32(sp)
      exit(0);
    20ca:	4501                	li	a0,0
    20cc:	3d2030ef          	jal	549e <exit>
  wait(&xstatus);
    20d0:	fbc40513          	addi	a0,s0,-68
    20d4:	3d2030ef          	jal	54a6 <wait>
  if (xstatus == 1) {
    20d8:	fbc42703          	lw	a4,-68(s0)
    20dc:	4785                	li	a5,1
    20de:	02f70063          	beq	a4,a5,20fe <sbrkbasic+0x9e>
    20e2:	fc26                	sd	s1,56(sp)
    20e4:	f84a                	sd	s2,48(sp)
    20e6:	f44e                	sd	s3,40(sp)
    20e8:	f052                	sd	s4,32(sp)
  a = sbrk(0);
    20ea:	4501                	li	a0,0
    20ec:	37e030ef          	jal	546a <sbrk>
    20f0:	84aa                	mv	s1,a0
  for (i = 0; i < 5000; i++) {
    20f2:	4901                	li	s2,0
    b = sbrk(1);
    20f4:	4985                	li	s3,1
  for (i = 0; i < 5000; i++) {
    20f6:	6a05                	lui	s4,0x1
    20f8:	388a0a13          	addi	s4,s4,904 # 1388 <truncate3+0x14a>
    20fc:	a005                	j	211c <sbrkbasic+0xbc>
    20fe:	fc26                	sd	s1,56(sp)
    2100:	f84a                	sd	s2,48(sp)
    2102:	f44e                	sd	s3,40(sp)
    2104:	f052                	sd	s4,32(sp)
    printf("%s: too much memory allocated!\n", s);
    2106:	85d6                	mv	a1,s5
    2108:	00004517          	auipc	a0,0x4
    210c:	64850513          	addi	a0,a0,1608 # 6750 <malloc+0xd98>
    2110:	7ec030ef          	jal	58fc <printf>
    exit(1);
    2114:	4505                	li	a0,1
    2116:	388030ef          	jal	549e <exit>
  for (i = 0; i < 5000; i++) {
    211a:	84be                	mv	s1,a5
    b = sbrk(1);
    211c:	854e                	mv	a0,s3
    211e:	34c030ef          	jal	546a <sbrk>
    if (b != a) {
    2122:	04951163          	bne	a0,s1,2164 <sbrkbasic+0x104>
    *b = 1;
    2126:	01348023          	sb	s3,0(s1)
    a = b + 1;
    212a:	00148793          	addi	a5,s1,1
  for (i = 0; i < 5000; i++) {
    212e:	2905                	addiw	s2,s2,1
    2130:	ff4915e3          	bne	s2,s4,211a <sbrkbasic+0xba>
  pid = fork();
    2134:	362030ef          	jal	5496 <fork>
    2138:	892a                	mv	s2,a0
  if (pid < 0) {
    213a:	04054263          	bltz	a0,217e <sbrkbasic+0x11e>
  c = sbrk(1);
    213e:	4505                	li	a0,1
    2140:	32a030ef          	jal	546a <sbrk>
  c = sbrk(1);
    2144:	4505                	li	a0,1
    2146:	324030ef          	jal	546a <sbrk>
  if (c != a + 1) {
    214a:	0489                	addi	s1,s1,2
    214c:	04950363          	beq	a0,s1,2192 <sbrkbasic+0x132>
    printf("%s: sbrk test failed post-fork\n", s);
    2150:	85d6                	mv	a1,s5
    2152:	00004517          	auipc	a0,0x4
    2156:	65e50513          	addi	a0,a0,1630 # 67b0 <malloc+0xdf8>
    215a:	7a2030ef          	jal	58fc <printf>
    exit(1);
    215e:	4505                	li	a0,1
    2160:	33e030ef          	jal	549e <exit>
      printf("%s: sbrk test failed %d %p %p\n", s, i, a, b);
    2164:	872a                	mv	a4,a0
    2166:	86a6                	mv	a3,s1
    2168:	864a                	mv	a2,s2
    216a:	85d6                	mv	a1,s5
    216c:	00004517          	auipc	a0,0x4
    2170:	60450513          	addi	a0,a0,1540 # 6770 <malloc+0xdb8>
    2174:	788030ef          	jal	58fc <printf>
      exit(1);
    2178:	4505                	li	a0,1
    217a:	324030ef          	jal	549e <exit>
    printf("%s: sbrk test fork failed\n", s);
    217e:	85d6                	mv	a1,s5
    2180:	00004517          	auipc	a0,0x4
    2184:	61050513          	addi	a0,a0,1552 # 6790 <malloc+0xdd8>
    2188:	774030ef          	jal	58fc <printf>
    exit(1);
    218c:	4505                	li	a0,1
    218e:	310030ef          	jal	549e <exit>
  if (pid == 0)
    2192:	00091563          	bnez	s2,219c <sbrkbasic+0x13c>
    exit(0);
    2196:	4501                	li	a0,0
    2198:	306030ef          	jal	549e <exit>
  wait(&xstatus);
    219c:	fbc40513          	addi	a0,s0,-68
    21a0:	306030ef          	jal	54a6 <wait>
  exit(xstatus);
    21a4:	fbc42503          	lw	a0,-68(s0)
    21a8:	2f6030ef          	jal	549e <exit>

00000000000021ac <sbrkmuch>:
{
    21ac:	7179                	addi	sp,sp,-48
    21ae:	f406                	sd	ra,40(sp)
    21b0:	f022                	sd	s0,32(sp)
    21b2:	ec26                	sd	s1,24(sp)
    21b4:	e84a                	sd	s2,16(sp)
    21b6:	e44e                	sd	s3,8(sp)
    21b8:	e052                	sd	s4,0(sp)
    21ba:	1800                	addi	s0,sp,48
    21bc:	89aa                	mv	s3,a0
  oldbrk = sbrk(0);
    21be:	4501                	li	a0,0
    21c0:	2aa030ef          	jal	546a <sbrk>
    21c4:	892a                	mv	s2,a0
  a = sbrk(0);
    21c6:	4501                	li	a0,0
    21c8:	2a2030ef          	jal	546a <sbrk>
    21cc:	84aa                	mv	s1,a0
  p = sbrk(amt);
    21ce:	06400537          	lui	a0,0x6400
    21d2:	9d05                	subw	a0,a0,s1
    21d4:	296030ef          	jal	546a <sbrk>
  if (p != a) {
    21d8:	08a49763          	bne	s1,a0,2266 <sbrkmuch+0xba>
  *lastaddr = 99;
    21dc:	064007b7          	lui	a5,0x6400
    21e0:	06300713          	li	a4,99
    21e4:	fee78fa3          	sb	a4,-1(a5) # 63fffff <base+0x63f0317>
  a = sbrk(0);
    21e8:	4501                	li	a0,0
    21ea:	280030ef          	jal	546a <sbrk>
    21ee:	84aa                	mv	s1,a0
  c = sbrk(-PGSIZE);
    21f0:	757d                	lui	a0,0xfffff
    21f2:	278030ef          	jal	546a <sbrk>
  if (c == (char *)SBRK_ERROR) {
    21f6:	57fd                	li	a5,-1
    21f8:	08f50163          	beq	a0,a5,227a <sbrkmuch+0xce>
  c = sbrk(0);
    21fc:	4501                	li	a0,0
    21fe:	26c030ef          	jal	546a <sbrk>
  if (c != a - PGSIZE) {
    2202:	77fd                	lui	a5,0xfffff
    2204:	97a6                	add	a5,a5,s1
    2206:	08f51463          	bne	a0,a5,228e <sbrkmuch+0xe2>
  a = sbrk(0);
    220a:	4501                	li	a0,0
    220c:	25e030ef          	jal	546a <sbrk>
    2210:	84aa                	mv	s1,a0
  c = sbrk(PGSIZE);
    2212:	6505                	lui	a0,0x1
    2214:	256030ef          	jal	546a <sbrk>
    2218:	8a2a                	mv	s4,a0
  if (c != a || sbrk(0) != a + PGSIZE) {
    221a:	08a49663          	bne	s1,a0,22a6 <sbrkmuch+0xfa>
    221e:	4501                	li	a0,0
    2220:	24a030ef          	jal	546a <sbrk>
    2224:	6785                	lui	a5,0x1
    2226:	97a6                	add	a5,a5,s1
    2228:	06f51f63          	bne	a0,a5,22a6 <sbrkmuch+0xfa>
  if (*lastaddr == 99) {
    222c:	064007b7          	lui	a5,0x6400
    2230:	fff7c703          	lbu	a4,-1(a5) # 63fffff <base+0x63f0317>
    2234:	06300793          	li	a5,99
    2238:	08f70363          	beq	a4,a5,22be <sbrkmuch+0x112>
  a = sbrk(0);
    223c:	4501                	li	a0,0
    223e:	22c030ef          	jal	546a <sbrk>
    2242:	84aa                	mv	s1,a0
  c = sbrk(-(sbrk(0) - oldbrk));
    2244:	4501                	li	a0,0
    2246:	224030ef          	jal	546a <sbrk>
    224a:	40a9053b          	subw	a0,s2,a0
    224e:	21c030ef          	jal	546a <sbrk>
  if (c != a) {
    2252:	08a49063          	bne	s1,a0,22d2 <sbrkmuch+0x126>
}
    2256:	70a2                	ld	ra,40(sp)
    2258:	7402                	ld	s0,32(sp)
    225a:	64e2                	ld	s1,24(sp)
    225c:	6942                	ld	s2,16(sp)
    225e:	69a2                	ld	s3,8(sp)
    2260:	6a02                	ld	s4,0(sp)
    2262:	6145                	addi	sp,sp,48
    2264:	8082                	ret
    printf("%s: sbrk test failed to grow big address space; enough phys mem?\n",
    2266:	85ce                	mv	a1,s3
    2268:	00004517          	auipc	a0,0x4
    226c:	56850513          	addi	a0,a0,1384 # 67d0 <malloc+0xe18>
    2270:	68c030ef          	jal	58fc <printf>
    exit(1);
    2274:	4505                	li	a0,1
    2276:	228030ef          	jal	549e <exit>
    printf("%s: sbrk could not deallocate\n", s);
    227a:	85ce                	mv	a1,s3
    227c:	00004517          	auipc	a0,0x4
    2280:	59c50513          	addi	a0,a0,1436 # 6818 <malloc+0xe60>
    2284:	678030ef          	jal	58fc <printf>
    exit(1);
    2288:	4505                	li	a0,1
    228a:	214030ef          	jal	549e <exit>
    printf("%s: sbrk deallocation produced wrong address, a %p c %p\n", s, a,
    228e:	86aa                	mv	a3,a0
    2290:	8626                	mv	a2,s1
    2292:	85ce                	mv	a1,s3
    2294:	00004517          	auipc	a0,0x4
    2298:	5a450513          	addi	a0,a0,1444 # 6838 <malloc+0xe80>
    229c:	660030ef          	jal	58fc <printf>
    exit(1);
    22a0:	4505                	li	a0,1
    22a2:	1fc030ef          	jal	549e <exit>
    printf("%s: sbrk re-allocation failed, a %p c %p\n", s, a, c);
    22a6:	86d2                	mv	a3,s4
    22a8:	8626                	mv	a2,s1
    22aa:	85ce                	mv	a1,s3
    22ac:	00004517          	auipc	a0,0x4
    22b0:	5cc50513          	addi	a0,a0,1484 # 6878 <malloc+0xec0>
    22b4:	648030ef          	jal	58fc <printf>
    exit(1);
    22b8:	4505                	li	a0,1
    22ba:	1e4030ef          	jal	549e <exit>
    printf("%s: sbrk de-allocation didn't really deallocate\n", s);
    22be:	85ce                	mv	a1,s3
    22c0:	00004517          	auipc	a0,0x4
    22c4:	5e850513          	addi	a0,a0,1512 # 68a8 <malloc+0xef0>
    22c8:	634030ef          	jal	58fc <printf>
    exit(1);
    22cc:	4505                	li	a0,1
    22ce:	1d0030ef          	jal	549e <exit>
    printf("%s: sbrk downsize failed, a %p c %p\n", s, a, c);
    22d2:	86aa                	mv	a3,a0
    22d4:	8626                	mv	a2,s1
    22d6:	85ce                	mv	a1,s3
    22d8:	00004517          	auipc	a0,0x4
    22dc:	60850513          	addi	a0,a0,1544 # 68e0 <malloc+0xf28>
    22e0:	61c030ef          	jal	58fc <printf>
    exit(1);
    22e4:	4505                	li	a0,1
    22e6:	1b8030ef          	jal	549e <exit>

00000000000022ea <sbrkarg>:
{
    22ea:	7179                	addi	sp,sp,-48
    22ec:	f406                	sd	ra,40(sp)
    22ee:	f022                	sd	s0,32(sp)
    22f0:	ec26                	sd	s1,24(sp)
    22f2:	e84a                	sd	s2,16(sp)
    22f4:	e44e                	sd	s3,8(sp)
    22f6:	1800                	addi	s0,sp,48
    22f8:	89aa                	mv	s3,a0
  a = sbrk(PGSIZE);
    22fa:	6505                	lui	a0,0x1
    22fc:	16e030ef          	jal	546a <sbrk>
    2300:	892a                	mv	s2,a0
  fd = open("sbrk", O_CREATE | O_WRONLY);
    2302:	20100593          	li	a1,513
    2306:	00004517          	auipc	a0,0x4
    230a:	60250513          	addi	a0,a0,1538 # 6908 <malloc+0xf50>
    230e:	1d0030ef          	jal	54de <open>
    2312:	84aa                	mv	s1,a0
  unlink("sbrk");
    2314:	00004517          	auipc	a0,0x4
    2318:	5f450513          	addi	a0,a0,1524 # 6908 <malloc+0xf50>
    231c:	1d2030ef          	jal	54ee <unlink>
  if (fd < 0) {
    2320:	0204c963          	bltz	s1,2352 <sbrkarg+0x68>
  if ((n = write(fd, a, PGSIZE)) < 0) {
    2324:	6605                	lui	a2,0x1
    2326:	85ca                	mv	a1,s2
    2328:	8526                	mv	a0,s1
    232a:	194030ef          	jal	54be <write>
    232e:	02054c63          	bltz	a0,2366 <sbrkarg+0x7c>
  close(fd);
    2332:	8526                	mv	a0,s1
    2334:	192030ef          	jal	54c6 <close>
  a = sbrk(PGSIZE);
    2338:	6505                	lui	a0,0x1
    233a:	130030ef          	jal	546a <sbrk>
  if (pipe((int *)a) != 0) {
    233e:	170030ef          	jal	54ae <pipe>
    2342:	ed05                	bnez	a0,237a <sbrkarg+0x90>
}
    2344:	70a2                	ld	ra,40(sp)
    2346:	7402                	ld	s0,32(sp)
    2348:	64e2                	ld	s1,24(sp)
    234a:	6942                	ld	s2,16(sp)
    234c:	69a2                	ld	s3,8(sp)
    234e:	6145                	addi	sp,sp,48
    2350:	8082                	ret
    printf("%s: open sbrk failed\n", s);
    2352:	85ce                	mv	a1,s3
    2354:	00004517          	auipc	a0,0x4
    2358:	5bc50513          	addi	a0,a0,1468 # 6910 <malloc+0xf58>
    235c:	5a0030ef          	jal	58fc <printf>
    exit(1);
    2360:	4505                	li	a0,1
    2362:	13c030ef          	jal	549e <exit>
    printf("%s: write sbrk failed\n", s);
    2366:	85ce                	mv	a1,s3
    2368:	00004517          	auipc	a0,0x4
    236c:	5c050513          	addi	a0,a0,1472 # 6928 <malloc+0xf70>
    2370:	58c030ef          	jal	58fc <printf>
    exit(1);
    2374:	4505                	li	a0,1
    2376:	128030ef          	jal	549e <exit>
    printf("%s: pipe() failed\n", s);
    237a:	85ce                	mv	a1,s3
    237c:	00004517          	auipc	a0,0x4
    2380:	08450513          	addi	a0,a0,132 # 6400 <malloc+0xa48>
    2384:	578030ef          	jal	58fc <printf>
    exit(1);
    2388:	4505                	li	a0,1
    238a:	114030ef          	jal	549e <exit>

000000000000238e <argptest>:
{
    238e:	1101                	addi	sp,sp,-32
    2390:	ec06                	sd	ra,24(sp)
    2392:	e822                	sd	s0,16(sp)
    2394:	e426                	sd	s1,8(sp)
    2396:	e04a                	sd	s2,0(sp)
    2398:	1000                	addi	s0,sp,32
    239a:	892a                	mv	s2,a0
  fd = open("init", O_RDONLY);
    239c:	4581                	li	a1,0
    239e:	00004517          	auipc	a0,0x4
    23a2:	5a250513          	addi	a0,a0,1442 # 6940 <malloc+0xf88>
    23a6:	138030ef          	jal	54de <open>
  if (fd < 0) {
    23aa:	02054563          	bltz	a0,23d4 <argptest+0x46>
    23ae:	84aa                	mv	s1,a0
  read(fd, sbrk(0) - 1, -1);
    23b0:	4501                	li	a0,0
    23b2:	0b8030ef          	jal	546a <sbrk>
    23b6:	567d                	li	a2,-1
    23b8:	00c505b3          	add	a1,a0,a2
    23bc:	8526                	mv	a0,s1
    23be:	0f8030ef          	jal	54b6 <read>
  close(fd);
    23c2:	8526                	mv	a0,s1
    23c4:	102030ef          	jal	54c6 <close>
}
    23c8:	60e2                	ld	ra,24(sp)
    23ca:	6442                	ld	s0,16(sp)
    23cc:	64a2                	ld	s1,8(sp)
    23ce:	6902                	ld	s2,0(sp)
    23d0:	6105                	addi	sp,sp,32
    23d2:	8082                	ret
    printf("%s: open failed\n", s);
    23d4:	85ca                	mv	a1,s2
    23d6:	00004517          	auipc	a0,0x4
    23da:	fba50513          	addi	a0,a0,-70 # 6390 <malloc+0x9d8>
    23de:	51e030ef          	jal	58fc <printf>
    exit(1);
    23e2:	4505                	li	a0,1
    23e4:	0ba030ef          	jal	549e <exit>

00000000000023e8 <sbrkbugs>:
{
    23e8:	1141                	addi	sp,sp,-16
    23ea:	e406                	sd	ra,8(sp)
    23ec:	e022                	sd	s0,0(sp)
    23ee:	0800                	addi	s0,sp,16
  int pid = fork();
    23f0:	0a6030ef          	jal	5496 <fork>
  if (pid < 0) {
    23f4:	00054c63          	bltz	a0,240c <sbrkbugs+0x24>
  if (pid == 0) {
    23f8:	e11d                	bnez	a0,241e <sbrkbugs+0x36>
    int sz = (uint64)sbrk(0);
    23fa:	070030ef          	jal	546a <sbrk>
    sbrk(-sz);
    23fe:	40a0053b          	negw	a0,a0
    2402:	068030ef          	jal	546a <sbrk>
    exit(0);
    2406:	4501                	li	a0,0
    2408:	096030ef          	jal	549e <exit>
    printf("fork failed\n");
    240c:	00005517          	auipc	a0,0x5
    2410:	62c50513          	addi	a0,a0,1580 # 7a38 <malloc+0x2080>
    2414:	4e8030ef          	jal	58fc <printf>
    exit(1);
    2418:	4505                	li	a0,1
    241a:	084030ef          	jal	549e <exit>
  wait(0);
    241e:	4501                	li	a0,0
    2420:	086030ef          	jal	54a6 <wait>
  pid = fork();
    2424:	072030ef          	jal	5496 <fork>
  if (pid < 0) {
    2428:	00054f63          	bltz	a0,2446 <sbrkbugs+0x5e>
  if (pid == 0) {
    242c:	e515                	bnez	a0,2458 <sbrkbugs+0x70>
    int sz = (uint64)sbrk(0);
    242e:	03c030ef          	jal	546a <sbrk>
    sbrk(-(sz - 3500));
    2432:	6785                	lui	a5,0x1
    2434:	dac7879b          	addiw	a5,a5,-596 # dac <linktest+0xe2>
    2438:	40a7853b          	subw	a0,a5,a0
    243c:	02e030ef          	jal	546a <sbrk>
    exit(0);
    2440:	4501                	li	a0,0
    2442:	05c030ef          	jal	549e <exit>
    printf("fork failed\n");
    2446:	00005517          	auipc	a0,0x5
    244a:	5f250513          	addi	a0,a0,1522 # 7a38 <malloc+0x2080>
    244e:	4ae030ef          	jal	58fc <printf>
    exit(1);
    2452:	4505                	li	a0,1
    2454:	04a030ef          	jal	549e <exit>
  wait(0);
    2458:	4501                	li	a0,0
    245a:	04c030ef          	jal	54a6 <wait>
  pid = fork();
    245e:	038030ef          	jal	5496 <fork>
  if (pid < 0) {
    2462:	02054263          	bltz	a0,2486 <sbrkbugs+0x9e>
  if (pid == 0) {
    2466:	e90d                	bnez	a0,2498 <sbrkbugs+0xb0>
    sbrk((10 * PGSIZE + 2048) - (uint64)sbrk(0));
    2468:	002030ef          	jal	546a <sbrk>
    246c:	67ad                	lui	a5,0xb
    246e:	8007879b          	addiw	a5,a5,-2048 # a800 <uninit+0x228>
    2472:	40a7853b          	subw	a0,a5,a0
    2476:	7f5020ef          	jal	546a <sbrk>
    sbrk(-10);
    247a:	5559                	li	a0,-10
    247c:	7ef020ef          	jal	546a <sbrk>
    exit(0);
    2480:	4501                	li	a0,0
    2482:	01c030ef          	jal	549e <exit>
    printf("fork failed\n");
    2486:	00005517          	auipc	a0,0x5
    248a:	5b250513          	addi	a0,a0,1458 # 7a38 <malloc+0x2080>
    248e:	46e030ef          	jal	58fc <printf>
    exit(1);
    2492:	4505                	li	a0,1
    2494:	00a030ef          	jal	549e <exit>
  wait(0);
    2498:	4501                	li	a0,0
    249a:	00c030ef          	jal	54a6 <wait>
  exit(0);
    249e:	4501                	li	a0,0
    24a0:	7ff020ef          	jal	549e <exit>

00000000000024a4 <sbrklast>:
{
    24a4:	7179                	addi	sp,sp,-48
    24a6:	f406                	sd	ra,40(sp)
    24a8:	f022                	sd	s0,32(sp)
    24aa:	ec26                	sd	s1,24(sp)
    24ac:	e84a                	sd	s2,16(sp)
    24ae:	e44e                	sd	s3,8(sp)
    24b0:	e052                	sd	s4,0(sp)
    24b2:	1800                	addi	s0,sp,48
  uint64 top = (uint64)sbrk(0);
    24b4:	4501                	li	a0,0
    24b6:	7b5020ef          	jal	546a <sbrk>
  if ((top % PGSIZE) != 0)
    24ba:	03451793          	slli	a5,a0,0x34
    24be:	ebad                	bnez	a5,2530 <sbrklast+0x8c>
  sbrk(PGSIZE);
    24c0:	6505                	lui	a0,0x1
    24c2:	7a9020ef          	jal	546a <sbrk>
  sbrk(10);
    24c6:	4529                	li	a0,10
    24c8:	7a3020ef          	jal	546a <sbrk>
  sbrk(-20);
    24cc:	5531                	li	a0,-20
    24ce:	79d020ef          	jal	546a <sbrk>
  top = (uint64)sbrk(0);
    24d2:	4501                	li	a0,0
    24d4:	797020ef          	jal	546a <sbrk>
    24d8:	84aa                	mv	s1,a0
  char *p = (char *)(top - 64);
    24da:	fc050913          	addi	s2,a0,-64 # fc0 <bigdir+0xcc>
  p[0] = 'x';
    24de:	07800993          	li	s3,120
    24e2:	fd350023          	sb	s3,-64(a0)
  p[1] = '\0';
    24e6:	fc0500a3          	sb	zero,-63(a0)
  int fd = open(p, O_RDWR | O_CREATE);
    24ea:	20200593          	li	a1,514
    24ee:	854a                	mv	a0,s2
    24f0:	7ef020ef          	jal	54de <open>
    24f4:	8a2a                	mv	s4,a0
  write(fd, p, 1);
    24f6:	4605                	li	a2,1
    24f8:	85ca                	mv	a1,s2
    24fa:	7c5020ef          	jal	54be <write>
  close(fd);
    24fe:	8552                	mv	a0,s4
    2500:	7c7020ef          	jal	54c6 <close>
  fd = open(p, O_RDWR);
    2504:	4589                	li	a1,2
    2506:	854a                	mv	a0,s2
    2508:	7d7020ef          	jal	54de <open>
  p[0] = '\0';
    250c:	fc048023          	sb	zero,-64(s1)
  read(fd, p, 1);
    2510:	4605                	li	a2,1
    2512:	85ca                	mv	a1,s2
    2514:	7a3020ef          	jal	54b6 <read>
  if (p[0] != 'x')
    2518:	fc04c783          	lbu	a5,-64(s1)
    251c:	03379263          	bne	a5,s3,2540 <sbrklast+0x9c>
}
    2520:	70a2                	ld	ra,40(sp)
    2522:	7402                	ld	s0,32(sp)
    2524:	64e2                	ld	s1,24(sp)
    2526:	6942                	ld	s2,16(sp)
    2528:	69a2                	ld	s3,8(sp)
    252a:	6a02                	ld	s4,0(sp)
    252c:	6145                	addi	sp,sp,48
    252e:	8082                	ret
    sbrk(PGSIZE - (top % PGSIZE));
    2530:	0347d513          	srli	a0,a5,0x34
    2534:	6785                	lui	a5,0x1
    2536:	40a7853b          	subw	a0,a5,a0
    253a:	731020ef          	jal	546a <sbrk>
    253e:	b749                	j	24c0 <sbrklast+0x1c>
    exit(1);
    2540:	4505                	li	a0,1
    2542:	75d020ef          	jal	549e <exit>

0000000000002546 <sbrk8000>:
{
    2546:	1141                	addi	sp,sp,-16
    2548:	e406                	sd	ra,8(sp)
    254a:	e022                	sd	s0,0(sp)
    254c:	0800                	addi	s0,sp,16
  sbrk(0x80000004);
    254e:	80000537          	lui	a0,0x80000
    2552:	0511                	addi	a0,a0,4 # ffffffff80000004 <base+0xffffffff7fff031c>
    2554:	717020ef          	jal	546a <sbrk>
  volatile char *top = sbrk(0);
    2558:	4501                	li	a0,0
    255a:	711020ef          	jal	546a <sbrk>
  *(top - 1) = *(top - 1) + 1;
    255e:	fff54783          	lbu	a5,-1(a0)
    2562:	2785                	addiw	a5,a5,1 # 1001 <bigdir+0x10d>
    2564:	fef50fa3          	sb	a5,-1(a0)
}
    2568:	60a2                	ld	ra,8(sp)
    256a:	6402                	ld	s0,0(sp)
    256c:	0141                	addi	sp,sp,16
    256e:	8082                	ret

0000000000002570 <execout>:
{
    2570:	711d                	addi	sp,sp,-96
    2572:	ec86                	sd	ra,88(sp)
    2574:	e8a2                	sd	s0,80(sp)
    2576:	e4a6                	sd	s1,72(sp)
    2578:	e0ca                	sd	s2,64(sp)
    257a:	fc4e                	sd	s3,56(sp)
    257c:	1080                	addi	s0,sp,96
  for (int avail = 0; avail < 15; avail++) {
    257e:	4901                	li	s2,0
    2580:	49bd                	li	s3,15
    int pid = fork();
    2582:	715020ef          	jal	5496 <fork>
    2586:	84aa                	mv	s1,a0
    if (pid < 0) {
    2588:	00054e63          	bltz	a0,25a4 <execout+0x34>
    } else if (pid == 0) {
    258c:	c51d                	beqz	a0,25ba <execout+0x4a>
      wait((int *)0);
    258e:	4501                	li	a0,0
    2590:	717020ef          	jal	54a6 <wait>
  for (int avail = 0; avail < 15; avail++) {
    2594:	2905                	addiw	s2,s2,1
    2596:	ff3916e3          	bne	s2,s3,2582 <execout+0x12>
    259a:	f852                	sd	s4,48(sp)
    259c:	f456                	sd	s5,40(sp)
  exit(0);
    259e:	4501                	li	a0,0
    25a0:	6ff020ef          	jal	549e <exit>
    25a4:	f852                	sd	s4,48(sp)
    25a6:	f456                	sd	s5,40(sp)
      printf("fork failed\n");
    25a8:	00005517          	auipc	a0,0x5
    25ac:	49050513          	addi	a0,a0,1168 # 7a38 <malloc+0x2080>
    25b0:	34c030ef          	jal	58fc <printf>
      exit(1);
    25b4:	4505                	li	a0,1
    25b6:	6e9020ef          	jal	549e <exit>
    25ba:	f852                	sd	s4,48(sp)
    25bc:	f456                	sd	s5,40(sp)
        char *a = sbrk(PGSIZE);
    25be:	6985                	lui	s3,0x1
        if (a == SBRK_ERROR)
    25c0:	5a7d                	li	s4,-1
        *(a + PGSIZE - 1) = 1;
    25c2:	4a85                	li	s5,1
        char *a = sbrk(PGSIZE);
    25c4:	854e                	mv	a0,s3
    25c6:	6a5020ef          	jal	546a <sbrk>
        if (a == SBRK_ERROR)
    25ca:	01450663          	beq	a0,s4,25d6 <execout+0x66>
        *(a + PGSIZE - 1) = 1;
    25ce:	954e                	add	a0,a0,s3
    25d0:	ff550fa3          	sb	s5,-1(a0)
      while (1) {
    25d4:	bfc5                	j	25c4 <execout+0x54>
        sbrk(-PGSIZE);
    25d6:	79fd                	lui	s3,0xfffff
      for (int i = 0; i < avail; i++)
    25d8:	01205863          	blez	s2,25e8 <execout+0x78>
        sbrk(-PGSIZE);
    25dc:	854e                	mv	a0,s3
    25de:	68d020ef          	jal	546a <sbrk>
      for (int i = 0; i < avail; i++)
    25e2:	2485                	addiw	s1,s1,1
    25e4:	ff249ce3          	bne	s1,s2,25dc <execout+0x6c>
      close(1);
    25e8:	4505                	li	a0,1
    25ea:	6dd020ef          	jal	54c6 <close>
      char *args[] = {"echo", "x", 0};
    25ee:	00003797          	auipc	a5,0x3
    25f2:	4fa78793          	addi	a5,a5,1274 # 5ae8 <malloc+0x130>
    25f6:	faf43423          	sd	a5,-88(s0)
    25fa:	00003797          	auipc	a5,0x3
    25fe:	55e78793          	addi	a5,a5,1374 # 5b58 <malloc+0x1a0>
    2602:	faf43823          	sd	a5,-80(s0)
    2606:	fa043c23          	sd	zero,-72(s0)
      exec("echo", args);
    260a:	fa840593          	addi	a1,s0,-88
    260e:	00003517          	auipc	a0,0x3
    2612:	4da50513          	addi	a0,a0,1242 # 5ae8 <malloc+0x130>
    2616:	6c1020ef          	jal	54d6 <exec>
      exit(0);
    261a:	4501                	li	a0,0
    261c:	683020ef          	jal	549e <exit>

0000000000002620 <fourteen>:
{
    2620:	1101                	addi	sp,sp,-32
    2622:	ec06                	sd	ra,24(sp)
    2624:	e822                	sd	s0,16(sp)
    2626:	e426                	sd	s1,8(sp)
    2628:	1000                	addi	s0,sp,32
    262a:	84aa                	mv	s1,a0
  if (mkdir("12345678901234") != 0) {
    262c:	00004517          	auipc	a0,0x4
    2630:	4ec50513          	addi	a0,a0,1260 # 6b18 <malloc+0x1160>
    2634:	6d3020ef          	jal	5506 <mkdir>
    2638:	e555                	bnez	a0,26e4 <fourteen+0xc4>
  if (mkdir("12345678901234/123456789012345") != 0) {
    263a:	00004517          	auipc	a0,0x4
    263e:	33650513          	addi	a0,a0,822 # 6970 <malloc+0xfb8>
    2642:	6c5020ef          	jal	5506 <mkdir>
    2646:	e94d                	bnez	a0,26f8 <fourteen+0xd8>
  fd = open("123456789012345/123456789012345/123456789012345", O_CREATE);
    2648:	20000593          	li	a1,512
    264c:	00004517          	auipc	a0,0x4
    2650:	37c50513          	addi	a0,a0,892 # 69c8 <malloc+0x1010>
    2654:	68b020ef          	jal	54de <open>
  if (fd < 0) {
    2658:	0a054a63          	bltz	a0,270c <fourteen+0xec>
  close(fd);
    265c:	66b020ef          	jal	54c6 <close>
  fd = open("12345678901234/12345678901234/12345678901234", 0);
    2660:	4581                	li	a1,0
    2662:	00004517          	auipc	a0,0x4
    2666:	3de50513          	addi	a0,a0,990 # 6a40 <malloc+0x1088>
    266a:	675020ef          	jal	54de <open>
  if (fd < 0) {
    266e:	0a054963          	bltz	a0,2720 <fourteen+0x100>
  close(fd);
    2672:	655020ef          	jal	54c6 <close>
  if (mkdir("12345678901234/12345678901234") == 0) {
    2676:	00004517          	auipc	a0,0x4
    267a:	43a50513          	addi	a0,a0,1082 # 6ab0 <malloc+0x10f8>
    267e:	689020ef          	jal	5506 <mkdir>
    2682:	c94d                	beqz	a0,2734 <fourteen+0x114>
  if (mkdir("123456789012345/12345678901234") == 0) {
    2684:	00004517          	auipc	a0,0x4
    2688:	48450513          	addi	a0,a0,1156 # 6b08 <malloc+0x1150>
    268c:	67b020ef          	jal	5506 <mkdir>
    2690:	cd45                	beqz	a0,2748 <fourteen+0x128>
  unlink("123456789012345/12345678901234");
    2692:	00004517          	auipc	a0,0x4
    2696:	47650513          	addi	a0,a0,1142 # 6b08 <malloc+0x1150>
    269a:	655020ef          	jal	54ee <unlink>
  unlink("12345678901234/12345678901234");
    269e:	00004517          	auipc	a0,0x4
    26a2:	41250513          	addi	a0,a0,1042 # 6ab0 <malloc+0x10f8>
    26a6:	649020ef          	jal	54ee <unlink>
  unlink("12345678901234/12345678901234/12345678901234");
    26aa:	00004517          	auipc	a0,0x4
    26ae:	39650513          	addi	a0,a0,918 # 6a40 <malloc+0x1088>
    26b2:	63d020ef          	jal	54ee <unlink>
  unlink("123456789012345/123456789012345/123456789012345");
    26b6:	00004517          	auipc	a0,0x4
    26ba:	31250513          	addi	a0,a0,786 # 69c8 <malloc+0x1010>
    26be:	631020ef          	jal	54ee <unlink>
  unlink("12345678901234/123456789012345");
    26c2:	00004517          	auipc	a0,0x4
    26c6:	2ae50513          	addi	a0,a0,686 # 6970 <malloc+0xfb8>
    26ca:	625020ef          	jal	54ee <unlink>
  unlink("12345678901234");
    26ce:	00004517          	auipc	a0,0x4
    26d2:	44a50513          	addi	a0,a0,1098 # 6b18 <malloc+0x1160>
    26d6:	619020ef          	jal	54ee <unlink>
}
    26da:	60e2                	ld	ra,24(sp)
    26dc:	6442                	ld	s0,16(sp)
    26de:	64a2                	ld	s1,8(sp)
    26e0:	6105                	addi	sp,sp,32
    26e2:	8082                	ret
    printf("%s: mkdir 12345678901234 failed\n", s);
    26e4:	85a6                	mv	a1,s1
    26e6:	00004517          	auipc	a0,0x4
    26ea:	26250513          	addi	a0,a0,610 # 6948 <malloc+0xf90>
    26ee:	20e030ef          	jal	58fc <printf>
    exit(1);
    26f2:	4505                	li	a0,1
    26f4:	5ab020ef          	jal	549e <exit>
    printf("%s: mkdir 12345678901234/123456789012345 failed\n", s);
    26f8:	85a6                	mv	a1,s1
    26fa:	00004517          	auipc	a0,0x4
    26fe:	29650513          	addi	a0,a0,662 # 6990 <malloc+0xfd8>
    2702:	1fa030ef          	jal	58fc <printf>
    exit(1);
    2706:	4505                	li	a0,1
    2708:	597020ef          	jal	549e <exit>
    printf(
    270c:	85a6                	mv	a1,s1
    270e:	00004517          	auipc	a0,0x4
    2712:	2ea50513          	addi	a0,a0,746 # 69f8 <malloc+0x1040>
    2716:	1e6030ef          	jal	58fc <printf>
    exit(1);
    271a:	4505                	li	a0,1
    271c:	583020ef          	jal	549e <exit>
    printf("%s: open 12345678901234/12345678901234/12345678901234 failed\n", s);
    2720:	85a6                	mv	a1,s1
    2722:	00004517          	auipc	a0,0x4
    2726:	34e50513          	addi	a0,a0,846 # 6a70 <malloc+0x10b8>
    272a:	1d2030ef          	jal	58fc <printf>
    exit(1);
    272e:	4505                	li	a0,1
    2730:	56f020ef          	jal	549e <exit>
    printf("%s: mkdir 12345678901234/12345678901234 succeeded!\n", s);
    2734:	85a6                	mv	a1,s1
    2736:	00004517          	auipc	a0,0x4
    273a:	39a50513          	addi	a0,a0,922 # 6ad0 <malloc+0x1118>
    273e:	1be030ef          	jal	58fc <printf>
    exit(1);
    2742:	4505                	li	a0,1
    2744:	55b020ef          	jal	549e <exit>
    printf("%s: mkdir 12345678901234/123456789012345 succeeded!\n", s);
    2748:	85a6                	mv	a1,s1
    274a:	00004517          	auipc	a0,0x4
    274e:	3de50513          	addi	a0,a0,990 # 6b28 <malloc+0x1170>
    2752:	1aa030ef          	jal	58fc <printf>
    exit(1);
    2756:	4505                	li	a0,1
    2758:	547020ef          	jal	549e <exit>

000000000000275c <diskfull>:
{
    275c:	b6010113          	addi	sp,sp,-1184
    2760:	48113c23          	sd	ra,1176(sp)
    2764:	48813823          	sd	s0,1168(sp)
    2768:	48913423          	sd	s1,1160(sp)
    276c:	49213023          	sd	s2,1152(sp)
    2770:	47313c23          	sd	s3,1144(sp)
    2774:	47413823          	sd	s4,1136(sp)
    2778:	47513423          	sd	s5,1128(sp)
    277c:	47613023          	sd	s6,1120(sp)
    2780:	45713c23          	sd	s7,1112(sp)
    2784:	45813823          	sd	s8,1104(sp)
    2788:	45913423          	sd	s9,1096(sp)
    278c:	45a13023          	sd	s10,1088(sp)
    2790:	43b13c23          	sd	s11,1080(sp)
    2794:	4a010413          	addi	s0,sp,1184
    2798:	b6a43423          	sd	a0,-1176(s0)
  unlink("diskfulldir");
    279c:	00004517          	auipc	a0,0x4
    27a0:	3c450513          	addi	a0,a0,964 # 6b60 <malloc+0x11a8>
    27a4:	54b020ef          	jal	54ee <unlink>
    27a8:	03000a93          	li	s5,48
    name[0] = 'b';
    27ac:	06200d13          	li	s10,98
    name[1] = 'i';
    27b0:	06900c93          	li	s9,105
    name[2] = 'g';
    27b4:	06700c13          	li	s8,103
    unlink(name);
    27b8:	b7040b13          	addi	s6,s0,-1168
    int fd = open(name, O_CREATE | O_RDWR | O_TRUNC);
    27bc:	60200b93          	li	s7,1538
    if (fd < 0) {
    27c0:	10c00d93          	li	s11,268
      if (write(fd, buf, BSIZE) != BSIZE) {
    27c4:	b9040a13          	addi	s4,s0,-1136
    27c8:	aa8d                	j	293a <diskfull+0x1de>
      printf("%s: could not create file %s\n", s, name);
    27ca:	b7040613          	addi	a2,s0,-1168
    27ce:	b6843583          	ld	a1,-1176(s0)
    27d2:	00004517          	auipc	a0,0x4
    27d6:	39e50513          	addi	a0,a0,926 # 6b70 <malloc+0x11b8>
    27da:	122030ef          	jal	58fc <printf>
      break;
    27de:	a039                	j	27ec <diskfull+0x90>
        close(fd);
    27e0:	854e                	mv	a0,s3
    27e2:	4e5020ef          	jal	54c6 <close>
    close(fd);
    27e6:	854e                	mv	a0,s3
    27e8:	4df020ef          	jal	54c6 <close>
  for (int i = 0; i < nzz; i++) {
    27ec:	4481                	li	s1,0
    name[0] = 'z';
    27ee:	07a00993          	li	s3,122
    unlink(name);
    27f2:	b9040913          	addi	s2,s0,-1136
    int fd = open(name, O_CREATE | O_RDWR | O_TRUNC);
    27f6:	60200a13          	li	s4,1538
  for (int i = 0; i < nzz; i++) {
    27fa:	08000a93          	li	s5,128
    name[0] = 'z';
    27fe:	b9340823          	sb	s3,-1136(s0)
    name[1] = 'z';
    2802:	b93408a3          	sb	s3,-1135(s0)
    name[2] = '0' + (i / 32);
    2806:	41f4d71b          	sraiw	a4,s1,0x1f
    280a:	01b7571b          	srliw	a4,a4,0x1b
    280e:	009707bb          	addw	a5,a4,s1
    2812:	4057d69b          	sraiw	a3,a5,0x5
    2816:	0306869b          	addiw	a3,a3,48
    281a:	b8d40923          	sb	a3,-1134(s0)
    name[3] = '0' + (i % 32);
    281e:	8bfd                	andi	a5,a5,31
    2820:	9f99                	subw	a5,a5,a4
    2822:	0307879b          	addiw	a5,a5,48
    2826:	b8f409a3          	sb	a5,-1133(s0)
    name[4] = '\0';
    282a:	b8040a23          	sb	zero,-1132(s0)
    unlink(name);
    282e:	854a                	mv	a0,s2
    2830:	4bf020ef          	jal	54ee <unlink>
    int fd = open(name, O_CREATE | O_RDWR | O_TRUNC);
    2834:	85d2                	mv	a1,s4
    2836:	854a                	mv	a0,s2
    2838:	4a7020ef          	jal	54de <open>
    if (fd < 0)
    283c:	00054763          	bltz	a0,284a <diskfull+0xee>
    close(fd);
    2840:	487020ef          	jal	54c6 <close>
  for (int i = 0; i < nzz; i++) {
    2844:	2485                	addiw	s1,s1,1
    2846:	fb549ce3          	bne	s1,s5,27fe <diskfull+0xa2>
  if (mkdir("diskfulldir") == 0)
    284a:	00004517          	auipc	a0,0x4
    284e:	31650513          	addi	a0,a0,790 # 6b60 <malloc+0x11a8>
    2852:	4b5020ef          	jal	5506 <mkdir>
    2856:	12050363          	beqz	a0,297c <diskfull+0x220>
  unlink("diskfulldir");
    285a:	00004517          	auipc	a0,0x4
    285e:	30650513          	addi	a0,a0,774 # 6b60 <malloc+0x11a8>
    2862:	48d020ef          	jal	54ee <unlink>
  for (int i = 0; i < nzz; i++) {
    2866:	4481                	li	s1,0
    name[0] = 'z';
    2868:	07a00913          	li	s2,122
    unlink(name);
    286c:	b9040a13          	addi	s4,s0,-1136
  for (int i = 0; i < nzz; i++) {
    2870:	08000993          	li	s3,128
    name[0] = 'z';
    2874:	b9240823          	sb	s2,-1136(s0)
    name[1] = 'z';
    2878:	b92408a3          	sb	s2,-1135(s0)
    name[2] = '0' + (i / 32);
    287c:	41f4d71b          	sraiw	a4,s1,0x1f
    2880:	01b7571b          	srliw	a4,a4,0x1b
    2884:	009707bb          	addw	a5,a4,s1
    2888:	4057d69b          	sraiw	a3,a5,0x5
    288c:	0306869b          	addiw	a3,a3,48
    2890:	b8d40923          	sb	a3,-1134(s0)
    name[3] = '0' + (i % 32);
    2894:	8bfd                	andi	a5,a5,31
    2896:	9f99                	subw	a5,a5,a4
    2898:	0307879b          	addiw	a5,a5,48
    289c:	b8f409a3          	sb	a5,-1133(s0)
    name[4] = '\0';
    28a0:	b8040a23          	sb	zero,-1132(s0)
    unlink(name);
    28a4:	8552                	mv	a0,s4
    28a6:	449020ef          	jal	54ee <unlink>
  for (int i = 0; i < nzz; i++) {
    28aa:	2485                	addiw	s1,s1,1
    28ac:	fd3494e3          	bne	s1,s3,2874 <diskfull+0x118>
    28b0:	03000493          	li	s1,48
    name[0] = 'b';
    28b4:	06200b13          	li	s6,98
    name[1] = 'i';
    28b8:	06900a93          	li	s5,105
    name[2] = 'g';
    28bc:	06700a13          	li	s4,103
    unlink(name);
    28c0:	b9040993          	addi	s3,s0,-1136
  for (int i = 0; '0' + i < 0177; i++) {
    28c4:	07f00913          	li	s2,127
    name[0] = 'b';
    28c8:	b9640823          	sb	s6,-1136(s0)
    name[1] = 'i';
    28cc:	b95408a3          	sb	s5,-1135(s0)
    name[2] = 'g';
    28d0:	b9440923          	sb	s4,-1134(s0)
    name[3] = '0' + i;
    28d4:	b89409a3          	sb	s1,-1133(s0)
    name[4] = '\0';
    28d8:	b8040a23          	sb	zero,-1132(s0)
    unlink(name);
    28dc:	854e                	mv	a0,s3
    28de:	411020ef          	jal	54ee <unlink>
  for (int i = 0; '0' + i < 0177; i++) {
    28e2:	2485                	addiw	s1,s1,1
    28e4:	0ff4f493          	zext.b	s1,s1
    28e8:	ff2490e3          	bne	s1,s2,28c8 <diskfull+0x16c>
}
    28ec:	49813083          	ld	ra,1176(sp)
    28f0:	49013403          	ld	s0,1168(sp)
    28f4:	48813483          	ld	s1,1160(sp)
    28f8:	48013903          	ld	s2,1152(sp)
    28fc:	47813983          	ld	s3,1144(sp)
    2900:	47013a03          	ld	s4,1136(sp)
    2904:	46813a83          	ld	s5,1128(sp)
    2908:	46013b03          	ld	s6,1120(sp)
    290c:	45813b83          	ld	s7,1112(sp)
    2910:	45013c03          	ld	s8,1104(sp)
    2914:	44813c83          	ld	s9,1096(sp)
    2918:	44013d03          	ld	s10,1088(sp)
    291c:	43813d83          	ld	s11,1080(sp)
    2920:	4a010113          	addi	sp,sp,1184
    2924:	8082                	ret
    close(fd);
    2926:	854e                	mv	a0,s3
    2928:	39f020ef          	jal	54c6 <close>
  for (fi = 0; done == 0 && '0' + fi < 0177; fi++) {
    292c:	2a85                	addiw	s5,s5,1 # 3001 <subdir+0x47b>
    292e:	0ffafa93          	zext.b	s5,s5
    2932:	07f00793          	li	a5,127
    2936:	eafa8be3          	beq	s5,a5,27ec <diskfull+0x90>
    name[0] = 'b';
    293a:	b7a40823          	sb	s10,-1168(s0)
    name[1] = 'i';
    293e:	b79408a3          	sb	s9,-1167(s0)
    name[2] = 'g';
    2942:	b7840923          	sb	s8,-1166(s0)
    name[3] = '0' + fi;
    2946:	b75409a3          	sb	s5,-1165(s0)
    name[4] = '\0';
    294a:	b6040a23          	sb	zero,-1164(s0)
    unlink(name);
    294e:	855a                	mv	a0,s6
    2950:	39f020ef          	jal	54ee <unlink>
    int fd = open(name, O_CREATE | O_RDWR | O_TRUNC);
    2954:	85de                	mv	a1,s7
    2956:	855a                	mv	a0,s6
    2958:	387020ef          	jal	54de <open>
    295c:	89aa                	mv	s3,a0
    if (fd < 0) {
    295e:	e60546e3          	bltz	a0,27ca <diskfull+0x6e>
    2962:	84ee                	mv	s1,s11
      if (write(fd, buf, BSIZE) != BSIZE) {
    2964:	40000913          	li	s2,1024
    2968:	864a                	mv	a2,s2
    296a:	85d2                	mv	a1,s4
    296c:	854e                	mv	a0,s3
    296e:	351020ef          	jal	54be <write>
    2972:	e72517e3          	bne	a0,s2,27e0 <diskfull+0x84>
    for (int i = 0; i < MAXFILE; i++) {
    2976:	34fd                	addiw	s1,s1,-1
    2978:	f8e5                	bnez	s1,2968 <diskfull+0x20c>
    297a:	b775                	j	2926 <diskfull+0x1ca>
    printf("%s: mkdir(diskfulldir) unexpectedly succeeded!\n", s);
    297c:	b6843583          	ld	a1,-1176(s0)
    2980:	00004517          	auipc	a0,0x4
    2984:	21050513          	addi	a0,a0,528 # 6b90 <malloc+0x11d8>
    2988:	775020ef          	jal	58fc <printf>
    298c:	b5f9                	j	285a <diskfull+0xfe>

000000000000298e <iputtest>:
{
    298e:	1101                	addi	sp,sp,-32
    2990:	ec06                	sd	ra,24(sp)
    2992:	e822                	sd	s0,16(sp)
    2994:	e426                	sd	s1,8(sp)
    2996:	1000                	addi	s0,sp,32
    2998:	84aa                	mv	s1,a0
  if (mkdir("iputdir") < 0) {
    299a:	00004517          	auipc	a0,0x4
    299e:	22650513          	addi	a0,a0,550 # 6bc0 <malloc+0x1208>
    29a2:	365020ef          	jal	5506 <mkdir>
    29a6:	02054f63          	bltz	a0,29e4 <iputtest+0x56>
  if (chdir("iputdir") < 0) {
    29aa:	00004517          	auipc	a0,0x4
    29ae:	21650513          	addi	a0,a0,534 # 6bc0 <malloc+0x1208>
    29b2:	35d020ef          	jal	550e <chdir>
    29b6:	04054163          	bltz	a0,29f8 <iputtest+0x6a>
  if (unlink("../iputdir") < 0) {
    29ba:	00004517          	auipc	a0,0x4
    29be:	24650513          	addi	a0,a0,582 # 6c00 <malloc+0x1248>
    29c2:	32d020ef          	jal	54ee <unlink>
    29c6:	04054363          	bltz	a0,2a0c <iputtest+0x7e>
  if (chdir("/") < 0) {
    29ca:	00004517          	auipc	a0,0x4
    29ce:	26650513          	addi	a0,a0,614 # 6c30 <malloc+0x1278>
    29d2:	33d020ef          	jal	550e <chdir>
    29d6:	04054563          	bltz	a0,2a20 <iputtest+0x92>
}
    29da:	60e2                	ld	ra,24(sp)
    29dc:	6442                	ld	s0,16(sp)
    29de:	64a2                	ld	s1,8(sp)
    29e0:	6105                	addi	sp,sp,32
    29e2:	8082                	ret
    printf("%s: mkdir failed\n", s);
    29e4:	85a6                	mv	a1,s1
    29e6:	00004517          	auipc	a0,0x4
    29ea:	1e250513          	addi	a0,a0,482 # 6bc8 <malloc+0x1210>
    29ee:	70f020ef          	jal	58fc <printf>
    exit(1);
    29f2:	4505                	li	a0,1
    29f4:	2ab020ef          	jal	549e <exit>
    printf("%s: chdir iputdir failed\n", s);
    29f8:	85a6                	mv	a1,s1
    29fa:	00004517          	auipc	a0,0x4
    29fe:	1e650513          	addi	a0,a0,486 # 6be0 <malloc+0x1228>
    2a02:	6fb020ef          	jal	58fc <printf>
    exit(1);
    2a06:	4505                	li	a0,1
    2a08:	297020ef          	jal	549e <exit>
    printf("%s: unlink ../iputdir failed\n", s);
    2a0c:	85a6                	mv	a1,s1
    2a0e:	00004517          	auipc	a0,0x4
    2a12:	20250513          	addi	a0,a0,514 # 6c10 <malloc+0x1258>
    2a16:	6e7020ef          	jal	58fc <printf>
    exit(1);
    2a1a:	4505                	li	a0,1
    2a1c:	283020ef          	jal	549e <exit>
    printf("%s: chdir / failed\n", s);
    2a20:	85a6                	mv	a1,s1
    2a22:	00004517          	auipc	a0,0x4
    2a26:	21650513          	addi	a0,a0,534 # 6c38 <malloc+0x1280>
    2a2a:	6d3020ef          	jal	58fc <printf>
    exit(1);
    2a2e:	4505                	li	a0,1
    2a30:	26f020ef          	jal	549e <exit>

0000000000002a34 <exitiputtest>:
{
    2a34:	7179                	addi	sp,sp,-48
    2a36:	f406                	sd	ra,40(sp)
    2a38:	f022                	sd	s0,32(sp)
    2a3a:	ec26                	sd	s1,24(sp)
    2a3c:	1800                	addi	s0,sp,48
    2a3e:	84aa                	mv	s1,a0
  pid = fork();
    2a40:	257020ef          	jal	5496 <fork>
  if (pid < 0) {
    2a44:	02054e63          	bltz	a0,2a80 <exitiputtest+0x4c>
  if (pid == 0) {
    2a48:	e541                	bnez	a0,2ad0 <exitiputtest+0x9c>
    if (mkdir("iputdir") < 0) {
    2a4a:	00004517          	auipc	a0,0x4
    2a4e:	17650513          	addi	a0,a0,374 # 6bc0 <malloc+0x1208>
    2a52:	2b5020ef          	jal	5506 <mkdir>
    2a56:	02054f63          	bltz	a0,2a94 <exitiputtest+0x60>
    if (chdir("iputdir") < 0) {
    2a5a:	00004517          	auipc	a0,0x4
    2a5e:	16650513          	addi	a0,a0,358 # 6bc0 <malloc+0x1208>
    2a62:	2ad020ef          	jal	550e <chdir>
    2a66:	04054163          	bltz	a0,2aa8 <exitiputtest+0x74>
    if (unlink("../iputdir") < 0) {
    2a6a:	00004517          	auipc	a0,0x4
    2a6e:	19650513          	addi	a0,a0,406 # 6c00 <malloc+0x1248>
    2a72:	27d020ef          	jal	54ee <unlink>
    2a76:	04054363          	bltz	a0,2abc <exitiputtest+0x88>
    exit(0);
    2a7a:	4501                	li	a0,0
    2a7c:	223020ef          	jal	549e <exit>
    printf("%s: fork failed\n", s);
    2a80:	85a6                	mv	a1,s1
    2a82:	00004517          	auipc	a0,0x4
    2a86:	8f650513          	addi	a0,a0,-1802 # 6378 <malloc+0x9c0>
    2a8a:	673020ef          	jal	58fc <printf>
    exit(1);
    2a8e:	4505                	li	a0,1
    2a90:	20f020ef          	jal	549e <exit>
      printf("%s: mkdir failed\n", s);
    2a94:	85a6                	mv	a1,s1
    2a96:	00004517          	auipc	a0,0x4
    2a9a:	13250513          	addi	a0,a0,306 # 6bc8 <malloc+0x1210>
    2a9e:	65f020ef          	jal	58fc <printf>
      exit(1);
    2aa2:	4505                	li	a0,1
    2aa4:	1fb020ef          	jal	549e <exit>
      printf("%s: child chdir failed\n", s);
    2aa8:	85a6                	mv	a1,s1
    2aaa:	00004517          	auipc	a0,0x4
    2aae:	1a650513          	addi	a0,a0,422 # 6c50 <malloc+0x1298>
    2ab2:	64b020ef          	jal	58fc <printf>
      exit(1);
    2ab6:	4505                	li	a0,1
    2ab8:	1e7020ef          	jal	549e <exit>
      printf("%s: unlink ../iputdir failed\n", s);
    2abc:	85a6                	mv	a1,s1
    2abe:	00004517          	auipc	a0,0x4
    2ac2:	15250513          	addi	a0,a0,338 # 6c10 <malloc+0x1258>
    2ac6:	637020ef          	jal	58fc <printf>
      exit(1);
    2aca:	4505                	li	a0,1
    2acc:	1d3020ef          	jal	549e <exit>
  wait(&xstatus);
    2ad0:	fdc40513          	addi	a0,s0,-36
    2ad4:	1d3020ef          	jal	54a6 <wait>
  exit(xstatus);
    2ad8:	fdc42503          	lw	a0,-36(s0)
    2adc:	1c3020ef          	jal	549e <exit>

0000000000002ae0 <dirtest>:
{
    2ae0:	1101                	addi	sp,sp,-32
    2ae2:	ec06                	sd	ra,24(sp)
    2ae4:	e822                	sd	s0,16(sp)
    2ae6:	e426                	sd	s1,8(sp)
    2ae8:	1000                	addi	s0,sp,32
    2aea:	84aa                	mv	s1,a0
  if (mkdir("dir0") < 0) {
    2aec:	00004517          	auipc	a0,0x4
    2af0:	17c50513          	addi	a0,a0,380 # 6c68 <malloc+0x12b0>
    2af4:	213020ef          	jal	5506 <mkdir>
    2af8:	02054f63          	bltz	a0,2b36 <dirtest+0x56>
  if (chdir("dir0") < 0) {
    2afc:	00004517          	auipc	a0,0x4
    2b00:	16c50513          	addi	a0,a0,364 # 6c68 <malloc+0x12b0>
    2b04:	20b020ef          	jal	550e <chdir>
    2b08:	04054163          	bltz	a0,2b4a <dirtest+0x6a>
  if (chdir("..") < 0) {
    2b0c:	00004517          	auipc	a0,0x4
    2b10:	17c50513          	addi	a0,a0,380 # 6c88 <malloc+0x12d0>
    2b14:	1fb020ef          	jal	550e <chdir>
    2b18:	04054363          	bltz	a0,2b5e <dirtest+0x7e>
  if (unlink("dir0") < 0) {
    2b1c:	00004517          	auipc	a0,0x4
    2b20:	14c50513          	addi	a0,a0,332 # 6c68 <malloc+0x12b0>
    2b24:	1cb020ef          	jal	54ee <unlink>
    2b28:	04054563          	bltz	a0,2b72 <dirtest+0x92>
}
    2b2c:	60e2                	ld	ra,24(sp)
    2b2e:	6442                	ld	s0,16(sp)
    2b30:	64a2                	ld	s1,8(sp)
    2b32:	6105                	addi	sp,sp,32
    2b34:	8082                	ret
    printf("%s: mkdir failed\n", s);
    2b36:	85a6                	mv	a1,s1
    2b38:	00004517          	auipc	a0,0x4
    2b3c:	09050513          	addi	a0,a0,144 # 6bc8 <malloc+0x1210>
    2b40:	5bd020ef          	jal	58fc <printf>
    exit(1);
    2b44:	4505                	li	a0,1
    2b46:	159020ef          	jal	549e <exit>
    printf("%s: chdir dir0 failed\n", s);
    2b4a:	85a6                	mv	a1,s1
    2b4c:	00004517          	auipc	a0,0x4
    2b50:	12450513          	addi	a0,a0,292 # 6c70 <malloc+0x12b8>
    2b54:	5a9020ef          	jal	58fc <printf>
    exit(1);
    2b58:	4505                	li	a0,1
    2b5a:	145020ef          	jal	549e <exit>
    printf("%s: chdir .. failed\n", s);
    2b5e:	85a6                	mv	a1,s1
    2b60:	00004517          	auipc	a0,0x4
    2b64:	13050513          	addi	a0,a0,304 # 6c90 <malloc+0x12d8>
    2b68:	595020ef          	jal	58fc <printf>
    exit(1);
    2b6c:	4505                	li	a0,1
    2b6e:	131020ef          	jal	549e <exit>
    printf("%s: unlink dir0 failed\n", s);
    2b72:	85a6                	mv	a1,s1
    2b74:	00004517          	auipc	a0,0x4
    2b78:	13450513          	addi	a0,a0,308 # 6ca8 <malloc+0x12f0>
    2b7c:	581020ef          	jal	58fc <printf>
    exit(1);
    2b80:	4505                	li	a0,1
    2b82:	11d020ef          	jal	549e <exit>

0000000000002b86 <subdir>:
{
    2b86:	1101                	addi	sp,sp,-32
    2b88:	ec06                	sd	ra,24(sp)
    2b8a:	e822                	sd	s0,16(sp)
    2b8c:	e426                	sd	s1,8(sp)
    2b8e:	e04a                	sd	s2,0(sp)
    2b90:	1000                	addi	s0,sp,32
    2b92:	892a                	mv	s2,a0
  unlink("ff");
    2b94:	00004517          	auipc	a0,0x4
    2b98:	25c50513          	addi	a0,a0,604 # 6df0 <malloc+0x1438>
    2b9c:	153020ef          	jal	54ee <unlink>
  if (mkdir("dd") != 0) {
    2ba0:	00004517          	auipc	a0,0x4
    2ba4:	12050513          	addi	a0,a0,288 # 6cc0 <malloc+0x1308>
    2ba8:	15f020ef          	jal	5506 <mkdir>
    2bac:	2e051263          	bnez	a0,2e90 <subdir+0x30a>
  fd = open("dd/ff", O_CREATE | O_RDWR);
    2bb0:	20200593          	li	a1,514
    2bb4:	00004517          	auipc	a0,0x4
    2bb8:	12c50513          	addi	a0,a0,300 # 6ce0 <malloc+0x1328>
    2bbc:	123020ef          	jal	54de <open>
    2bc0:	84aa                	mv	s1,a0
  if (fd < 0) {
    2bc2:	2e054163          	bltz	a0,2ea4 <subdir+0x31e>
  write(fd, "ff", 2);
    2bc6:	4609                	li	a2,2
    2bc8:	00004597          	auipc	a1,0x4
    2bcc:	22858593          	addi	a1,a1,552 # 6df0 <malloc+0x1438>
    2bd0:	0ef020ef          	jal	54be <write>
  close(fd);
    2bd4:	8526                	mv	a0,s1
    2bd6:	0f1020ef          	jal	54c6 <close>
  if (unlink("dd") >= 0) {
    2bda:	00004517          	auipc	a0,0x4
    2bde:	0e650513          	addi	a0,a0,230 # 6cc0 <malloc+0x1308>
    2be2:	10d020ef          	jal	54ee <unlink>
    2be6:	2c055963          	bgez	a0,2eb8 <subdir+0x332>
  if (mkdir("/dd/dd") != 0) {
    2bea:	00004517          	auipc	a0,0x4
    2bee:	14e50513          	addi	a0,a0,334 # 6d38 <malloc+0x1380>
    2bf2:	115020ef          	jal	5506 <mkdir>
    2bf6:	2c051b63          	bnez	a0,2ecc <subdir+0x346>
  fd = open("dd/dd/ff", O_CREATE | O_RDWR);
    2bfa:	20200593          	li	a1,514
    2bfe:	00004517          	auipc	a0,0x4
    2c02:	16250513          	addi	a0,a0,354 # 6d60 <malloc+0x13a8>
    2c06:	0d9020ef          	jal	54de <open>
    2c0a:	84aa                	mv	s1,a0
  if (fd < 0) {
    2c0c:	2c054a63          	bltz	a0,2ee0 <subdir+0x35a>
  write(fd, "FF", 2);
    2c10:	4609                	li	a2,2
    2c12:	00004597          	auipc	a1,0x4
    2c16:	17e58593          	addi	a1,a1,382 # 6d90 <malloc+0x13d8>
    2c1a:	0a5020ef          	jal	54be <write>
  close(fd);
    2c1e:	8526                	mv	a0,s1
    2c20:	0a7020ef          	jal	54c6 <close>
  fd = open("dd/dd/../ff", 0);
    2c24:	4581                	li	a1,0
    2c26:	00004517          	auipc	a0,0x4
    2c2a:	17250513          	addi	a0,a0,370 # 6d98 <malloc+0x13e0>
    2c2e:	0b1020ef          	jal	54de <open>
    2c32:	84aa                	mv	s1,a0
  if (fd < 0) {
    2c34:	2c054063          	bltz	a0,2ef4 <subdir+0x36e>
  cc = read(fd, buf, sizeof(buf));
    2c38:	660d                	lui	a2,0x3
    2c3a:	0000a597          	auipc	a1,0xa
    2c3e:	0ae58593          	addi	a1,a1,174 # cce8 <buf>
    2c42:	075020ef          	jal	54b6 <read>
  if (cc != 2 || buf[0] != 'f') {
    2c46:	4789                	li	a5,2
    2c48:	2cf51063          	bne	a0,a5,2f08 <subdir+0x382>
    2c4c:	0000a717          	auipc	a4,0xa
    2c50:	09c74703          	lbu	a4,156(a4) # cce8 <buf>
    2c54:	06600793          	li	a5,102
    2c58:	2af71863          	bne	a4,a5,2f08 <subdir+0x382>
  close(fd);
    2c5c:	8526                	mv	a0,s1
    2c5e:	069020ef          	jal	54c6 <close>
  if (link("dd/dd/ff", "dd/dd/ffff") != 0) {
    2c62:	00004597          	auipc	a1,0x4
    2c66:	18658593          	addi	a1,a1,390 # 6de8 <malloc+0x1430>
    2c6a:	00004517          	auipc	a0,0x4
    2c6e:	0f650513          	addi	a0,a0,246 # 6d60 <malloc+0x13a8>
    2c72:	08d020ef          	jal	54fe <link>
    2c76:	2a051363          	bnez	a0,2f1c <subdir+0x396>
  if (unlink("dd/dd/ff") != 0) {
    2c7a:	00004517          	auipc	a0,0x4
    2c7e:	0e650513          	addi	a0,a0,230 # 6d60 <malloc+0x13a8>
    2c82:	06d020ef          	jal	54ee <unlink>
    2c86:	2a051563          	bnez	a0,2f30 <subdir+0x3aa>
  if (open("dd/dd/ff", O_RDONLY) >= 0) {
    2c8a:	4581                	li	a1,0
    2c8c:	00004517          	auipc	a0,0x4
    2c90:	0d450513          	addi	a0,a0,212 # 6d60 <malloc+0x13a8>
    2c94:	04b020ef          	jal	54de <open>
    2c98:	2a055663          	bgez	a0,2f44 <subdir+0x3be>
  if (chdir("dd") != 0) {
    2c9c:	00004517          	auipc	a0,0x4
    2ca0:	02450513          	addi	a0,a0,36 # 6cc0 <malloc+0x1308>
    2ca4:	06b020ef          	jal	550e <chdir>
    2ca8:	2a051863          	bnez	a0,2f58 <subdir+0x3d2>
  if (chdir("dd/../../dd") != 0) {
    2cac:	00004517          	auipc	a0,0x4
    2cb0:	1d450513          	addi	a0,a0,468 # 6e80 <malloc+0x14c8>
    2cb4:	05b020ef          	jal	550e <chdir>
    2cb8:	2a051a63          	bnez	a0,2f6c <subdir+0x3e6>
  if (chdir("dd/../../../dd") != 0) {
    2cbc:	00004517          	auipc	a0,0x4
    2cc0:	1f450513          	addi	a0,a0,500 # 6eb0 <malloc+0x14f8>
    2cc4:	04b020ef          	jal	550e <chdir>
    2cc8:	2a051c63          	bnez	a0,2f80 <subdir+0x3fa>
  if (chdir("./..") != 0) {
    2ccc:	00004517          	auipc	a0,0x4
    2cd0:	21c50513          	addi	a0,a0,540 # 6ee8 <malloc+0x1530>
    2cd4:	03b020ef          	jal	550e <chdir>
    2cd8:	2a051e63          	bnez	a0,2f94 <subdir+0x40e>
  fd = open("dd/dd/ffff", 0);
    2cdc:	4581                	li	a1,0
    2cde:	00004517          	auipc	a0,0x4
    2ce2:	10a50513          	addi	a0,a0,266 # 6de8 <malloc+0x1430>
    2ce6:	7f8020ef          	jal	54de <open>
    2cea:	84aa                	mv	s1,a0
  if (fd < 0) {
    2cec:	2a054e63          	bltz	a0,2fa8 <subdir+0x422>
  if (read(fd, buf, sizeof(buf)) != 2) {
    2cf0:	660d                	lui	a2,0x3
    2cf2:	0000a597          	auipc	a1,0xa
    2cf6:	ff658593          	addi	a1,a1,-10 # cce8 <buf>
    2cfa:	7bc020ef          	jal	54b6 <read>
    2cfe:	4789                	li	a5,2
    2d00:	2af51e63          	bne	a0,a5,2fbc <subdir+0x436>
  close(fd);
    2d04:	8526                	mv	a0,s1
    2d06:	7c0020ef          	jal	54c6 <close>
  if (open("dd/dd/ff", O_RDONLY) >= 0) {
    2d0a:	4581                	li	a1,0
    2d0c:	00004517          	auipc	a0,0x4
    2d10:	05450513          	addi	a0,a0,84 # 6d60 <malloc+0x13a8>
    2d14:	7ca020ef          	jal	54de <open>
    2d18:	2a055c63          	bgez	a0,2fd0 <subdir+0x44a>
  if (open("dd/ff/ff", O_CREATE | O_RDWR) >= 0) {
    2d1c:	20200593          	li	a1,514
    2d20:	00004517          	auipc	a0,0x4
    2d24:	25850513          	addi	a0,a0,600 # 6f78 <malloc+0x15c0>
    2d28:	7b6020ef          	jal	54de <open>
    2d2c:	2a055c63          	bgez	a0,2fe4 <subdir+0x45e>
  if (open("dd/xx/ff", O_CREATE | O_RDWR) >= 0) {
    2d30:	20200593          	li	a1,514
    2d34:	00004517          	auipc	a0,0x4
    2d38:	27450513          	addi	a0,a0,628 # 6fa8 <malloc+0x15f0>
    2d3c:	7a2020ef          	jal	54de <open>
    2d40:	2a055c63          	bgez	a0,2ff8 <subdir+0x472>
  if (open("dd", O_CREATE) >= 0) {
    2d44:	20000593          	li	a1,512
    2d48:	00004517          	auipc	a0,0x4
    2d4c:	f7850513          	addi	a0,a0,-136 # 6cc0 <malloc+0x1308>
    2d50:	78e020ef          	jal	54de <open>
    2d54:	2a055c63          	bgez	a0,300c <subdir+0x486>
  if (open("dd", O_RDWR) >= 0) {
    2d58:	4589                	li	a1,2
    2d5a:	00004517          	auipc	a0,0x4
    2d5e:	f6650513          	addi	a0,a0,-154 # 6cc0 <malloc+0x1308>
    2d62:	77c020ef          	jal	54de <open>
    2d66:	2a055d63          	bgez	a0,3020 <subdir+0x49a>
  if (open("dd", O_WRONLY) >= 0) {
    2d6a:	4585                	li	a1,1
    2d6c:	00004517          	auipc	a0,0x4
    2d70:	f5450513          	addi	a0,a0,-172 # 6cc0 <malloc+0x1308>
    2d74:	76a020ef          	jal	54de <open>
    2d78:	2a055e63          	bgez	a0,3034 <subdir+0x4ae>
  if (link("dd/ff/ff", "dd/dd/xx") == 0) {
    2d7c:	00004597          	auipc	a1,0x4
    2d80:	2bc58593          	addi	a1,a1,700 # 7038 <malloc+0x1680>
    2d84:	00004517          	auipc	a0,0x4
    2d88:	1f450513          	addi	a0,a0,500 # 6f78 <malloc+0x15c0>
    2d8c:	772020ef          	jal	54fe <link>
    2d90:	2a050c63          	beqz	a0,3048 <subdir+0x4c2>
  if (link("dd/xx/ff", "dd/dd/xx") == 0) {
    2d94:	00004597          	auipc	a1,0x4
    2d98:	2a458593          	addi	a1,a1,676 # 7038 <malloc+0x1680>
    2d9c:	00004517          	auipc	a0,0x4
    2da0:	20c50513          	addi	a0,a0,524 # 6fa8 <malloc+0x15f0>
    2da4:	75a020ef          	jal	54fe <link>
    2da8:	2a050a63          	beqz	a0,305c <subdir+0x4d6>
  if (link("dd/ff", "dd/dd/ffff") == 0) {
    2dac:	00004597          	auipc	a1,0x4
    2db0:	03c58593          	addi	a1,a1,60 # 6de8 <malloc+0x1430>
    2db4:	00004517          	auipc	a0,0x4
    2db8:	f2c50513          	addi	a0,a0,-212 # 6ce0 <malloc+0x1328>
    2dbc:	742020ef          	jal	54fe <link>
    2dc0:	2a050863          	beqz	a0,3070 <subdir+0x4ea>
  if (mkdir("dd/ff/ff") == 0) {
    2dc4:	00004517          	auipc	a0,0x4
    2dc8:	1b450513          	addi	a0,a0,436 # 6f78 <malloc+0x15c0>
    2dcc:	73a020ef          	jal	5506 <mkdir>
    2dd0:	2a050a63          	beqz	a0,3084 <subdir+0x4fe>
  if (mkdir("dd/xx/ff") == 0) {
    2dd4:	00004517          	auipc	a0,0x4
    2dd8:	1d450513          	addi	a0,a0,468 # 6fa8 <malloc+0x15f0>
    2ddc:	72a020ef          	jal	5506 <mkdir>
    2de0:	2a050c63          	beqz	a0,3098 <subdir+0x512>
  if (mkdir("dd/dd/ffff") == 0) {
    2de4:	00004517          	auipc	a0,0x4
    2de8:	00450513          	addi	a0,a0,4 # 6de8 <malloc+0x1430>
    2dec:	71a020ef          	jal	5506 <mkdir>
    2df0:	2a050e63          	beqz	a0,30ac <subdir+0x526>
  if (unlink("dd/xx/ff") == 0) {
    2df4:	00004517          	auipc	a0,0x4
    2df8:	1b450513          	addi	a0,a0,436 # 6fa8 <malloc+0x15f0>
    2dfc:	6f2020ef          	jal	54ee <unlink>
    2e00:	2c050063          	beqz	a0,30c0 <subdir+0x53a>
  if (unlink("dd/ff/ff") == 0) {
    2e04:	00004517          	auipc	a0,0x4
    2e08:	17450513          	addi	a0,a0,372 # 6f78 <malloc+0x15c0>
    2e0c:	6e2020ef          	jal	54ee <unlink>
    2e10:	2c050263          	beqz	a0,30d4 <subdir+0x54e>
  if (chdir("dd/ff") == 0) {
    2e14:	00004517          	auipc	a0,0x4
    2e18:	ecc50513          	addi	a0,a0,-308 # 6ce0 <malloc+0x1328>
    2e1c:	6f2020ef          	jal	550e <chdir>
    2e20:	2c050463          	beqz	a0,30e8 <subdir+0x562>
  if (chdir("dd/xx") == 0) {
    2e24:	00004517          	auipc	a0,0x4
    2e28:	36450513          	addi	a0,a0,868 # 7188 <malloc+0x17d0>
    2e2c:	6e2020ef          	jal	550e <chdir>
    2e30:	2c050663          	beqz	a0,30fc <subdir+0x576>
  if (unlink("dd/dd/ffff") != 0) {
    2e34:	00004517          	auipc	a0,0x4
    2e38:	fb450513          	addi	a0,a0,-76 # 6de8 <malloc+0x1430>
    2e3c:	6b2020ef          	jal	54ee <unlink>
    2e40:	2c051863          	bnez	a0,3110 <subdir+0x58a>
  if (unlink("dd/ff") != 0) {
    2e44:	00004517          	auipc	a0,0x4
    2e48:	e9c50513          	addi	a0,a0,-356 # 6ce0 <malloc+0x1328>
    2e4c:	6a2020ef          	jal	54ee <unlink>
    2e50:	2c051a63          	bnez	a0,3124 <subdir+0x59e>
  if (unlink("dd") == 0) {
    2e54:	00004517          	auipc	a0,0x4
    2e58:	e6c50513          	addi	a0,a0,-404 # 6cc0 <malloc+0x1308>
    2e5c:	692020ef          	jal	54ee <unlink>
    2e60:	2c050c63          	beqz	a0,3138 <subdir+0x5b2>
  if (unlink("dd/dd") < 0) {
    2e64:	00004517          	auipc	a0,0x4
    2e68:	39450513          	addi	a0,a0,916 # 71f8 <malloc+0x1840>
    2e6c:	682020ef          	jal	54ee <unlink>
    2e70:	2c054e63          	bltz	a0,314c <subdir+0x5c6>
  if (unlink("dd") < 0) {
    2e74:	00004517          	auipc	a0,0x4
    2e78:	e4c50513          	addi	a0,a0,-436 # 6cc0 <malloc+0x1308>
    2e7c:	672020ef          	jal	54ee <unlink>
    2e80:	2e054063          	bltz	a0,3160 <subdir+0x5da>
}
    2e84:	60e2                	ld	ra,24(sp)
    2e86:	6442                	ld	s0,16(sp)
    2e88:	64a2                	ld	s1,8(sp)
    2e8a:	6902                	ld	s2,0(sp)
    2e8c:	6105                	addi	sp,sp,32
    2e8e:	8082                	ret
    printf("%s: mkdir dd failed\n", s);
    2e90:	85ca                	mv	a1,s2
    2e92:	00004517          	auipc	a0,0x4
    2e96:	e3650513          	addi	a0,a0,-458 # 6cc8 <malloc+0x1310>
    2e9a:	263020ef          	jal	58fc <printf>
    exit(1);
    2e9e:	4505                	li	a0,1
    2ea0:	5fe020ef          	jal	549e <exit>
    printf("%s: create dd/ff failed\n", s);
    2ea4:	85ca                	mv	a1,s2
    2ea6:	00004517          	auipc	a0,0x4
    2eaa:	e4250513          	addi	a0,a0,-446 # 6ce8 <malloc+0x1330>
    2eae:	24f020ef          	jal	58fc <printf>
    exit(1);
    2eb2:	4505                	li	a0,1
    2eb4:	5ea020ef          	jal	549e <exit>
    printf("%s: unlink dd (non-empty dir) succeeded!\n", s);
    2eb8:	85ca                	mv	a1,s2
    2eba:	00004517          	auipc	a0,0x4
    2ebe:	e4e50513          	addi	a0,a0,-434 # 6d08 <malloc+0x1350>
    2ec2:	23b020ef          	jal	58fc <printf>
    exit(1);
    2ec6:	4505                	li	a0,1
    2ec8:	5d6020ef          	jal	549e <exit>
    printf("%s: subdir mkdir dd/dd failed\n", s);
    2ecc:	85ca                	mv	a1,s2
    2ece:	00004517          	auipc	a0,0x4
    2ed2:	e7250513          	addi	a0,a0,-398 # 6d40 <malloc+0x1388>
    2ed6:	227020ef          	jal	58fc <printf>
    exit(1);
    2eda:	4505                	li	a0,1
    2edc:	5c2020ef          	jal	549e <exit>
    printf("%s: create dd/dd/ff failed\n", s);
    2ee0:	85ca                	mv	a1,s2
    2ee2:	00004517          	auipc	a0,0x4
    2ee6:	e8e50513          	addi	a0,a0,-370 # 6d70 <malloc+0x13b8>
    2eea:	213020ef          	jal	58fc <printf>
    exit(1);
    2eee:	4505                	li	a0,1
    2ef0:	5ae020ef          	jal	549e <exit>
    printf("%s: open dd/dd/../ff failed\n", s);
    2ef4:	85ca                	mv	a1,s2
    2ef6:	00004517          	auipc	a0,0x4
    2efa:	eb250513          	addi	a0,a0,-334 # 6da8 <malloc+0x13f0>
    2efe:	1ff020ef          	jal	58fc <printf>
    exit(1);
    2f02:	4505                	li	a0,1
    2f04:	59a020ef          	jal	549e <exit>
    printf("%s: dd/dd/../ff wrong content\n", s);
    2f08:	85ca                	mv	a1,s2
    2f0a:	00004517          	auipc	a0,0x4
    2f0e:	ebe50513          	addi	a0,a0,-322 # 6dc8 <malloc+0x1410>
    2f12:	1eb020ef          	jal	58fc <printf>
    exit(1);
    2f16:	4505                	li	a0,1
    2f18:	586020ef          	jal	549e <exit>
    printf("%s: link dd/dd/ff dd/dd/ffff failed\n", s);
    2f1c:	85ca                	mv	a1,s2
    2f1e:	00004517          	auipc	a0,0x4
    2f22:	eda50513          	addi	a0,a0,-294 # 6df8 <malloc+0x1440>
    2f26:	1d7020ef          	jal	58fc <printf>
    exit(1);
    2f2a:	4505                	li	a0,1
    2f2c:	572020ef          	jal	549e <exit>
    printf("%s: unlink dd/dd/ff failed\n", s);
    2f30:	85ca                	mv	a1,s2
    2f32:	00004517          	auipc	a0,0x4
    2f36:	eee50513          	addi	a0,a0,-274 # 6e20 <malloc+0x1468>
    2f3a:	1c3020ef          	jal	58fc <printf>
    exit(1);
    2f3e:	4505                	li	a0,1
    2f40:	55e020ef          	jal	549e <exit>
    printf("%s: open (unlinked) dd/dd/ff succeeded\n", s);
    2f44:	85ca                	mv	a1,s2
    2f46:	00004517          	auipc	a0,0x4
    2f4a:	efa50513          	addi	a0,a0,-262 # 6e40 <malloc+0x1488>
    2f4e:	1af020ef          	jal	58fc <printf>
    exit(1);
    2f52:	4505                	li	a0,1
    2f54:	54a020ef          	jal	549e <exit>
    printf("%s: chdir dd failed\n", s);
    2f58:	85ca                	mv	a1,s2
    2f5a:	00004517          	auipc	a0,0x4
    2f5e:	f0e50513          	addi	a0,a0,-242 # 6e68 <malloc+0x14b0>
    2f62:	19b020ef          	jal	58fc <printf>
    exit(1);
    2f66:	4505                	li	a0,1
    2f68:	536020ef          	jal	549e <exit>
    printf("%s: chdir dd/../../dd failed\n", s);
    2f6c:	85ca                	mv	a1,s2
    2f6e:	00004517          	auipc	a0,0x4
    2f72:	f2250513          	addi	a0,a0,-222 # 6e90 <malloc+0x14d8>
    2f76:	187020ef          	jal	58fc <printf>
    exit(1);
    2f7a:	4505                	li	a0,1
    2f7c:	522020ef          	jal	549e <exit>
    printf("%s: chdir dd/../../../dd failed\n", s);
    2f80:	85ca                	mv	a1,s2
    2f82:	00004517          	auipc	a0,0x4
    2f86:	f3e50513          	addi	a0,a0,-194 # 6ec0 <malloc+0x1508>
    2f8a:	173020ef          	jal	58fc <printf>
    exit(1);
    2f8e:	4505                	li	a0,1
    2f90:	50e020ef          	jal	549e <exit>
    printf("%s: chdir ./.. failed\n", s);
    2f94:	85ca                	mv	a1,s2
    2f96:	00004517          	auipc	a0,0x4
    2f9a:	f5a50513          	addi	a0,a0,-166 # 6ef0 <malloc+0x1538>
    2f9e:	15f020ef          	jal	58fc <printf>
    exit(1);
    2fa2:	4505                	li	a0,1
    2fa4:	4fa020ef          	jal	549e <exit>
    printf("%s: open dd/dd/ffff failed\n", s);
    2fa8:	85ca                	mv	a1,s2
    2faa:	00004517          	auipc	a0,0x4
    2fae:	f5e50513          	addi	a0,a0,-162 # 6f08 <malloc+0x1550>
    2fb2:	14b020ef          	jal	58fc <printf>
    exit(1);
    2fb6:	4505                	li	a0,1
    2fb8:	4e6020ef          	jal	549e <exit>
    printf("%s: read dd/dd/ffff wrong len\n", s);
    2fbc:	85ca                	mv	a1,s2
    2fbe:	00004517          	auipc	a0,0x4
    2fc2:	f6a50513          	addi	a0,a0,-150 # 6f28 <malloc+0x1570>
    2fc6:	137020ef          	jal	58fc <printf>
    exit(1);
    2fca:	4505                	li	a0,1
    2fcc:	4d2020ef          	jal	549e <exit>
    printf("%s: open (unlinked) dd/dd/ff succeeded!\n", s);
    2fd0:	85ca                	mv	a1,s2
    2fd2:	00004517          	auipc	a0,0x4
    2fd6:	f7650513          	addi	a0,a0,-138 # 6f48 <malloc+0x1590>
    2fda:	123020ef          	jal	58fc <printf>
    exit(1);
    2fde:	4505                	li	a0,1
    2fe0:	4be020ef          	jal	549e <exit>
    printf("%s: create dd/ff/ff succeeded!\n", s);
    2fe4:	85ca                	mv	a1,s2
    2fe6:	00004517          	auipc	a0,0x4
    2fea:	fa250513          	addi	a0,a0,-94 # 6f88 <malloc+0x15d0>
    2fee:	10f020ef          	jal	58fc <printf>
    exit(1);
    2ff2:	4505                	li	a0,1
    2ff4:	4aa020ef          	jal	549e <exit>
    printf("%s: create dd/xx/ff succeeded!\n", s);
    2ff8:	85ca                	mv	a1,s2
    2ffa:	00004517          	auipc	a0,0x4
    2ffe:	fbe50513          	addi	a0,a0,-66 # 6fb8 <malloc+0x1600>
    3002:	0fb020ef          	jal	58fc <printf>
    exit(1);
    3006:	4505                	li	a0,1
    3008:	496020ef          	jal	549e <exit>
    printf("%s: create dd succeeded!\n", s);
    300c:	85ca                	mv	a1,s2
    300e:	00004517          	auipc	a0,0x4
    3012:	fca50513          	addi	a0,a0,-54 # 6fd8 <malloc+0x1620>
    3016:	0e7020ef          	jal	58fc <printf>
    exit(1);
    301a:	4505                	li	a0,1
    301c:	482020ef          	jal	549e <exit>
    printf("%s: open dd rdwr succeeded!\n", s);
    3020:	85ca                	mv	a1,s2
    3022:	00004517          	auipc	a0,0x4
    3026:	fd650513          	addi	a0,a0,-42 # 6ff8 <malloc+0x1640>
    302a:	0d3020ef          	jal	58fc <printf>
    exit(1);
    302e:	4505                	li	a0,1
    3030:	46e020ef          	jal	549e <exit>
    printf("%s: open dd wronly succeeded!\n", s);
    3034:	85ca                	mv	a1,s2
    3036:	00004517          	auipc	a0,0x4
    303a:	fe250513          	addi	a0,a0,-30 # 7018 <malloc+0x1660>
    303e:	0bf020ef          	jal	58fc <printf>
    exit(1);
    3042:	4505                	li	a0,1
    3044:	45a020ef          	jal	549e <exit>
    printf("%s: link dd/ff/ff dd/dd/xx succeeded!\n", s);
    3048:	85ca                	mv	a1,s2
    304a:	00004517          	auipc	a0,0x4
    304e:	ffe50513          	addi	a0,a0,-2 # 7048 <malloc+0x1690>
    3052:	0ab020ef          	jal	58fc <printf>
    exit(1);
    3056:	4505                	li	a0,1
    3058:	446020ef          	jal	549e <exit>
    printf("%s: link dd/xx/ff dd/dd/xx succeeded!\n", s);
    305c:	85ca                	mv	a1,s2
    305e:	00004517          	auipc	a0,0x4
    3062:	01250513          	addi	a0,a0,18 # 7070 <malloc+0x16b8>
    3066:	097020ef          	jal	58fc <printf>
    exit(1);
    306a:	4505                	li	a0,1
    306c:	432020ef          	jal	549e <exit>
    printf("%s: link dd/ff dd/dd/ffff succeeded!\n", s);
    3070:	85ca                	mv	a1,s2
    3072:	00004517          	auipc	a0,0x4
    3076:	02650513          	addi	a0,a0,38 # 7098 <malloc+0x16e0>
    307a:	083020ef          	jal	58fc <printf>
    exit(1);
    307e:	4505                	li	a0,1
    3080:	41e020ef          	jal	549e <exit>
    printf("%s: mkdir dd/ff/ff succeeded!\n", s);
    3084:	85ca                	mv	a1,s2
    3086:	00004517          	auipc	a0,0x4
    308a:	03a50513          	addi	a0,a0,58 # 70c0 <malloc+0x1708>
    308e:	06f020ef          	jal	58fc <printf>
    exit(1);
    3092:	4505                	li	a0,1
    3094:	40a020ef          	jal	549e <exit>
    printf("%s: mkdir dd/xx/ff succeeded!\n", s);
    3098:	85ca                	mv	a1,s2
    309a:	00004517          	auipc	a0,0x4
    309e:	04650513          	addi	a0,a0,70 # 70e0 <malloc+0x1728>
    30a2:	05b020ef          	jal	58fc <printf>
    exit(1);
    30a6:	4505                	li	a0,1
    30a8:	3f6020ef          	jal	549e <exit>
    printf("%s: mkdir dd/dd/ffff succeeded!\n", s);
    30ac:	85ca                	mv	a1,s2
    30ae:	00004517          	auipc	a0,0x4
    30b2:	05250513          	addi	a0,a0,82 # 7100 <malloc+0x1748>
    30b6:	047020ef          	jal	58fc <printf>
    exit(1);
    30ba:	4505                	li	a0,1
    30bc:	3e2020ef          	jal	549e <exit>
    printf("%s: unlink dd/xx/ff succeeded!\n", s);
    30c0:	85ca                	mv	a1,s2
    30c2:	00004517          	auipc	a0,0x4
    30c6:	06650513          	addi	a0,a0,102 # 7128 <malloc+0x1770>
    30ca:	033020ef          	jal	58fc <printf>
    exit(1);
    30ce:	4505                	li	a0,1
    30d0:	3ce020ef          	jal	549e <exit>
    printf("%s: unlink dd/ff/ff succeeded!\n", s);
    30d4:	85ca                	mv	a1,s2
    30d6:	00004517          	auipc	a0,0x4
    30da:	07250513          	addi	a0,a0,114 # 7148 <malloc+0x1790>
    30de:	01f020ef          	jal	58fc <printf>
    exit(1);
    30e2:	4505                	li	a0,1
    30e4:	3ba020ef          	jal	549e <exit>
    printf("%s: chdir dd/ff succeeded!\n", s);
    30e8:	85ca                	mv	a1,s2
    30ea:	00004517          	auipc	a0,0x4
    30ee:	07e50513          	addi	a0,a0,126 # 7168 <malloc+0x17b0>
    30f2:	00b020ef          	jal	58fc <printf>
    exit(1);
    30f6:	4505                	li	a0,1
    30f8:	3a6020ef          	jal	549e <exit>
    printf("%s: chdir dd/xx succeeded!\n", s);
    30fc:	85ca                	mv	a1,s2
    30fe:	00004517          	auipc	a0,0x4
    3102:	09250513          	addi	a0,a0,146 # 7190 <malloc+0x17d8>
    3106:	7f6020ef          	jal	58fc <printf>
    exit(1);
    310a:	4505                	li	a0,1
    310c:	392020ef          	jal	549e <exit>
    printf("%s: unlink dd/dd/ff failed\n", s);
    3110:	85ca                	mv	a1,s2
    3112:	00004517          	auipc	a0,0x4
    3116:	d0e50513          	addi	a0,a0,-754 # 6e20 <malloc+0x1468>
    311a:	7e2020ef          	jal	58fc <printf>
    exit(1);
    311e:	4505                	li	a0,1
    3120:	37e020ef          	jal	549e <exit>
    printf("%s: unlink dd/ff failed\n", s);
    3124:	85ca                	mv	a1,s2
    3126:	00004517          	auipc	a0,0x4
    312a:	08a50513          	addi	a0,a0,138 # 71b0 <malloc+0x17f8>
    312e:	7ce020ef          	jal	58fc <printf>
    exit(1);
    3132:	4505                	li	a0,1
    3134:	36a020ef          	jal	549e <exit>
    printf("%s: unlink non-empty dd succeeded!\n", s);
    3138:	85ca                	mv	a1,s2
    313a:	00004517          	auipc	a0,0x4
    313e:	09650513          	addi	a0,a0,150 # 71d0 <malloc+0x1818>
    3142:	7ba020ef          	jal	58fc <printf>
    exit(1);
    3146:	4505                	li	a0,1
    3148:	356020ef          	jal	549e <exit>
    printf("%s: unlink dd/dd failed\n", s);
    314c:	85ca                	mv	a1,s2
    314e:	00004517          	auipc	a0,0x4
    3152:	0b250513          	addi	a0,a0,178 # 7200 <malloc+0x1848>
    3156:	7a6020ef          	jal	58fc <printf>
    exit(1);
    315a:	4505                	li	a0,1
    315c:	342020ef          	jal	549e <exit>
    printf("%s: unlink dd failed\n", s);
    3160:	85ca                	mv	a1,s2
    3162:	00004517          	auipc	a0,0x4
    3166:	0be50513          	addi	a0,a0,190 # 7220 <malloc+0x1868>
    316a:	792020ef          	jal	58fc <printf>
    exit(1);
    316e:	4505                	li	a0,1
    3170:	32e020ef          	jal	549e <exit>

0000000000003174 <rmdot>:
{
    3174:	1101                	addi	sp,sp,-32
    3176:	ec06                	sd	ra,24(sp)
    3178:	e822                	sd	s0,16(sp)
    317a:	e426                	sd	s1,8(sp)
    317c:	1000                	addi	s0,sp,32
    317e:	84aa                	mv	s1,a0
  if (mkdir("dots") != 0) {
    3180:	00004517          	auipc	a0,0x4
    3184:	0b850513          	addi	a0,a0,184 # 7238 <malloc+0x1880>
    3188:	37e020ef          	jal	5506 <mkdir>
    318c:	e53d                	bnez	a0,31fa <rmdot+0x86>
  if (chdir("dots") != 0) {
    318e:	00004517          	auipc	a0,0x4
    3192:	0aa50513          	addi	a0,a0,170 # 7238 <malloc+0x1880>
    3196:	378020ef          	jal	550e <chdir>
    319a:	e935                	bnez	a0,320e <rmdot+0x9a>
  if (unlink(".") == 0) {
    319c:	00003517          	auipc	a0,0x3
    31a0:	03450513          	addi	a0,a0,52 # 61d0 <malloc+0x818>
    31a4:	34a020ef          	jal	54ee <unlink>
    31a8:	cd2d                	beqz	a0,3222 <rmdot+0xae>
  if (unlink("..") == 0) {
    31aa:	00004517          	auipc	a0,0x4
    31ae:	ade50513          	addi	a0,a0,-1314 # 6c88 <malloc+0x12d0>
    31b2:	33c020ef          	jal	54ee <unlink>
    31b6:	c141                	beqz	a0,3236 <rmdot+0xc2>
  if (chdir("/") != 0) {
    31b8:	00004517          	auipc	a0,0x4
    31bc:	a7850513          	addi	a0,a0,-1416 # 6c30 <malloc+0x1278>
    31c0:	34e020ef          	jal	550e <chdir>
    31c4:	e159                	bnez	a0,324a <rmdot+0xd6>
  if (unlink("dots/.") == 0) {
    31c6:	00004517          	auipc	a0,0x4
    31ca:	0da50513          	addi	a0,a0,218 # 72a0 <malloc+0x18e8>
    31ce:	320020ef          	jal	54ee <unlink>
    31d2:	c551                	beqz	a0,325e <rmdot+0xea>
  if (unlink("dots/..") == 0) {
    31d4:	00004517          	auipc	a0,0x4
    31d8:	0f450513          	addi	a0,a0,244 # 72c8 <malloc+0x1910>
    31dc:	312020ef          	jal	54ee <unlink>
    31e0:	c949                	beqz	a0,3272 <rmdot+0xfe>
  if (unlink("dots") != 0) {
    31e2:	00004517          	auipc	a0,0x4
    31e6:	05650513          	addi	a0,a0,86 # 7238 <malloc+0x1880>
    31ea:	304020ef          	jal	54ee <unlink>
    31ee:	ed41                	bnez	a0,3286 <rmdot+0x112>
}
    31f0:	60e2                	ld	ra,24(sp)
    31f2:	6442                	ld	s0,16(sp)
    31f4:	64a2                	ld	s1,8(sp)
    31f6:	6105                	addi	sp,sp,32
    31f8:	8082                	ret
    printf("%s: mkdir dots failed\n", s);
    31fa:	85a6                	mv	a1,s1
    31fc:	00004517          	auipc	a0,0x4
    3200:	04450513          	addi	a0,a0,68 # 7240 <malloc+0x1888>
    3204:	6f8020ef          	jal	58fc <printf>
    exit(1);
    3208:	4505                	li	a0,1
    320a:	294020ef          	jal	549e <exit>
    printf("%s: chdir dots failed\n", s);
    320e:	85a6                	mv	a1,s1
    3210:	00004517          	auipc	a0,0x4
    3214:	04850513          	addi	a0,a0,72 # 7258 <malloc+0x18a0>
    3218:	6e4020ef          	jal	58fc <printf>
    exit(1);
    321c:	4505                	li	a0,1
    321e:	280020ef          	jal	549e <exit>
    printf("%s: rm . worked!\n", s);
    3222:	85a6                	mv	a1,s1
    3224:	00004517          	auipc	a0,0x4
    3228:	04c50513          	addi	a0,a0,76 # 7270 <malloc+0x18b8>
    322c:	6d0020ef          	jal	58fc <printf>
    exit(1);
    3230:	4505                	li	a0,1
    3232:	26c020ef          	jal	549e <exit>
    printf("%s: rm .. worked!\n", s);
    3236:	85a6                	mv	a1,s1
    3238:	00004517          	auipc	a0,0x4
    323c:	05050513          	addi	a0,a0,80 # 7288 <malloc+0x18d0>
    3240:	6bc020ef          	jal	58fc <printf>
    exit(1);
    3244:	4505                	li	a0,1
    3246:	258020ef          	jal	549e <exit>
    printf("%s: chdir / failed\n", s);
    324a:	85a6                	mv	a1,s1
    324c:	00004517          	auipc	a0,0x4
    3250:	9ec50513          	addi	a0,a0,-1556 # 6c38 <malloc+0x1280>
    3254:	6a8020ef          	jal	58fc <printf>
    exit(1);
    3258:	4505                	li	a0,1
    325a:	244020ef          	jal	549e <exit>
    printf("%s: unlink dots/. worked!\n", s);
    325e:	85a6                	mv	a1,s1
    3260:	00004517          	auipc	a0,0x4
    3264:	04850513          	addi	a0,a0,72 # 72a8 <malloc+0x18f0>
    3268:	694020ef          	jal	58fc <printf>
    exit(1);
    326c:	4505                	li	a0,1
    326e:	230020ef          	jal	549e <exit>
    printf("%s: unlink dots/.. worked!\n", s);
    3272:	85a6                	mv	a1,s1
    3274:	00004517          	auipc	a0,0x4
    3278:	05c50513          	addi	a0,a0,92 # 72d0 <malloc+0x1918>
    327c:	680020ef          	jal	58fc <printf>
    exit(1);
    3280:	4505                	li	a0,1
    3282:	21c020ef          	jal	549e <exit>
    printf("%s: unlink dots failed!\n", s);
    3286:	85a6                	mv	a1,s1
    3288:	00004517          	auipc	a0,0x4
    328c:	06850513          	addi	a0,a0,104 # 72f0 <malloc+0x1938>
    3290:	66c020ef          	jal	58fc <printf>
    exit(1);
    3294:	4505                	li	a0,1
    3296:	208020ef          	jal	549e <exit>

000000000000329a <dirfile>:
{
    329a:	1101                	addi	sp,sp,-32
    329c:	ec06                	sd	ra,24(sp)
    329e:	e822                	sd	s0,16(sp)
    32a0:	e426                	sd	s1,8(sp)
    32a2:	e04a                	sd	s2,0(sp)
    32a4:	1000                	addi	s0,sp,32
    32a6:	892a                	mv	s2,a0
  fd = open("dirfile", O_CREATE);
    32a8:	20000593          	li	a1,512
    32ac:	00004517          	auipc	a0,0x4
    32b0:	06450513          	addi	a0,a0,100 # 7310 <malloc+0x1958>
    32b4:	22a020ef          	jal	54de <open>
  if (fd < 0) {
    32b8:	0c054563          	bltz	a0,3382 <dirfile+0xe8>
  close(fd);
    32bc:	20a020ef          	jal	54c6 <close>
  if (chdir("dirfile") == 0) {
    32c0:	00004517          	auipc	a0,0x4
    32c4:	05050513          	addi	a0,a0,80 # 7310 <malloc+0x1958>
    32c8:	246020ef          	jal	550e <chdir>
    32cc:	c569                	beqz	a0,3396 <dirfile+0xfc>
  fd = open("dirfile/xx", 0);
    32ce:	4581                	li	a1,0
    32d0:	00004517          	auipc	a0,0x4
    32d4:	08850513          	addi	a0,a0,136 # 7358 <malloc+0x19a0>
    32d8:	206020ef          	jal	54de <open>
  if (fd >= 0) {
    32dc:	0c055763          	bgez	a0,33aa <dirfile+0x110>
  fd = open("dirfile/xx", O_CREATE);
    32e0:	20000593          	li	a1,512
    32e4:	00004517          	auipc	a0,0x4
    32e8:	07450513          	addi	a0,a0,116 # 7358 <malloc+0x19a0>
    32ec:	1f2020ef          	jal	54de <open>
  if (fd >= 0) {
    32f0:	0c055763          	bgez	a0,33be <dirfile+0x124>
  if (mkdir("dirfile/xx") == 0) {
    32f4:	00004517          	auipc	a0,0x4
    32f8:	06450513          	addi	a0,a0,100 # 7358 <malloc+0x19a0>
    32fc:	20a020ef          	jal	5506 <mkdir>
    3300:	0c050963          	beqz	a0,33d2 <dirfile+0x138>
  if (unlink("dirfile/xx") == 0) {
    3304:	00004517          	auipc	a0,0x4
    3308:	05450513          	addi	a0,a0,84 # 7358 <malloc+0x19a0>
    330c:	1e2020ef          	jal	54ee <unlink>
    3310:	0c050b63          	beqz	a0,33e6 <dirfile+0x14c>
  if (link("README", "dirfile/xx") == 0) {
    3314:	00004597          	auipc	a1,0x4
    3318:	04458593          	addi	a1,a1,68 # 7358 <malloc+0x19a0>
    331c:	00003517          	auipc	a0,0x3
    3320:	9a450513          	addi	a0,a0,-1628 # 5cc0 <malloc+0x308>
    3324:	1da020ef          	jal	54fe <link>
    3328:	0c050963          	beqz	a0,33fa <dirfile+0x160>
  if (unlink("dirfile") != 0) {
    332c:	00004517          	auipc	a0,0x4
    3330:	fe450513          	addi	a0,a0,-28 # 7310 <malloc+0x1958>
    3334:	1ba020ef          	jal	54ee <unlink>
    3338:	0c051b63          	bnez	a0,340e <dirfile+0x174>
  fd = open(".", O_RDWR);
    333c:	4589                	li	a1,2
    333e:	00003517          	auipc	a0,0x3
    3342:	e9250513          	addi	a0,a0,-366 # 61d0 <malloc+0x818>
    3346:	198020ef          	jal	54de <open>
  if (fd >= 0) {
    334a:	0c055c63          	bgez	a0,3422 <dirfile+0x188>
  fd = open(".", 0);
    334e:	4581                	li	a1,0
    3350:	00003517          	auipc	a0,0x3
    3354:	e8050513          	addi	a0,a0,-384 # 61d0 <malloc+0x818>
    3358:	186020ef          	jal	54de <open>
    335c:	84aa                	mv	s1,a0
  if (write(fd, "x", 1) > 0) {
    335e:	4605                	li	a2,1
    3360:	00002597          	auipc	a1,0x2
    3364:	7f858593          	addi	a1,a1,2040 # 5b58 <malloc+0x1a0>
    3368:	156020ef          	jal	54be <write>
    336c:	0ca04563          	bgtz	a0,3436 <dirfile+0x19c>
  close(fd);
    3370:	8526                	mv	a0,s1
    3372:	154020ef          	jal	54c6 <close>
}
    3376:	60e2                	ld	ra,24(sp)
    3378:	6442                	ld	s0,16(sp)
    337a:	64a2                	ld	s1,8(sp)
    337c:	6902                	ld	s2,0(sp)
    337e:	6105                	addi	sp,sp,32
    3380:	8082                	ret
    printf("%s: create dirfile failed\n", s);
    3382:	85ca                	mv	a1,s2
    3384:	00004517          	auipc	a0,0x4
    3388:	f9450513          	addi	a0,a0,-108 # 7318 <malloc+0x1960>
    338c:	570020ef          	jal	58fc <printf>
    exit(1);
    3390:	4505                	li	a0,1
    3392:	10c020ef          	jal	549e <exit>
    printf("%s: chdir dirfile succeeded!\n", s);
    3396:	85ca                	mv	a1,s2
    3398:	00004517          	auipc	a0,0x4
    339c:	fa050513          	addi	a0,a0,-96 # 7338 <malloc+0x1980>
    33a0:	55c020ef          	jal	58fc <printf>
    exit(1);
    33a4:	4505                	li	a0,1
    33a6:	0f8020ef          	jal	549e <exit>
    printf("%s: create dirfile/xx succeeded!\n", s);
    33aa:	85ca                	mv	a1,s2
    33ac:	00004517          	auipc	a0,0x4
    33b0:	fbc50513          	addi	a0,a0,-68 # 7368 <malloc+0x19b0>
    33b4:	548020ef          	jal	58fc <printf>
    exit(1);
    33b8:	4505                	li	a0,1
    33ba:	0e4020ef          	jal	549e <exit>
    printf("%s: create dirfile/xx succeeded!\n", s);
    33be:	85ca                	mv	a1,s2
    33c0:	00004517          	auipc	a0,0x4
    33c4:	fa850513          	addi	a0,a0,-88 # 7368 <malloc+0x19b0>
    33c8:	534020ef          	jal	58fc <printf>
    exit(1);
    33cc:	4505                	li	a0,1
    33ce:	0d0020ef          	jal	549e <exit>
    printf("%s: mkdir dirfile/xx succeeded!\n", s);
    33d2:	85ca                	mv	a1,s2
    33d4:	00004517          	auipc	a0,0x4
    33d8:	fbc50513          	addi	a0,a0,-68 # 7390 <malloc+0x19d8>
    33dc:	520020ef          	jal	58fc <printf>
    exit(1);
    33e0:	4505                	li	a0,1
    33e2:	0bc020ef          	jal	549e <exit>
    printf("%s: unlink dirfile/xx succeeded!\n", s);
    33e6:	85ca                	mv	a1,s2
    33e8:	00004517          	auipc	a0,0x4
    33ec:	fd050513          	addi	a0,a0,-48 # 73b8 <malloc+0x1a00>
    33f0:	50c020ef          	jal	58fc <printf>
    exit(1);
    33f4:	4505                	li	a0,1
    33f6:	0a8020ef          	jal	549e <exit>
    printf("%s: link to dirfile/xx succeeded!\n", s);
    33fa:	85ca                	mv	a1,s2
    33fc:	00004517          	auipc	a0,0x4
    3400:	fe450513          	addi	a0,a0,-28 # 73e0 <malloc+0x1a28>
    3404:	4f8020ef          	jal	58fc <printf>
    exit(1);
    3408:	4505                	li	a0,1
    340a:	094020ef          	jal	549e <exit>
    printf("%s: unlink dirfile failed!\n", s);
    340e:	85ca                	mv	a1,s2
    3410:	00004517          	auipc	a0,0x4
    3414:	ff850513          	addi	a0,a0,-8 # 7408 <malloc+0x1a50>
    3418:	4e4020ef          	jal	58fc <printf>
    exit(1);
    341c:	4505                	li	a0,1
    341e:	080020ef          	jal	549e <exit>
    printf("%s: open . for writing succeeded!\n", s);
    3422:	85ca                	mv	a1,s2
    3424:	00004517          	auipc	a0,0x4
    3428:	00450513          	addi	a0,a0,4 # 7428 <malloc+0x1a70>
    342c:	4d0020ef          	jal	58fc <printf>
    exit(1);
    3430:	4505                	li	a0,1
    3432:	06c020ef          	jal	549e <exit>
    printf("%s: write . succeeded!\n", s);
    3436:	85ca                	mv	a1,s2
    3438:	00004517          	auipc	a0,0x4
    343c:	01850513          	addi	a0,a0,24 # 7450 <malloc+0x1a98>
    3440:	4bc020ef          	jal	58fc <printf>
    exit(1);
    3444:	4505                	li	a0,1
    3446:	058020ef          	jal	549e <exit>

000000000000344a <iref>:
{
    344a:	715d                	addi	sp,sp,-80
    344c:	e486                	sd	ra,72(sp)
    344e:	e0a2                	sd	s0,64(sp)
    3450:	fc26                	sd	s1,56(sp)
    3452:	f84a                	sd	s2,48(sp)
    3454:	f44e                	sd	s3,40(sp)
    3456:	f052                	sd	s4,32(sp)
    3458:	ec56                	sd	s5,24(sp)
    345a:	e85a                	sd	s6,16(sp)
    345c:	e45e                	sd	s7,8(sp)
    345e:	0880                	addi	s0,sp,80
    3460:	8baa                	mv	s7,a0
    3462:	03300913          	li	s2,51
    if (mkdir("irefd") != 0) {
    3466:	00004a97          	auipc	s5,0x4
    346a:	002a8a93          	addi	s5,s5,2 # 7468 <malloc+0x1ab0>
    mkdir("");
    346e:	00004497          	auipc	s1,0x4
    3472:	b0248493          	addi	s1,s1,-1278 # 6f70 <malloc+0x15b8>
    link("README", "");
    3476:	00003b17          	auipc	s6,0x3
    347a:	84ab0b13          	addi	s6,s6,-1974 # 5cc0 <malloc+0x308>
    fd = open("", O_CREATE);
    347e:	20000a13          	li	s4,512
    fd = open("xx", O_CREATE);
    3482:	00004997          	auipc	s3,0x4
    3486:	ede98993          	addi	s3,s3,-290 # 7360 <malloc+0x19a8>
    348a:	a835                	j	34c6 <iref+0x7c>
      printf("%s: mkdir irefd failed\n", s);
    348c:	85de                	mv	a1,s7
    348e:	00004517          	auipc	a0,0x4
    3492:	fe250513          	addi	a0,a0,-30 # 7470 <malloc+0x1ab8>
    3496:	466020ef          	jal	58fc <printf>
      exit(1);
    349a:	4505                	li	a0,1
    349c:	002020ef          	jal	549e <exit>
      printf("%s: chdir irefd failed\n", s);
    34a0:	85de                	mv	a1,s7
    34a2:	00004517          	auipc	a0,0x4
    34a6:	fe650513          	addi	a0,a0,-26 # 7488 <malloc+0x1ad0>
    34aa:	452020ef          	jal	58fc <printf>
      exit(1);
    34ae:	4505                	li	a0,1
    34b0:	7ef010ef          	jal	549e <exit>
      close(fd);
    34b4:	012020ef          	jal	54c6 <close>
    34b8:	a825                	j	34f0 <iref+0xa6>
    unlink("xx");
    34ba:	854e                	mv	a0,s3
    34bc:	032020ef          	jal	54ee <unlink>
  for (i = 0; i < NINODE + 1; i++) {
    34c0:	397d                	addiw	s2,s2,-1
    34c2:	04090063          	beqz	s2,3502 <iref+0xb8>
    if (mkdir("irefd") != 0) {
    34c6:	8556                	mv	a0,s5
    34c8:	03e020ef          	jal	5506 <mkdir>
    34cc:	f161                	bnez	a0,348c <iref+0x42>
    if (chdir("irefd") != 0) {
    34ce:	8556                	mv	a0,s5
    34d0:	03e020ef          	jal	550e <chdir>
    34d4:	f571                	bnez	a0,34a0 <iref+0x56>
    mkdir("");
    34d6:	8526                	mv	a0,s1
    34d8:	02e020ef          	jal	5506 <mkdir>
    link("README", "");
    34dc:	85a6                	mv	a1,s1
    34de:	855a                	mv	a0,s6
    34e0:	01e020ef          	jal	54fe <link>
    fd = open("", O_CREATE);
    34e4:	85d2                	mv	a1,s4
    34e6:	8526                	mv	a0,s1
    34e8:	7f7010ef          	jal	54de <open>
    if (fd >= 0)
    34ec:	fc0554e3          	bgez	a0,34b4 <iref+0x6a>
    fd = open("xx", O_CREATE);
    34f0:	85d2                	mv	a1,s4
    34f2:	854e                	mv	a0,s3
    34f4:	7eb010ef          	jal	54de <open>
    if (fd >= 0)
    34f8:	fc0541e3          	bltz	a0,34ba <iref+0x70>
      close(fd);
    34fc:	7cb010ef          	jal	54c6 <close>
    3500:	bf6d                	j	34ba <iref+0x70>
  for (i = 0; i < NINODE + 1; i++) {
    3502:	03300493          	li	s1,51
    chdir("..");
    3506:	00003997          	auipc	s3,0x3
    350a:	78298993          	addi	s3,s3,1922 # 6c88 <malloc+0x12d0>
    unlink("irefd");
    350e:	00004917          	auipc	s2,0x4
    3512:	f5a90913          	addi	s2,s2,-166 # 7468 <malloc+0x1ab0>
    chdir("..");
    3516:	854e                	mv	a0,s3
    3518:	7f7010ef          	jal	550e <chdir>
    unlink("irefd");
    351c:	854a                	mv	a0,s2
    351e:	7d1010ef          	jal	54ee <unlink>
  for (i = 0; i < NINODE + 1; i++) {
    3522:	34fd                	addiw	s1,s1,-1
    3524:	f8ed                	bnez	s1,3516 <iref+0xcc>
  chdir("/");
    3526:	00003517          	auipc	a0,0x3
    352a:	70a50513          	addi	a0,a0,1802 # 6c30 <malloc+0x1278>
    352e:	7e1010ef          	jal	550e <chdir>
}
    3532:	60a6                	ld	ra,72(sp)
    3534:	6406                	ld	s0,64(sp)
    3536:	74e2                	ld	s1,56(sp)
    3538:	7942                	ld	s2,48(sp)
    353a:	79a2                	ld	s3,40(sp)
    353c:	7a02                	ld	s4,32(sp)
    353e:	6ae2                	ld	s5,24(sp)
    3540:	6b42                	ld	s6,16(sp)
    3542:	6ba2                	ld	s7,8(sp)
    3544:	6161                	addi	sp,sp,80
    3546:	8082                	ret

0000000000003548 <unlinkcwd>:
{
    3548:	1101                	addi	sp,sp,-32
    354a:	ec06                	sd	ra,24(sp)
    354c:	e822                	sd	s0,16(sp)
    354e:	e426                	sd	s1,8(sp)
    3550:	1000                	addi	s0,sp,32
    3552:	84aa                	mv	s1,a0
  if (mkdir("/a") < 0) {
    3554:	00004517          	auipc	a0,0x4
    3558:	f4c50513          	addi	a0,a0,-180 # 74a0 <malloc+0x1ae8>
    355c:	7ab010ef          	jal	5506 <mkdir>
    3560:	06054a63          	bltz	a0,35d4 <unlinkcwd+0x8c>
  if (mkdir("/a/b") < 0) {
    3564:	00004517          	auipc	a0,0x4
    3568:	f5c50513          	addi	a0,a0,-164 # 74c0 <malloc+0x1b08>
    356c:	79b010ef          	jal	5506 <mkdir>
    3570:	06054c63          	bltz	a0,35e8 <unlinkcwd+0xa0>
  if (chdir("/a/b") < 0) {
    3574:	00004517          	auipc	a0,0x4
    3578:	f4c50513          	addi	a0,a0,-180 # 74c0 <malloc+0x1b08>
    357c:	793010ef          	jal	550e <chdir>
    3580:	06054e63          	bltz	a0,35fc <unlinkcwd+0xb4>
  if (unlink("/a/b") < 0) {
    3584:	00004517          	auipc	a0,0x4
    3588:	f3c50513          	addi	a0,a0,-196 # 74c0 <malloc+0x1b08>
    358c:	763010ef          	jal	54ee <unlink>
    3590:	08054063          	bltz	a0,3610 <unlinkcwd+0xc8>
  if (unlink("/a") < 0) {
    3594:	00004517          	auipc	a0,0x4
    3598:	f0c50513          	addi	a0,a0,-244 # 74a0 <malloc+0x1ae8>
    359c:	753010ef          	jal	54ee <unlink>
    35a0:	08054263          	bltz	a0,3624 <unlinkcwd+0xdc>
  if (open("../", O_RDONLY) > 0) {
    35a4:	4581                	li	a1,0
    35a6:	00004517          	auipc	a0,0x4
    35aa:	f8250513          	addi	a0,a0,-126 # 7528 <malloc+0x1b70>
    35ae:	731010ef          	jal	54de <open>
    35b2:	08a04363          	bgtz	a0,3638 <unlinkcwd+0xf0>
  if (open("../c", O_CREATE) > 0) {
    35b6:	20000593          	li	a1,512
    35ba:	00004517          	auipc	a0,0x4
    35be:	f9e50513          	addi	a0,a0,-98 # 7558 <malloc+0x1ba0>
    35c2:	71d010ef          	jal	54de <open>
    35c6:	08a04163          	bgtz	a0,3648 <unlinkcwd+0x100>
}
    35ca:	60e2                	ld	ra,24(sp)
    35cc:	6442                	ld	s0,16(sp)
    35ce:	64a2                	ld	s1,8(sp)
    35d0:	6105                	addi	sp,sp,32
    35d2:	8082                	ret
    printf("%s: mkdir /a failed\n", s);
    35d4:	85a6                	mv	a1,s1
    35d6:	00004517          	auipc	a0,0x4
    35da:	ed250513          	addi	a0,a0,-302 # 74a8 <malloc+0x1af0>
    35de:	31e020ef          	jal	58fc <printf>
    exit(1);
    35e2:	4505                	li	a0,1
    35e4:	6bb010ef          	jal	549e <exit>
    printf("%s: mkdir /a/b failed\n", s);
    35e8:	85a6                	mv	a1,s1
    35ea:	00004517          	auipc	a0,0x4
    35ee:	ede50513          	addi	a0,a0,-290 # 74c8 <malloc+0x1b10>
    35f2:	30a020ef          	jal	58fc <printf>
    exit(1);
    35f6:	4505                	li	a0,1
    35f8:	6a7010ef          	jal	549e <exit>
    printf("%s: chdir failed\n", s);
    35fc:	85a6                	mv	a1,s1
    35fe:	00004517          	auipc	a0,0x4
    3602:	ee250513          	addi	a0,a0,-286 # 74e0 <malloc+0x1b28>
    3606:	2f6020ef          	jal	58fc <printf>
    exit(1);
    360a:	4505                	li	a0,1
    360c:	693010ef          	jal	549e <exit>
    printf("%s: unlink /a/b failed\n", s);
    3610:	85a6                	mv	a1,s1
    3612:	00004517          	auipc	a0,0x4
    3616:	ee650513          	addi	a0,a0,-282 # 74f8 <malloc+0x1b40>
    361a:	2e2020ef          	jal	58fc <printf>
    exit(1);
    361e:	4505                	li	a0,1
    3620:	67f010ef          	jal	549e <exit>
    printf("%s: unlink /a failed\n", s);
    3624:	85a6                	mv	a1,s1
    3626:	00004517          	auipc	a0,0x4
    362a:	eea50513          	addi	a0,a0,-278 # 7510 <malloc+0x1b58>
    362e:	2ce020ef          	jal	58fc <printf>
    exit(1);
    3632:	4505                	li	a0,1
    3634:	66b010ef          	jal	549e <exit>
    printf("%s: open ../ non-existing directory\n", s);
    3638:	85a6                	mv	a1,s1
    363a:	00004517          	auipc	a0,0x4
    363e:	ef650513          	addi	a0,a0,-266 # 7530 <malloc+0x1b78>
    3642:	2ba020ef          	jal	58fc <printf>
    3646:	bf85                	j	35b6 <unlinkcwd+0x6e>
    printf("%s: create ../c non-existing file\n", s);
    3648:	85a6                	mv	a1,s1
    364a:	00004517          	auipc	a0,0x4
    364e:	f1650513          	addi	a0,a0,-234 # 7560 <malloc+0x1ba8>
    3652:	2aa020ef          	jal	58fc <printf>
}
    3656:	bf95                	j	35ca <unlinkcwd+0x82>

0000000000003658 <openiputtest>:
{
    3658:	7179                	addi	sp,sp,-48
    365a:	f406                	sd	ra,40(sp)
    365c:	f022                	sd	s0,32(sp)
    365e:	ec26                	sd	s1,24(sp)
    3660:	1800                	addi	s0,sp,48
    3662:	84aa                	mv	s1,a0
  if (mkdir("oidir") < 0) {
    3664:	00004517          	auipc	a0,0x4
    3668:	f2450513          	addi	a0,a0,-220 # 7588 <malloc+0x1bd0>
    366c:	69b010ef          	jal	5506 <mkdir>
    3670:	02054a63          	bltz	a0,36a4 <openiputtest+0x4c>
  pid = fork();
    3674:	623010ef          	jal	5496 <fork>
  if (pid < 0) {
    3678:	04054063          	bltz	a0,36b8 <openiputtest+0x60>
  if (pid == 0) {
    367c:	e939                	bnez	a0,36d2 <openiputtest+0x7a>
    int fd = open("oidir", O_RDWR);
    367e:	4589                	li	a1,2
    3680:	00004517          	auipc	a0,0x4
    3684:	f0850513          	addi	a0,a0,-248 # 7588 <malloc+0x1bd0>
    3688:	657010ef          	jal	54de <open>
    if (fd >= 0) {
    368c:	04054063          	bltz	a0,36cc <openiputtest+0x74>
      printf("%s: open directory for write succeeded\n", s);
    3690:	85a6                	mv	a1,s1
    3692:	00004517          	auipc	a0,0x4
    3696:	f1650513          	addi	a0,a0,-234 # 75a8 <malloc+0x1bf0>
    369a:	262020ef          	jal	58fc <printf>
      exit(1);
    369e:	4505                	li	a0,1
    36a0:	5ff010ef          	jal	549e <exit>
    printf("%s: mkdir oidir failed\n", s);
    36a4:	85a6                	mv	a1,s1
    36a6:	00004517          	auipc	a0,0x4
    36aa:	eea50513          	addi	a0,a0,-278 # 7590 <malloc+0x1bd8>
    36ae:	24e020ef          	jal	58fc <printf>
    exit(1);
    36b2:	4505                	li	a0,1
    36b4:	5eb010ef          	jal	549e <exit>
    printf("%s: fork failed\n", s);
    36b8:	85a6                	mv	a1,s1
    36ba:	00003517          	auipc	a0,0x3
    36be:	cbe50513          	addi	a0,a0,-834 # 6378 <malloc+0x9c0>
    36c2:	23a020ef          	jal	58fc <printf>
    exit(1);
    36c6:	4505                	li	a0,1
    36c8:	5d7010ef          	jal	549e <exit>
    exit(0);
    36cc:	4501                	li	a0,0
    36ce:	5d1010ef          	jal	549e <exit>
  pause(1);
    36d2:	4505                	li	a0,1
    36d4:	65b010ef          	jal	552e <pause>
  if (unlink("oidir") != 0) {
    36d8:	00004517          	auipc	a0,0x4
    36dc:	eb050513          	addi	a0,a0,-336 # 7588 <malloc+0x1bd0>
    36e0:	60f010ef          	jal	54ee <unlink>
    36e4:	c919                	beqz	a0,36fa <openiputtest+0xa2>
    printf("%s: unlink failed\n", s);
    36e6:	85a6                	mv	a1,s1
    36e8:	00003517          	auipc	a0,0x3
    36ec:	e1850513          	addi	a0,a0,-488 # 6500 <malloc+0xb48>
    36f0:	20c020ef          	jal	58fc <printf>
    exit(1);
    36f4:	4505                	li	a0,1
    36f6:	5a9010ef          	jal	549e <exit>
  wait(&xstatus);
    36fa:	fdc40513          	addi	a0,s0,-36
    36fe:	5a9010ef          	jal	54a6 <wait>
  exit(xstatus);
    3702:	fdc42503          	lw	a0,-36(s0)
    3706:	599010ef          	jal	549e <exit>

000000000000370a <forkforkfork>:
{
    370a:	1101                	addi	sp,sp,-32
    370c:	ec06                	sd	ra,24(sp)
    370e:	e822                	sd	s0,16(sp)
    3710:	e426                	sd	s1,8(sp)
    3712:	1000                	addi	s0,sp,32
    3714:	84aa                	mv	s1,a0
  unlink("stopforking");
    3716:	00004517          	auipc	a0,0x4
    371a:	eba50513          	addi	a0,a0,-326 # 75d0 <malloc+0x1c18>
    371e:	5d1010ef          	jal	54ee <unlink>
  int pid = fork();
    3722:	575010ef          	jal	5496 <fork>
  if (pid < 0) {
    3726:	02054b63          	bltz	a0,375c <forkforkfork+0x52>
  if (pid == 0) {
    372a:	c125                	beqz	a0,378a <forkforkfork+0x80>
  pause(20); // two seconds
    372c:	4551                	li	a0,20
    372e:	601010ef          	jal	552e <pause>
  close(open("stopforking", O_CREATE | O_RDWR));
    3732:	20200593          	li	a1,514
    3736:	00004517          	auipc	a0,0x4
    373a:	e9a50513          	addi	a0,a0,-358 # 75d0 <malloc+0x1c18>
    373e:	5a1010ef          	jal	54de <open>
    3742:	585010ef          	jal	54c6 <close>
  wait(0);
    3746:	4501                	li	a0,0
    3748:	55f010ef          	jal	54a6 <wait>
  pause(10); // one second
    374c:	4529                	li	a0,10
    374e:	5e1010ef          	jal	552e <pause>
}
    3752:	60e2                	ld	ra,24(sp)
    3754:	6442                	ld	s0,16(sp)
    3756:	64a2                	ld	s1,8(sp)
    3758:	6105                	addi	sp,sp,32
    375a:	8082                	ret
    printf("%s: fork failed", s);
    375c:	85a6                	mv	a1,s1
    375e:	00003517          	auipc	a0,0x3
    3762:	d5a50513          	addi	a0,a0,-678 # 64b8 <malloc+0xb00>
    3766:	196020ef          	jal	58fc <printf>
    exit(1);
    376a:	4505                	li	a0,1
    376c:	533010ef          	jal	549e <exit>
        exit(0);
    3770:	4501                	li	a0,0
    3772:	52d010ef          	jal	549e <exit>
        close(open("stopforking", O_CREATE | O_RDWR));
    3776:	20200593          	li	a1,514
    377a:	00004517          	auipc	a0,0x4
    377e:	e5650513          	addi	a0,a0,-426 # 75d0 <malloc+0x1c18>
    3782:	55d010ef          	jal	54de <open>
    3786:	541010ef          	jal	54c6 <close>
      int fd = open("stopforking", 0);
    378a:	4581                	li	a1,0
    378c:	00004517          	auipc	a0,0x4
    3790:	e4450513          	addi	a0,a0,-444 # 75d0 <malloc+0x1c18>
    3794:	54b010ef          	jal	54de <open>
      if (fd >= 0) {
    3798:	fc055ce3          	bgez	a0,3770 <forkforkfork+0x66>
      if (fork() < 0) {
    379c:	4fb010ef          	jal	5496 <fork>
    37a0:	fe0555e3          	bgez	a0,378a <forkforkfork+0x80>
    37a4:	bfc9                	j	3776 <forkforkfork+0x6c>

00000000000037a6 <exectest>:
{
    37a6:	711d                	addi	sp,sp,-96
    37a8:	ec86                	sd	ra,88(sp)
    37aa:	e8a2                	sd	s0,80(sp)
    37ac:	e0ca                	sd	s2,64(sp)
    37ae:	1080                	addi	s0,sp,96
    37b0:	892a                	mv	s2,a0
  char *echoargv[] = {"echo", "OK", 0};
    37b2:	00002797          	auipc	a5,0x2
    37b6:	33678793          	addi	a5,a5,822 # 5ae8 <malloc+0x130>
    37ba:	faf43823          	sd	a5,-80(s0)
    37be:	00004797          	auipc	a5,0x4
    37c2:	e2278793          	addi	a5,a5,-478 # 75e0 <malloc+0x1c28>
    37c6:	faf43c23          	sd	a5,-72(s0)
    37ca:	fc043023          	sd	zero,-64(s0)
  unlink("echo-ok");
    37ce:	00004517          	auipc	a0,0x4
    37d2:	e1a50513          	addi	a0,a0,-486 # 75e8 <malloc+0x1c30>
    37d6:	519010ef          	jal	54ee <unlink>
  pid = fork();
    37da:	4bd010ef          	jal	5496 <fork>
  if (pid < 0) {
    37de:	04054763          	bltz	a0,382c <exectest+0x86>
    37e2:	e4a6                	sd	s1,72(sp)
    37e4:	fc4e                	sd	s3,56(sp)
    37e6:	84aa                	mv	s1,a0
  if (pid == 0) {
    37e8:	ed49                	bnez	a0,3882 <exectest+0xdc>
    int errfd = dup(1);
    37ea:	4505                	li	a0,1
    37ec:	52b010ef          	jal	5516 <dup>
    37f0:	89aa                	mv	s3,a0
    if (errfd < 0) {
    37f2:	04054963          	bltz	a0,3844 <exectest+0x9e>
    close(1);
    37f6:	4505                	li	a0,1
    37f8:	4cf010ef          	jal	54c6 <close>
    fd = open("echo-ok", O_CREATE | O_WRONLY);
    37fc:	20100593          	li	a1,513
    3800:	00004517          	auipc	a0,0x4
    3804:	de850513          	addi	a0,a0,-536 # 75e8 <malloc+0x1c30>
    3808:	4d7010ef          	jal	54de <open>
    if (fd < 0) {
    380c:	04054663          	bltz	a0,3858 <exectest+0xb2>
    if (fd != 1) {
    3810:	4785                	li	a5,1
    3812:	04f50e63          	beq	a0,a5,386e <exectest+0xc8>
      fprintf(errfd, "%s: wrong fd\n", s);
    3816:	864a                	mv	a2,s2
    3818:	00004597          	auipc	a1,0x4
    381c:	de858593          	addi	a1,a1,-536 # 7600 <malloc+0x1c48>
    3820:	854e                	mv	a0,s3
    3822:	0b0020ef          	jal	58d2 <fprintf>
      exit(1);
    3826:	4505                	li	a0,1
    3828:	477010ef          	jal	549e <exit>
    382c:	e4a6                	sd	s1,72(sp)
    382e:	fc4e                	sd	s3,56(sp)
    printf("%s: fork failed\n", s);
    3830:	85ca                	mv	a1,s2
    3832:	00003517          	auipc	a0,0x3
    3836:	b4650513          	addi	a0,a0,-1210 # 6378 <malloc+0x9c0>
    383a:	0c2020ef          	jal	58fc <printf>
    exit(1);
    383e:	4505                	li	a0,1
    3840:	45f010ef          	jal	549e <exit>
      printf("%s: dup failed\n", s);
    3844:	85ca                	mv	a1,s2
    3846:	00004517          	auipc	a0,0x4
    384a:	daa50513          	addi	a0,a0,-598 # 75f0 <malloc+0x1c38>
    384e:	0ae020ef          	jal	58fc <printf>
      exit(1);
    3852:	4505                	li	a0,1
    3854:	44b010ef          	jal	549e <exit>
      fprintf(errfd, "%s: create failed\n", s);
    3858:	864a                	mv	a2,s2
    385a:	00003597          	auipc	a1,0x3
    385e:	c8e58593          	addi	a1,a1,-882 # 64e8 <malloc+0xb30>
    3862:	854e                	mv	a0,s3
    3864:	06e020ef          	jal	58d2 <fprintf>
      exit(1);
    3868:	4505                	li	a0,1
    386a:	435010ef          	jal	549e <exit>
    if (exec("echo", echoargv) < 0) {
    386e:	fb040593          	addi	a1,s0,-80
    3872:	00002517          	auipc	a0,0x2
    3876:	27650513          	addi	a0,a0,630 # 5ae8 <malloc+0x130>
    387a:	45d010ef          	jal	54d6 <exec>
    387e:	02054563          	bltz	a0,38a8 <exectest+0x102>
  if (wait(&xstatus) != pid) {
    3882:	fcc40513          	addi	a0,s0,-52
    3886:	421010ef          	jal	54a6 <wait>
    388a:	02951a63          	bne	a0,s1,38be <exectest+0x118>
  if (xstatus != 0) {
    388e:	fcc42603          	lw	a2,-52(s0)
    3892:	ce15                	beqz	a2,38ce <exectest+0x128>
    printf("%s: nonzero wait status %d\n", s, xstatus);
    3894:	85ca                	mv	a1,s2
    3896:	00004517          	auipc	a0,0x4
    389a:	daa50513          	addi	a0,a0,-598 # 7640 <malloc+0x1c88>
    389e:	05e020ef          	jal	58fc <printf>
    exit(1);
    38a2:	4505                	li	a0,1
    38a4:	3fb010ef          	jal	549e <exit>
      fprintf(errfd, "%s: exec echo failed\n", s);
    38a8:	864a                	mv	a2,s2
    38aa:	00004597          	auipc	a1,0x4
    38ae:	d6658593          	addi	a1,a1,-666 # 7610 <malloc+0x1c58>
    38b2:	854e                	mv	a0,s3
    38b4:	01e020ef          	jal	58d2 <fprintf>
      exit(1);
    38b8:	4505                	li	a0,1
    38ba:	3e5010ef          	jal	549e <exit>
    printf("%s: wait failed!\n", s);
    38be:	85ca                	mv	a1,s2
    38c0:	00004517          	auipc	a0,0x4
    38c4:	d6850513          	addi	a0,a0,-664 # 7628 <malloc+0x1c70>
    38c8:	034020ef          	jal	58fc <printf>
    38cc:	b7c9                	j	388e <exectest+0xe8>
  fd = open("echo-ok", O_RDONLY);
    38ce:	4581                	li	a1,0
    38d0:	00004517          	auipc	a0,0x4
    38d4:	d1850513          	addi	a0,a0,-744 # 75e8 <malloc+0x1c30>
    38d8:	407010ef          	jal	54de <open>
  if (fd < 0) {
    38dc:	02054463          	bltz	a0,3904 <exectest+0x15e>
  if (read(fd, buf, 2) != 2) {
    38e0:	4609                	li	a2,2
    38e2:	fa840593          	addi	a1,s0,-88
    38e6:	3d1010ef          	jal	54b6 <read>
    38ea:	4789                	li	a5,2
    38ec:	02f50663          	beq	a0,a5,3918 <exectest+0x172>
    printf("%s: read failed\n", s);
    38f0:	85ca                	mv	a1,s2
    38f2:	00002517          	auipc	a0,0x2
    38f6:	5c650513          	addi	a0,a0,1478 # 5eb8 <malloc+0x500>
    38fa:	002020ef          	jal	58fc <printf>
    exit(1);
    38fe:	4505                	li	a0,1
    3900:	39f010ef          	jal	549e <exit>
    printf("%s: open failed\n", s);
    3904:	85ca                	mv	a1,s2
    3906:	00003517          	auipc	a0,0x3
    390a:	a8a50513          	addi	a0,a0,-1398 # 6390 <malloc+0x9d8>
    390e:	7ef010ef          	jal	58fc <printf>
    exit(1);
    3912:	4505                	li	a0,1
    3914:	38b010ef          	jal	549e <exit>
  unlink("echo-ok");
    3918:	00004517          	auipc	a0,0x4
    391c:	cd050513          	addi	a0,a0,-816 # 75e8 <malloc+0x1c30>
    3920:	3cf010ef          	jal	54ee <unlink>
  if (buf[0] == 'O' && buf[1] == 'K')
    3924:	fa844703          	lbu	a4,-88(s0)
    3928:	04f00793          	li	a5,79
    392c:	00f71863          	bne	a4,a5,393c <exectest+0x196>
    3930:	fa944703          	lbu	a4,-87(s0)
    3934:	04b00793          	li	a5,75
    3938:	00f70c63          	beq	a4,a5,3950 <exectest+0x1aa>
    printf("%s: wrong output\n", s);
    393c:	85ca                	mv	a1,s2
    393e:	00004517          	auipc	a0,0x4
    3942:	d2250513          	addi	a0,a0,-734 # 7660 <malloc+0x1ca8>
    3946:	7b7010ef          	jal	58fc <printf>
    exit(1);
    394a:	4505                	li	a0,1
    394c:	353010ef          	jal	549e <exit>
    exit(0);
    3950:	4501                	li	a0,0
    3952:	34d010ef          	jal	549e <exit>

0000000000003956 <killstatus>:
{
    3956:	715d                	addi	sp,sp,-80
    3958:	e486                	sd	ra,72(sp)
    395a:	e0a2                	sd	s0,64(sp)
    395c:	fc26                	sd	s1,56(sp)
    395e:	f84a                	sd	s2,48(sp)
    3960:	f44e                	sd	s3,40(sp)
    3962:	f052                	sd	s4,32(sp)
    3964:	ec56                	sd	s5,24(sp)
    3966:	e85a                	sd	s6,16(sp)
    3968:	0880                	addi	s0,sp,80
    396a:	8b2a                	mv	s6,a0
    396c:	06400913          	li	s2,100
    pause(1);
    3970:	4a85                	li	s5,1
    wait(&xst);
    3972:	fbc40a13          	addi	s4,s0,-68
    if (xst != -1) {
    3976:	59fd                	li	s3,-1
    int pid1 = fork();
    3978:	31f010ef          	jal	5496 <fork>
    397c:	84aa                	mv	s1,a0
    if (pid1 < 0) {
    397e:	02054663          	bltz	a0,39aa <killstatus+0x54>
    if (pid1 == 0) {
    3982:	cd15                	beqz	a0,39be <killstatus+0x68>
    pause(1);
    3984:	8556                	mv	a0,s5
    3986:	3a9010ef          	jal	552e <pause>
    kill(pid1);
    398a:	8526                	mv	a0,s1
    398c:	343010ef          	jal	54ce <kill>
    wait(&xst);
    3990:	8552                	mv	a0,s4
    3992:	315010ef          	jal	54a6 <wait>
    if (xst != -1) {
    3996:	fbc42783          	lw	a5,-68(s0)
    399a:	03379563          	bne	a5,s3,39c4 <killstatus+0x6e>
  for (int i = 0; i < 100; i++) {
    399e:	397d                	addiw	s2,s2,-1
    39a0:	fc091ce3          	bnez	s2,3978 <killstatus+0x22>
  exit(0);
    39a4:	4501                	li	a0,0
    39a6:	2f9010ef          	jal	549e <exit>
      printf("%s: fork failed\n", s);
    39aa:	85da                	mv	a1,s6
    39ac:	00003517          	auipc	a0,0x3
    39b0:	9cc50513          	addi	a0,a0,-1588 # 6378 <malloc+0x9c0>
    39b4:	749010ef          	jal	58fc <printf>
      exit(1);
    39b8:	4505                	li	a0,1
    39ba:	2e5010ef          	jal	549e <exit>
        getpid();
    39be:	361010ef          	jal	551e <getpid>
      while (1) {
    39c2:	bff5                	j	39be <killstatus+0x68>
      printf("%s: status should be -1\n", s);
    39c4:	85da                	mv	a1,s6
    39c6:	00004517          	auipc	a0,0x4
    39ca:	cb250513          	addi	a0,a0,-846 # 7678 <malloc+0x1cc0>
    39ce:	72f010ef          	jal	58fc <printf>
      exit(1);
    39d2:	4505                	li	a0,1
    39d4:	2cb010ef          	jal	549e <exit>

00000000000039d8 <preempt>:
{
    39d8:	7139                	addi	sp,sp,-64
    39da:	fc06                	sd	ra,56(sp)
    39dc:	f822                	sd	s0,48(sp)
    39de:	f426                	sd	s1,40(sp)
    39e0:	f04a                	sd	s2,32(sp)
    39e2:	ec4e                	sd	s3,24(sp)
    39e4:	e852                	sd	s4,16(sp)
    39e6:	0080                	addi	s0,sp,64
    39e8:	892a                	mv	s2,a0
  pid1 = fork();
    39ea:	2ad010ef          	jal	5496 <fork>
  if (pid1 < 0) {
    39ee:	00054563          	bltz	a0,39f8 <preempt+0x20>
    39f2:	84aa                	mv	s1,a0
  if (pid1 == 0)
    39f4:	ed01                	bnez	a0,3a0c <preempt+0x34>
    for (;;)
    39f6:	a001                	j	39f6 <preempt+0x1e>
    printf("%s: fork failed", s);
    39f8:	85ca                	mv	a1,s2
    39fa:	00003517          	auipc	a0,0x3
    39fe:	abe50513          	addi	a0,a0,-1346 # 64b8 <malloc+0xb00>
    3a02:	6fb010ef          	jal	58fc <printf>
    exit(1);
    3a06:	4505                	li	a0,1
    3a08:	297010ef          	jal	549e <exit>
  pid2 = fork();
    3a0c:	28b010ef          	jal	5496 <fork>
    3a10:	89aa                	mv	s3,a0
  if (pid2 < 0) {
    3a12:	00054463          	bltz	a0,3a1a <preempt+0x42>
  if (pid2 == 0)
    3a16:	ed01                	bnez	a0,3a2e <preempt+0x56>
    for (;;)
    3a18:	a001                	j	3a18 <preempt+0x40>
    printf("%s: fork failed\n", s);
    3a1a:	85ca                	mv	a1,s2
    3a1c:	00003517          	auipc	a0,0x3
    3a20:	95c50513          	addi	a0,a0,-1700 # 6378 <malloc+0x9c0>
    3a24:	6d9010ef          	jal	58fc <printf>
    exit(1);
    3a28:	4505                	li	a0,1
    3a2a:	275010ef          	jal	549e <exit>
  pipe(pfds);
    3a2e:	fc840513          	addi	a0,s0,-56
    3a32:	27d010ef          	jal	54ae <pipe>
  pid3 = fork();
    3a36:	261010ef          	jal	5496 <fork>
    3a3a:	8a2a                	mv	s4,a0
  if (pid3 < 0) {
    3a3c:	02054863          	bltz	a0,3a6c <preempt+0x94>
  if (pid3 == 0) {
    3a40:	e921                	bnez	a0,3a90 <preempt+0xb8>
    close(pfds[0]);
    3a42:	fc842503          	lw	a0,-56(s0)
    3a46:	281010ef          	jal	54c6 <close>
    if (write(pfds[1], "x", 1) != 1)
    3a4a:	4605                	li	a2,1
    3a4c:	00002597          	auipc	a1,0x2
    3a50:	10c58593          	addi	a1,a1,268 # 5b58 <malloc+0x1a0>
    3a54:	fcc42503          	lw	a0,-52(s0)
    3a58:	267010ef          	jal	54be <write>
    3a5c:	4785                	li	a5,1
    3a5e:	02f51163          	bne	a0,a5,3a80 <preempt+0xa8>
    close(pfds[1]);
    3a62:	fcc42503          	lw	a0,-52(s0)
    3a66:	261010ef          	jal	54c6 <close>
    for (;;)
    3a6a:	a001                	j	3a6a <preempt+0x92>
    printf("%s: fork failed\n", s);
    3a6c:	85ca                	mv	a1,s2
    3a6e:	00003517          	auipc	a0,0x3
    3a72:	90a50513          	addi	a0,a0,-1782 # 6378 <malloc+0x9c0>
    3a76:	687010ef          	jal	58fc <printf>
    exit(1);
    3a7a:	4505                	li	a0,1
    3a7c:	223010ef          	jal	549e <exit>
      printf("%s: preempt write error", s);
    3a80:	85ca                	mv	a1,s2
    3a82:	00004517          	auipc	a0,0x4
    3a86:	c1650513          	addi	a0,a0,-1002 # 7698 <malloc+0x1ce0>
    3a8a:	673010ef          	jal	58fc <printf>
    3a8e:	bfd1                	j	3a62 <preempt+0x8a>
  close(pfds[1]);
    3a90:	fcc42503          	lw	a0,-52(s0)
    3a94:	233010ef          	jal	54c6 <close>
  if (read(pfds[0], buf, sizeof(buf)) != 1) {
    3a98:	660d                	lui	a2,0x3
    3a9a:	00009597          	auipc	a1,0x9
    3a9e:	24e58593          	addi	a1,a1,590 # cce8 <buf>
    3aa2:	fc842503          	lw	a0,-56(s0)
    3aa6:	211010ef          	jal	54b6 <read>
    3aaa:	4785                	li	a5,1
    3aac:	00f50a63          	beq	a0,a5,3ac0 <preempt+0xe8>
    printf("%s: preempt read error", s);
    3ab0:	85ca                	mv	a1,s2
    3ab2:	00004517          	auipc	a0,0x4
    3ab6:	bfe50513          	addi	a0,a0,-1026 # 76b0 <malloc+0x1cf8>
    3aba:	643010ef          	jal	58fc <printf>
    return;
    3abe:	a099                	j	3b04 <preempt+0x12c>
  close(pfds[0]);
    3ac0:	fc842503          	lw	a0,-56(s0)
    3ac4:	203010ef          	jal	54c6 <close>
  printf("kill... ");
    3ac8:	00004517          	auipc	a0,0x4
    3acc:	c0050513          	addi	a0,a0,-1024 # 76c8 <malloc+0x1d10>
    3ad0:	62d010ef          	jal	58fc <printf>
  kill(pid1);
    3ad4:	8526                	mv	a0,s1
    3ad6:	1f9010ef          	jal	54ce <kill>
  kill(pid2);
    3ada:	854e                	mv	a0,s3
    3adc:	1f3010ef          	jal	54ce <kill>
  kill(pid3);
    3ae0:	8552                	mv	a0,s4
    3ae2:	1ed010ef          	jal	54ce <kill>
  printf("wait... ");
    3ae6:	00004517          	auipc	a0,0x4
    3aea:	bf250513          	addi	a0,a0,-1038 # 76d8 <malloc+0x1d20>
    3aee:	60f010ef          	jal	58fc <printf>
  wait(0);
    3af2:	4501                	li	a0,0
    3af4:	1b3010ef          	jal	54a6 <wait>
  wait(0);
    3af8:	4501                	li	a0,0
    3afa:	1ad010ef          	jal	54a6 <wait>
  wait(0);
    3afe:	4501                	li	a0,0
    3b00:	1a7010ef          	jal	54a6 <wait>
}
    3b04:	70e2                	ld	ra,56(sp)
    3b06:	7442                	ld	s0,48(sp)
    3b08:	74a2                	ld	s1,40(sp)
    3b0a:	7902                	ld	s2,32(sp)
    3b0c:	69e2                	ld	s3,24(sp)
    3b0e:	6a42                	ld	s4,16(sp)
    3b10:	6121                	addi	sp,sp,64
    3b12:	8082                	ret

0000000000003b14 <reparent>:
{
    3b14:	7179                	addi	sp,sp,-48
    3b16:	f406                	sd	ra,40(sp)
    3b18:	f022                	sd	s0,32(sp)
    3b1a:	ec26                	sd	s1,24(sp)
    3b1c:	e84a                	sd	s2,16(sp)
    3b1e:	e44e                	sd	s3,8(sp)
    3b20:	e052                	sd	s4,0(sp)
    3b22:	1800                	addi	s0,sp,48
    3b24:	89aa                	mv	s3,a0
  int master_pid = getpid();
    3b26:	1f9010ef          	jal	551e <getpid>
    3b2a:	8a2a                	mv	s4,a0
    3b2c:	0c800913          	li	s2,200
    int pid = fork();
    3b30:	167010ef          	jal	5496 <fork>
    3b34:	84aa                	mv	s1,a0
    if (pid < 0) {
    3b36:	00054e63          	bltz	a0,3b52 <reparent+0x3e>
    if (pid) {
    3b3a:	c121                	beqz	a0,3b7a <reparent+0x66>
      if (wait(0) != pid) {
    3b3c:	4501                	li	a0,0
    3b3e:	169010ef          	jal	54a6 <wait>
    3b42:	02951263          	bne	a0,s1,3b66 <reparent+0x52>
  for (int i = 0; i < 200; i++) {
    3b46:	397d                	addiw	s2,s2,-1
    3b48:	fe0914e3          	bnez	s2,3b30 <reparent+0x1c>
  exit(0);
    3b4c:	4501                	li	a0,0
    3b4e:	151010ef          	jal	549e <exit>
      printf("%s: fork failed\n", s);
    3b52:	85ce                	mv	a1,s3
    3b54:	00003517          	auipc	a0,0x3
    3b58:	82450513          	addi	a0,a0,-2012 # 6378 <malloc+0x9c0>
    3b5c:	5a1010ef          	jal	58fc <printf>
      exit(1);
    3b60:	4505                	li	a0,1
    3b62:	13d010ef          	jal	549e <exit>
        printf("%s: wait wrong pid\n", s);
    3b66:	85ce                	mv	a1,s3
    3b68:	00003517          	auipc	a0,0x3
    3b6c:	91850513          	addi	a0,a0,-1768 # 6480 <malloc+0xac8>
    3b70:	58d010ef          	jal	58fc <printf>
        exit(1);
    3b74:	4505                	li	a0,1
    3b76:	129010ef          	jal	549e <exit>
      int pid2 = fork();
    3b7a:	11d010ef          	jal	5496 <fork>
      if (pid2 < 0) {
    3b7e:	00054563          	bltz	a0,3b88 <reparent+0x74>
      exit(0);
    3b82:	4501                	li	a0,0
    3b84:	11b010ef          	jal	549e <exit>
        kill(master_pid);
    3b88:	8552                	mv	a0,s4
    3b8a:	145010ef          	jal	54ce <kill>
        exit(1);
    3b8e:	4505                	li	a0,1
    3b90:	10f010ef          	jal	549e <exit>

0000000000003b94 <sbrkfail>:
{
    3b94:	7175                	addi	sp,sp,-144
    3b96:	e506                	sd	ra,136(sp)
    3b98:	e122                	sd	s0,128(sp)
    3b9a:	fca6                	sd	s1,120(sp)
    3b9c:	f8ca                	sd	s2,112(sp)
    3b9e:	f4ce                	sd	s3,104(sp)
    3ba0:	f0d2                	sd	s4,96(sp)
    3ba2:	ecd6                	sd	s5,88(sp)
    3ba4:	e8da                	sd	s6,80(sp)
    3ba6:	e4de                	sd	s7,72(sp)
    3ba8:	e0e2                	sd	s8,64(sp)
    3baa:	0900                	addi	s0,sp,144
    3bac:	8c2a                	mv	s8,a0
  if (pipe(fds) != 0) {
    3bae:	fa040513          	addi	a0,s0,-96
    3bb2:	0fd010ef          	jal	54ae <pipe>
    3bb6:	ed01                	bnez	a0,3bce <sbrkfail+0x3a>
    3bb8:	8baa                	mv	s7,a0
    3bba:	f7040493          	addi	s1,s0,-144
    3bbe:	f9840993          	addi	s3,s0,-104
    3bc2:	8926                	mv	s2,s1
    if (pids[i] != -1) {
    3bc4:	5a7d                	li	s4,-1
      read(fds[0], &scratch, 1);
    3bc6:	f9f40b13          	addi	s6,s0,-97
    3bca:	4a85                	li	s5,1
    3bcc:	a095                	j	3c30 <sbrkfail+0x9c>
    printf("%s: pipe() failed\n", s);
    3bce:	85e2                	mv	a1,s8
    3bd0:	00003517          	auipc	a0,0x3
    3bd4:	83050513          	addi	a0,a0,-2000 # 6400 <malloc+0xa48>
    3bd8:	525010ef          	jal	58fc <printf>
    exit(1);
    3bdc:	4505                	li	a0,1
    3bde:	0c1010ef          	jal	549e <exit>
      if (sbrk(BIG - (uint64)sbrk(0)) == (char *)SBRK_ERROR)
    3be2:	089010ef          	jal	546a <sbrk>
    3be6:	064007b7          	lui	a5,0x6400
    3bea:	40a7853b          	subw	a0,a5,a0
    3bee:	07d010ef          	jal	546a <sbrk>
    3bf2:	57fd                	li	a5,-1
    3bf4:	02f50163          	beq	a0,a5,3c16 <sbrkfail+0x82>
        write(fds[1], "1", 1);
    3bf8:	4605                	li	a2,1
    3bfa:	00004597          	auipc	a1,0x4
    3bfe:	3de58593          	addi	a1,a1,990 # 7fd8 <malloc+0x2620>
    3c02:	fa442503          	lw	a0,-92(s0)
    3c06:	0b9010ef          	jal	54be <write>
        pause(1000);
    3c0a:	3e800493          	li	s1,1000
    3c0e:	8526                	mv	a0,s1
    3c10:	11f010ef          	jal	552e <pause>
      for (;;)
    3c14:	bfed                	j	3c0e <sbrkfail+0x7a>
        write(fds[1], "0", 1);
    3c16:	4605                	li	a2,1
    3c18:	00004597          	auipc	a1,0x4
    3c1c:	ad058593          	addi	a1,a1,-1328 # 76e8 <malloc+0x1d30>
    3c20:	fa442503          	lw	a0,-92(s0)
    3c24:	09b010ef          	jal	54be <write>
    3c28:	b7cd                	j	3c0a <sbrkfail+0x76>
  for (i = 0; i < sizeof(pids) / sizeof(pids[0]); i++) {
    3c2a:	0911                	addi	s2,s2,4
    3c2c:	03390a63          	beq	s2,s3,3c60 <sbrkfail+0xcc>
    if ((pids[i] = fork()) == 0) {
    3c30:	067010ef          	jal	5496 <fork>
    3c34:	00a92023          	sw	a0,0(s2)
    3c38:	d54d                	beqz	a0,3be2 <sbrkfail+0x4e>
    if (pids[i] != -1) {
    3c3a:	ff4508e3          	beq	a0,s4,3c2a <sbrkfail+0x96>
      read(fds[0], &scratch, 1);
    3c3e:	8656                	mv	a2,s5
    3c40:	85da                	mv	a1,s6
    3c42:	fa042503          	lw	a0,-96(s0)
    3c46:	071010ef          	jal	54b6 <read>
      if (scratch == '0')
    3c4a:	f9f44783          	lbu	a5,-97(s0)
    3c4e:	fd078793          	addi	a5,a5,-48 # 63fffd0 <base+0x63f02e8>
    3c52:	0017b793          	seqz	a5,a5
    3c56:	00fbe7b3          	or	a5,s7,a5
    3c5a:	00078b9b          	sext.w	s7,a5
    3c5e:	b7f1                	j	3c2a <sbrkfail+0x96>
  if (!failed) {
    3c60:	000b8863          	beqz	s7,3c70 <sbrkfail+0xdc>
  c = sbrk(PGSIZE);
    3c64:	6505                	lui	a0,0x1
    3c66:	005010ef          	jal	546a <sbrk>
    3c6a:	8a2a                	mv	s4,a0
    if (pids[i] == -1)
    3c6c:	597d                	li	s2,-1
    3c6e:	a821                	j	3c86 <sbrkfail+0xf2>
    printf("%s: no allocation failed; allocate more?\n", s);
    3c70:	85e2                	mv	a1,s8
    3c72:	00004517          	auipc	a0,0x4
    3c76:	a7e50513          	addi	a0,a0,-1410 # 76f0 <malloc+0x1d38>
    3c7a:	483010ef          	jal	58fc <printf>
    3c7e:	b7dd                	j	3c64 <sbrkfail+0xd0>
  for (i = 0; i < sizeof(pids) / sizeof(pids[0]); i++) {
    3c80:	0491                	addi	s1,s1,4
    3c82:	01348b63          	beq	s1,s3,3c98 <sbrkfail+0x104>
    if (pids[i] == -1)
    3c86:	4088                	lw	a0,0(s1)
    3c88:	ff250ce3          	beq	a0,s2,3c80 <sbrkfail+0xec>
    kill(pids[i]);
    3c8c:	043010ef          	jal	54ce <kill>
    wait(0);
    3c90:	4501                	li	a0,0
    3c92:	015010ef          	jal	54a6 <wait>
    3c96:	b7ed                	j	3c80 <sbrkfail+0xec>
  if (c == (char *)SBRK_ERROR) {
    3c98:	57fd                	li	a5,-1
    3c9a:	02fa0a63          	beq	s4,a5,3cce <sbrkfail+0x13a>
  pid = fork();
    3c9e:	7f8010ef          	jal	5496 <fork>
  if (pid < 0) {
    3ca2:	04054063          	bltz	a0,3ce2 <sbrkfail+0x14e>
  if (pid == 0) {
    3ca6:	e939                	bnez	a0,3cfc <sbrkfail+0x168>
    a = sbrk(10 * BIG);
    3ca8:	3e800537          	lui	a0,0x3e800
    3cac:	7be010ef          	jal	546a <sbrk>
    if (a == (char *)SBRK_ERROR) {
    3cb0:	57fd                	li	a5,-1
    3cb2:	04f50263          	beq	a0,a5,3cf6 <sbrkfail+0x162>
    printf("%s: allocate a lot of memory succeeded %d\n", s, 10 * BIG);
    3cb6:	3e800637          	lui	a2,0x3e800
    3cba:	85e2                	mv	a1,s8
    3cbc:	00004517          	auipc	a0,0x4
    3cc0:	a8450513          	addi	a0,a0,-1404 # 7740 <malloc+0x1d88>
    3cc4:	439010ef          	jal	58fc <printf>
    exit(1);
    3cc8:	4505                	li	a0,1
    3cca:	7d4010ef          	jal	549e <exit>
    printf("%s: failed sbrk leaked memory\n", s);
    3cce:	85e2                	mv	a1,s8
    3cd0:	00004517          	auipc	a0,0x4
    3cd4:	a5050513          	addi	a0,a0,-1456 # 7720 <malloc+0x1d68>
    3cd8:	425010ef          	jal	58fc <printf>
    exit(1);
    3cdc:	4505                	li	a0,1
    3cde:	7c0010ef          	jal	549e <exit>
    printf("%s: fork failed\n", s);
    3ce2:	85e2                	mv	a1,s8
    3ce4:	00002517          	auipc	a0,0x2
    3ce8:	69450513          	addi	a0,a0,1684 # 6378 <malloc+0x9c0>
    3cec:	411010ef          	jal	58fc <printf>
    exit(1);
    3cf0:	4505                	li	a0,1
    3cf2:	7ac010ef          	jal	549e <exit>
      exit(0);
    3cf6:	4501                	li	a0,0
    3cf8:	7a6010ef          	jal	549e <exit>
  wait(&xstatus);
    3cfc:	fac40513          	addi	a0,s0,-84
    3d00:	7a6010ef          	jal	54a6 <wait>
  if (xstatus != 0)
    3d04:	fac42783          	lw	a5,-84(s0)
    3d08:	ef89                	bnez	a5,3d22 <sbrkfail+0x18e>
}
    3d0a:	60aa                	ld	ra,136(sp)
    3d0c:	640a                	ld	s0,128(sp)
    3d0e:	74e6                	ld	s1,120(sp)
    3d10:	7946                	ld	s2,112(sp)
    3d12:	79a6                	ld	s3,104(sp)
    3d14:	7a06                	ld	s4,96(sp)
    3d16:	6ae6                	ld	s5,88(sp)
    3d18:	6b46                	ld	s6,80(sp)
    3d1a:	6ba6                	ld	s7,72(sp)
    3d1c:	6c06                	ld	s8,64(sp)
    3d1e:	6149                	addi	sp,sp,144
    3d20:	8082                	ret
    exit(1);
    3d22:	4505                	li	a0,1
    3d24:	77a010ef          	jal	549e <exit>

0000000000003d28 <mem>:
{
    3d28:	7139                	addi	sp,sp,-64
    3d2a:	fc06                	sd	ra,56(sp)
    3d2c:	f822                	sd	s0,48(sp)
    3d2e:	f426                	sd	s1,40(sp)
    3d30:	f04a                	sd	s2,32(sp)
    3d32:	ec4e                	sd	s3,24(sp)
    3d34:	0080                	addi	s0,sp,64
    3d36:	89aa                	mv	s3,a0
  if ((pid = fork()) == 0) {
    3d38:	75e010ef          	jal	5496 <fork>
    m1 = 0;
    3d3c:	4481                	li	s1,0
    while ((m2 = malloc(10001)) != 0) {
    3d3e:	6909                	lui	s2,0x2
    3d40:	71190913          	addi	s2,s2,1809 # 2711 <fourteen+0xf1>
  if ((pid = fork()) == 0) {
    3d44:	cd11                	beqz	a0,3d60 <mem+0x38>
    wait(&xstatus);
    3d46:	fcc40513          	addi	a0,s0,-52
    3d4a:	75c010ef          	jal	54a6 <wait>
    if (xstatus == -1) {
    3d4e:	fcc42503          	lw	a0,-52(s0)
    3d52:	57fd                	li	a5,-1
    3d54:	04f50363          	beq	a0,a5,3d9a <mem+0x72>
    exit(xstatus);
    3d58:	746010ef          	jal	549e <exit>
      *(char **)m2 = m1;
    3d5c:	e104                	sd	s1,0(a0)
      m1 = m2;
    3d5e:	84aa                	mv	s1,a0
    while ((m2 = malloc(10001)) != 0) {
    3d60:	854a                	mv	a0,s2
    3d62:	457010ef          	jal	59b8 <malloc>
    3d66:	f97d                	bnez	a0,3d5c <mem+0x34>
    while (m1) {
    3d68:	c491                	beqz	s1,3d74 <mem+0x4c>
      m2 = *(char **)m1;
    3d6a:	8526                	mv	a0,s1
    3d6c:	6084                	ld	s1,0(s1)
      free(m1);
    3d6e:	3c1010ef          	jal	592e <free>
    while (m1) {
    3d72:	fce5                	bnez	s1,3d6a <mem+0x42>
    m1 = malloc(1024 * 20);
    3d74:	6515                	lui	a0,0x5
    3d76:	443010ef          	jal	59b8 <malloc>
    if (m1 == 0) {
    3d7a:	c511                	beqz	a0,3d86 <mem+0x5e>
    free(m1);
    3d7c:	3b3010ef          	jal	592e <free>
    exit(0);
    3d80:	4501                	li	a0,0
    3d82:	71c010ef          	jal	549e <exit>
      printf("%s: couldn't allocate mem?!!\n", s);
    3d86:	85ce                	mv	a1,s3
    3d88:	00004517          	auipc	a0,0x4
    3d8c:	9e850513          	addi	a0,a0,-1560 # 7770 <malloc+0x1db8>
    3d90:	36d010ef          	jal	58fc <printf>
      exit(1);
    3d94:	4505                	li	a0,1
    3d96:	708010ef          	jal	549e <exit>
      exit(0);
    3d9a:	4501                	li	a0,0
    3d9c:	702010ef          	jal	549e <exit>

0000000000003da0 <sharedfd>:
{
    3da0:	7159                	addi	sp,sp,-112
    3da2:	f486                	sd	ra,104(sp)
    3da4:	f0a2                	sd	s0,96(sp)
    3da6:	eca6                	sd	s1,88(sp)
    3da8:	f85a                	sd	s6,48(sp)
    3daa:	1880                	addi	s0,sp,112
    3dac:	84aa                	mv	s1,a0
    3dae:	8b2a                	mv	s6,a0
  unlink("sharedfd");
    3db0:	00004517          	auipc	a0,0x4
    3db4:	9e050513          	addi	a0,a0,-1568 # 7790 <malloc+0x1dd8>
    3db8:	736010ef          	jal	54ee <unlink>
  fd = open("sharedfd", O_CREATE | O_RDWR);
    3dbc:	20200593          	li	a1,514
    3dc0:	00004517          	auipc	a0,0x4
    3dc4:	9d050513          	addi	a0,a0,-1584 # 7790 <malloc+0x1dd8>
    3dc8:	716010ef          	jal	54de <open>
  if (fd < 0) {
    3dcc:	04054863          	bltz	a0,3e1c <sharedfd+0x7c>
    3dd0:	e8ca                	sd	s2,80(sp)
    3dd2:	e4ce                	sd	s3,72(sp)
    3dd4:	e0d2                	sd	s4,64(sp)
    3dd6:	fc56                	sd	s5,56(sp)
    3dd8:	89aa                	mv	s3,a0
  pid = fork();
    3dda:	6bc010ef          	jal	5496 <fork>
    3dde:	8aaa                	mv	s5,a0
  memset(buf, pid == 0 ? 'c' : 'p', sizeof(buf));
    3de0:	07000593          	li	a1,112
    3de4:	e119                	bnez	a0,3dea <sharedfd+0x4a>
    3de6:	06300593          	li	a1,99
    3dea:	4629                	li	a2,10
    3dec:	fa040513          	addi	a0,s0,-96
    3df0:	484010ef          	jal	5274 <memset>
    3df4:	3e800493          	li	s1,1000
    if (write(fd, buf, sizeof(buf)) != sizeof(buf)) {
    3df8:	fa040a13          	addi	s4,s0,-96
    3dfc:	4929                	li	s2,10
    3dfe:	864a                	mv	a2,s2
    3e00:	85d2                	mv	a1,s4
    3e02:	854e                	mv	a0,s3
    3e04:	6ba010ef          	jal	54be <write>
    3e08:	03251963          	bne	a0,s2,3e3a <sharedfd+0x9a>
  for (i = 0; i < N; i++) {
    3e0c:	34fd                	addiw	s1,s1,-1
    3e0e:	f8e5                	bnez	s1,3dfe <sharedfd+0x5e>
  if (pid == 0) {
    3e10:	040a9063          	bnez	s5,3e50 <sharedfd+0xb0>
    3e14:	f45e                	sd	s7,40(sp)
    exit(0);
    3e16:	4501                	li	a0,0
    3e18:	686010ef          	jal	549e <exit>
    3e1c:	e8ca                	sd	s2,80(sp)
    3e1e:	e4ce                	sd	s3,72(sp)
    3e20:	e0d2                	sd	s4,64(sp)
    3e22:	fc56                	sd	s5,56(sp)
    3e24:	f45e                	sd	s7,40(sp)
    printf("%s: cannot open sharedfd for writing", s);
    3e26:	85a6                	mv	a1,s1
    3e28:	00004517          	auipc	a0,0x4
    3e2c:	97850513          	addi	a0,a0,-1672 # 77a0 <malloc+0x1de8>
    3e30:	2cd010ef          	jal	58fc <printf>
    exit(1);
    3e34:	4505                	li	a0,1
    3e36:	668010ef          	jal	549e <exit>
    3e3a:	f45e                	sd	s7,40(sp)
      printf("%s: write sharedfd failed\n", s);
    3e3c:	85da                	mv	a1,s6
    3e3e:	00004517          	auipc	a0,0x4
    3e42:	98a50513          	addi	a0,a0,-1654 # 77c8 <malloc+0x1e10>
    3e46:	2b7010ef          	jal	58fc <printf>
      exit(1);
    3e4a:	4505                	li	a0,1
    3e4c:	652010ef          	jal	549e <exit>
    wait(&xstatus);
    3e50:	f9c40513          	addi	a0,s0,-100
    3e54:	652010ef          	jal	54a6 <wait>
    if (xstatus != 0)
    3e58:	f9c42a03          	lw	s4,-100(s0)
    3e5c:	000a0663          	beqz	s4,3e68 <sharedfd+0xc8>
    3e60:	f45e                	sd	s7,40(sp)
      exit(xstatus);
    3e62:	8552                	mv	a0,s4
    3e64:	63a010ef          	jal	549e <exit>
    3e68:	f45e                	sd	s7,40(sp)
  close(fd);
    3e6a:	854e                	mv	a0,s3
    3e6c:	65a010ef          	jal	54c6 <close>
  fd = open("sharedfd", 0);
    3e70:	4581                	li	a1,0
    3e72:	00004517          	auipc	a0,0x4
    3e76:	91e50513          	addi	a0,a0,-1762 # 7790 <malloc+0x1dd8>
    3e7a:	664010ef          	jal	54de <open>
    3e7e:	8baa                	mv	s7,a0
  nc = np = 0;
    3e80:	89d2                	mv	s3,s4
  if (fd < 0) {
    3e82:	02054363          	bltz	a0,3ea8 <sharedfd+0x108>
    3e86:	faa40913          	addi	s2,s0,-86
      if (buf[i] == 'c')
    3e8a:	06300493          	li	s1,99
      if (buf[i] == 'p')
    3e8e:	07000a93          	li	s5,112
  while ((n = read(fd, buf, sizeof(buf))) > 0) {
    3e92:	4629                	li	a2,10
    3e94:	fa040593          	addi	a1,s0,-96
    3e98:	855e                	mv	a0,s7
    3e9a:	61c010ef          	jal	54b6 <read>
    3e9e:	02a05b63          	blez	a0,3ed4 <sharedfd+0x134>
    3ea2:	fa040793          	addi	a5,s0,-96
    3ea6:	a839                	j	3ec4 <sharedfd+0x124>
    printf("%s: cannot open sharedfd for reading\n", s);
    3ea8:	85da                	mv	a1,s6
    3eaa:	00004517          	auipc	a0,0x4
    3eae:	93e50513          	addi	a0,a0,-1730 # 77e8 <malloc+0x1e30>
    3eb2:	24b010ef          	jal	58fc <printf>
    exit(1);
    3eb6:	4505                	li	a0,1
    3eb8:	5e6010ef          	jal	549e <exit>
        nc++;
    3ebc:	2a05                	addiw	s4,s4,1
    for (i = 0; i < sizeof(buf); i++) {
    3ebe:	0785                	addi	a5,a5,1
    3ec0:	fd2789e3          	beq	a5,s2,3e92 <sharedfd+0xf2>
      if (buf[i] == 'c')
    3ec4:	0007c703          	lbu	a4,0(a5)
    3ec8:	fe970ae3          	beq	a4,s1,3ebc <sharedfd+0x11c>
      if (buf[i] == 'p')
    3ecc:	ff5719e3          	bne	a4,s5,3ebe <sharedfd+0x11e>
        np++;
    3ed0:	2985                	addiw	s3,s3,1
    3ed2:	b7f5                	j	3ebe <sharedfd+0x11e>
  close(fd);
    3ed4:	855e                	mv	a0,s7
    3ed6:	5f0010ef          	jal	54c6 <close>
  unlink("sharedfd");
    3eda:	00004517          	auipc	a0,0x4
    3ede:	8b650513          	addi	a0,a0,-1866 # 7790 <malloc+0x1dd8>
    3ee2:	60c010ef          	jal	54ee <unlink>
  if (nc == N * SZ && np == N * SZ) {
    3ee6:	6789                	lui	a5,0x2
    3ee8:	71078793          	addi	a5,a5,1808 # 2710 <fourteen+0xf0>
    3eec:	00fa1763          	bne	s4,a5,3efa <sharedfd+0x15a>
    3ef0:	01499563          	bne	s3,s4,3efa <sharedfd+0x15a>
    exit(0);
    3ef4:	4501                	li	a0,0
    3ef6:	5a8010ef          	jal	549e <exit>
    printf("%s: nc/np test fails\n", s);
    3efa:	85da                	mv	a1,s6
    3efc:	00004517          	auipc	a0,0x4
    3f00:	91450513          	addi	a0,a0,-1772 # 7810 <malloc+0x1e58>
    3f04:	1f9010ef          	jal	58fc <printf>
    exit(1);
    3f08:	4505                	li	a0,1
    3f0a:	594010ef          	jal	549e <exit>

0000000000003f0e <fourfiles>:
{
    3f0e:	7135                	addi	sp,sp,-160
    3f10:	ed06                	sd	ra,152(sp)
    3f12:	e922                	sd	s0,144(sp)
    3f14:	e526                	sd	s1,136(sp)
    3f16:	e14a                	sd	s2,128(sp)
    3f18:	fcce                	sd	s3,120(sp)
    3f1a:	f8d2                	sd	s4,112(sp)
    3f1c:	f4d6                	sd	s5,104(sp)
    3f1e:	f0da                	sd	s6,96(sp)
    3f20:	ecde                	sd	s7,88(sp)
    3f22:	e8e2                	sd	s8,80(sp)
    3f24:	e4e6                	sd	s9,72(sp)
    3f26:	e0ea                	sd	s10,64(sp)
    3f28:	fc6e                	sd	s11,56(sp)
    3f2a:	1100                	addi	s0,sp,160
    3f2c:	8caa                	mv	s9,a0
  char *names[] = {"f0", "f1", "f2", "f3"};
    3f2e:	00004797          	auipc	a5,0x4
    3f32:	8fa78793          	addi	a5,a5,-1798 # 7828 <malloc+0x1e70>
    3f36:	f6f43823          	sd	a5,-144(s0)
    3f3a:	00004797          	auipc	a5,0x4
    3f3e:	8f678793          	addi	a5,a5,-1802 # 7830 <malloc+0x1e78>
    3f42:	f6f43c23          	sd	a5,-136(s0)
    3f46:	00004797          	auipc	a5,0x4
    3f4a:	8f278793          	addi	a5,a5,-1806 # 7838 <malloc+0x1e80>
    3f4e:	f8f43023          	sd	a5,-128(s0)
    3f52:	00004797          	auipc	a5,0x4
    3f56:	8ee78793          	addi	a5,a5,-1810 # 7840 <malloc+0x1e88>
    3f5a:	f8f43423          	sd	a5,-120(s0)
  for (pi = 0; pi < NCHILD; pi++) {
    3f5e:	f7040b93          	addi	s7,s0,-144
  char *names[] = {"f0", "f1", "f2", "f3"};
    3f62:	895e                	mv	s2,s7
  for (pi = 0; pi < NCHILD; pi++) {
    3f64:	4481                	li	s1,0
    3f66:	4a11                	li	s4,4
    fname = names[pi];
    3f68:	00093983          	ld	s3,0(s2)
    unlink(fname);
    3f6c:	854e                	mv	a0,s3
    3f6e:	580010ef          	jal	54ee <unlink>
    pid = fork();
    3f72:	524010ef          	jal	5496 <fork>
    if (pid < 0) {
    3f76:	04054063          	bltz	a0,3fb6 <fourfiles+0xa8>
    if (pid == 0) {
    3f7a:	c921                	beqz	a0,3fca <fourfiles+0xbc>
  for (pi = 0; pi < NCHILD; pi++) {
    3f7c:	2485                	addiw	s1,s1,1
    3f7e:	0921                	addi	s2,s2,8
    3f80:	ff4494e3          	bne	s1,s4,3f68 <fourfiles+0x5a>
    3f84:	4491                	li	s1,4
    wait(&xstatus);
    3f86:	f6c40913          	addi	s2,s0,-148
    3f8a:	854a                	mv	a0,s2
    3f8c:	51a010ef          	jal	54a6 <wait>
    if (xstatus != 0)
    3f90:	f6c42b03          	lw	s6,-148(s0)
    3f94:	0a0b1463          	bnez	s6,403c <fourfiles+0x12e>
  for (pi = 0; pi < NCHILD; pi++) {
    3f98:	34fd                	addiw	s1,s1,-1
    3f9a:	f8e5                	bnez	s1,3f8a <fourfiles+0x7c>
    3f9c:	03000493          	li	s1,48
    while ((n = read(fd, buf, sizeof(buf))) > 0) {
    3fa0:	6a8d                	lui	s5,0x3
    3fa2:	00009a17          	auipc	s4,0x9
    3fa6:	d46a0a13          	addi	s4,s4,-698 # cce8 <buf>
    if (total != N * SZ) {
    3faa:	6d05                	lui	s10,0x1
    3fac:	770d0d13          	addi	s10,s10,1904 # 1770 <createdelete+0x20>
  for (i = 0; i < NCHILD; i++) {
    3fb0:	03400d93          	li	s11,52
    3fb4:	a86d                	j	406e <fourfiles+0x160>
      printf("%s: fork failed\n", s);
    3fb6:	85e6                	mv	a1,s9
    3fb8:	00002517          	auipc	a0,0x2
    3fbc:	3c050513          	addi	a0,a0,960 # 6378 <malloc+0x9c0>
    3fc0:	13d010ef          	jal	58fc <printf>
      exit(1);
    3fc4:	4505                	li	a0,1
    3fc6:	4d8010ef          	jal	549e <exit>
      fd = open(fname, O_CREATE | O_RDWR);
    3fca:	20200593          	li	a1,514
    3fce:	854e                	mv	a0,s3
    3fd0:	50e010ef          	jal	54de <open>
    3fd4:	892a                	mv	s2,a0
      if (fd < 0) {
    3fd6:	04054063          	bltz	a0,4016 <fourfiles+0x108>
      memset(buf, '0' + pi, SZ);
    3fda:	1f400613          	li	a2,500
    3fde:	0304859b          	addiw	a1,s1,48
    3fe2:	00009517          	auipc	a0,0x9
    3fe6:	d0650513          	addi	a0,a0,-762 # cce8 <buf>
    3fea:	28a010ef          	jal	5274 <memset>
    3fee:	44b1                	li	s1,12
        if ((n = write(fd, buf, SZ)) != SZ) {
    3ff0:	1f400993          	li	s3,500
    3ff4:	00009a17          	auipc	s4,0x9
    3ff8:	cf4a0a13          	addi	s4,s4,-780 # cce8 <buf>
    3ffc:	864e                	mv	a2,s3
    3ffe:	85d2                	mv	a1,s4
    4000:	854a                	mv	a0,s2
    4002:	4bc010ef          	jal	54be <write>
    4006:	85aa                	mv	a1,a0
    4008:	03351163          	bne	a0,s3,402a <fourfiles+0x11c>
      for (i = 0; i < N; i++) {
    400c:	34fd                	addiw	s1,s1,-1
    400e:	f4fd                	bnez	s1,3ffc <fourfiles+0xee>
      exit(0);
    4010:	4501                	li	a0,0
    4012:	48c010ef          	jal	549e <exit>
        printf("%s: create failed\n", s);
    4016:	85e6                	mv	a1,s9
    4018:	00002517          	auipc	a0,0x2
    401c:	4d050513          	addi	a0,a0,1232 # 64e8 <malloc+0xb30>
    4020:	0dd010ef          	jal	58fc <printf>
        exit(1);
    4024:	4505                	li	a0,1
    4026:	478010ef          	jal	549e <exit>
          printf("write failed %d\n", n);
    402a:	00004517          	auipc	a0,0x4
    402e:	81e50513          	addi	a0,a0,-2018 # 7848 <malloc+0x1e90>
    4032:	0cb010ef          	jal	58fc <printf>
          exit(1);
    4036:	4505                	li	a0,1
    4038:	466010ef          	jal	549e <exit>
      exit(xstatus);
    403c:	855a                	mv	a0,s6
    403e:	460010ef          	jal	549e <exit>
          printf("%s: wrong char\n", s);
    4042:	85e6                	mv	a1,s9
    4044:	00004517          	auipc	a0,0x4
    4048:	81c50513          	addi	a0,a0,-2020 # 7860 <malloc+0x1ea8>
    404c:	0b1010ef          	jal	58fc <printf>
          exit(1);
    4050:	4505                	li	a0,1
    4052:	44c010ef          	jal	549e <exit>
    close(fd);
    4056:	854e                	mv	a0,s3
    4058:	46e010ef          	jal	54c6 <close>
    if (total != N * SZ) {
    405c:	05a91863          	bne	s2,s10,40ac <fourfiles+0x19e>
    unlink(fname);
    4060:	8562                	mv	a0,s8
    4062:	48c010ef          	jal	54ee <unlink>
  for (i = 0; i < NCHILD; i++) {
    4066:	0ba1                	addi	s7,s7,8
    4068:	2485                	addiw	s1,s1,1
    406a:	05b48b63          	beq	s1,s11,40c0 <fourfiles+0x1b2>
    fname = names[i];
    406e:	000bbc03          	ld	s8,0(s7)
    fd = open(fname, 0);
    4072:	4581                	li	a1,0
    4074:	8562                	mv	a0,s8
    4076:	468010ef          	jal	54de <open>
    407a:	89aa                	mv	s3,a0
    total = 0;
    407c:	895a                	mv	s2,s6
    while ((n = read(fd, buf, sizeof(buf))) > 0) {
    407e:	8656                	mv	a2,s5
    4080:	85d2                	mv	a1,s4
    4082:	854e                	mv	a0,s3
    4084:	432010ef          	jal	54b6 <read>
    4088:	fca057e3          	blez	a0,4056 <fourfiles+0x148>
    408c:	00009797          	auipc	a5,0x9
    4090:	c5c78793          	addi	a5,a5,-932 # cce8 <buf>
    4094:	00f506b3          	add	a3,a0,a5
        if (buf[j] != '0' + i) {
    4098:	0007c703          	lbu	a4,0(a5)
    409c:	fa9713e3          	bne	a4,s1,4042 <fourfiles+0x134>
      for (j = 0; j < n; j++) {
    40a0:	0785                	addi	a5,a5,1
    40a2:	fed79be3          	bne	a5,a3,4098 <fourfiles+0x18a>
      total += n;
    40a6:	00a9093b          	addw	s2,s2,a0
    40aa:	bfd1                	j	407e <fourfiles+0x170>
      printf("wrong length %d\n", total);
    40ac:	85ca                	mv	a1,s2
    40ae:	00003517          	auipc	a0,0x3
    40b2:	7c250513          	addi	a0,a0,1986 # 7870 <malloc+0x1eb8>
    40b6:	047010ef          	jal	58fc <printf>
      exit(1);
    40ba:	4505                	li	a0,1
    40bc:	3e2010ef          	jal	549e <exit>
}
    40c0:	60ea                	ld	ra,152(sp)
    40c2:	644a                	ld	s0,144(sp)
    40c4:	64aa                	ld	s1,136(sp)
    40c6:	690a                	ld	s2,128(sp)
    40c8:	79e6                	ld	s3,120(sp)
    40ca:	7a46                	ld	s4,112(sp)
    40cc:	7aa6                	ld	s5,104(sp)
    40ce:	7b06                	ld	s6,96(sp)
    40d0:	6be6                	ld	s7,88(sp)
    40d2:	6c46                	ld	s8,80(sp)
    40d4:	6ca6                	ld	s9,72(sp)
    40d6:	6d06                	ld	s10,64(sp)
    40d8:	7de2                	ld	s11,56(sp)
    40da:	610d                	addi	sp,sp,160
    40dc:	8082                	ret

00000000000040de <concreate>:
{
    40de:	7171                	addi	sp,sp,-176
    40e0:	f506                	sd	ra,168(sp)
    40e2:	f122                	sd	s0,160(sp)
    40e4:	ed26                	sd	s1,152(sp)
    40e6:	e94a                	sd	s2,144(sp)
    40e8:	e54e                	sd	s3,136(sp)
    40ea:	e152                	sd	s4,128(sp)
    40ec:	fcd6                	sd	s5,120(sp)
    40ee:	f8da                	sd	s6,112(sp)
    40f0:	f4de                	sd	s7,104(sp)
    40f2:	f0e2                	sd	s8,96(sp)
    40f4:	ece6                	sd	s9,88(sp)
    40f6:	e8ea                	sd	s10,80(sp)
    40f8:	1900                	addi	s0,sp,176
    40fa:	8d2a                	mv	s10,a0
  file[0] = 'C';
    40fc:	04300793          	li	a5,67
    4100:	f8f40c23          	sb	a5,-104(s0)
  file[2] = '\0';
    4104:	f8040d23          	sb	zero,-102(s0)
  for (i = 0; i < N; i++) {
    4108:	4901                	li	s2,0
    unlink(file);
    410a:	f9840993          	addi	s3,s0,-104
    if (pid && (i % 3) == 1) {
    410e:	55555b37          	lui	s6,0x55555
    4112:	556b0b13          	addi	s6,s6,1366 # 55555556 <base+0x5554586e>
    4116:	4b85                	li	s7,1
      fd = open(file, O_CREATE | O_RDWR);
    4118:	20200c13          	li	s8,514
      link("C0", file);
    411c:	00003c97          	auipc	s9,0x3
    4120:	76cc8c93          	addi	s9,s9,1900 # 7888 <malloc+0x1ed0>
      wait(&xstatus);
    4124:	f5c40a93          	addi	s5,s0,-164
  for (i = 0; i < N; i++) {
    4128:	02800a13          	li	s4,40
    412c:	a481                	j	436c <concreate+0x28e>
      link("C0", file);
    412e:	85ce                	mv	a1,s3
    4130:	8566                	mv	a0,s9
    4132:	3cc010ef          	jal	54fe <link>
    if (pid == 0) {
    4136:	a40d                	j	4358 <concreate+0x27a>
    } else if (pid == 0 && (i % 5) == 1) {
    4138:	666667b7          	lui	a5,0x66666
    413c:	66778793          	addi	a5,a5,1639 # 66666667 <base+0x6665697f>
    4140:	02f907b3          	mul	a5,s2,a5
    4144:	9785                	srai	a5,a5,0x21
    4146:	41f9571b          	sraiw	a4,s2,0x1f
    414a:	9f99                	subw	a5,a5,a4
    414c:	0027971b          	slliw	a4,a5,0x2
    4150:	9fb9                	addw	a5,a5,a4
    4152:	40f9093b          	subw	s2,s2,a5
    4156:	4785                	li	a5,1
    4158:	02f90563          	beq	s2,a5,4182 <concreate+0xa4>
      fd = open(file, O_CREATE | O_RDWR);
    415c:	20200593          	li	a1,514
    4160:	f9840513          	addi	a0,s0,-104
    4164:	37a010ef          	jal	54de <open>
      if (fd < 0) {
    4168:	1e055363          	bgez	a0,434e <concreate+0x270>
        printf("concreate create %s failed\n", file);
    416c:	f9840593          	addi	a1,s0,-104
    4170:	00003517          	auipc	a0,0x3
    4174:	72050513          	addi	a0,a0,1824 # 7890 <malloc+0x1ed8>
    4178:	784010ef          	jal	58fc <printf>
        exit(1);
    417c:	4505                	li	a0,1
    417e:	320010ef          	jal	549e <exit>
      link("C0", file);
    4182:	f9840593          	addi	a1,s0,-104
    4186:	00003517          	auipc	a0,0x3
    418a:	70250513          	addi	a0,a0,1794 # 7888 <malloc+0x1ed0>
    418e:	370010ef          	jal	54fe <link>
      exit(0);
    4192:	4501                	li	a0,0
    4194:	30a010ef          	jal	549e <exit>
        exit(1);
    4198:	4505                	li	a0,1
    419a:	304010ef          	jal	549e <exit>
  memset(fa, 0, sizeof(fa));
    419e:	02800613          	li	a2,40
    41a2:	4581                	li	a1,0
    41a4:	f7040513          	addi	a0,s0,-144
    41a8:	0cc010ef          	jal	5274 <memset>
  fd = open(".", 0);
    41ac:	4581                	li	a1,0
    41ae:	00002517          	auipc	a0,0x2
    41b2:	02250513          	addi	a0,a0,34 # 61d0 <malloc+0x818>
    41b6:	328010ef          	jal	54de <open>
    41ba:	892a                	mv	s2,a0
  n = 0;
    41bc:	8b26                	mv	s6,s1
  while (read(fd, &de, sizeof(de)) > 0) {
    41be:	f6040a13          	addi	s4,s0,-160
    41c2:	49c1                	li	s3,16
    if (de.name[0] == 'C' && de.name[2] == '\0') {
    41c4:	04300a93          	li	s5,67
      if (i < 0 || i >= sizeof(fa)) {
    41c8:	02700b93          	li	s7,39
      fa[i] = 1;
    41cc:	4c05                	li	s8,1
  while (read(fd, &de, sizeof(de)) > 0) {
    41ce:	864e                	mv	a2,s3
    41d0:	85d2                	mv	a1,s4
    41d2:	854a                	mv	a0,s2
    41d4:	2e2010ef          	jal	54b6 <read>
    41d8:	06a05763          	blez	a0,4246 <concreate+0x168>
    if (de.inum == 0)
    41dc:	f6045783          	lhu	a5,-160(s0)
    41e0:	d7fd                	beqz	a5,41ce <concreate+0xf0>
    if (de.name[0] == 'C' && de.name[2] == '\0') {
    41e2:	f6244783          	lbu	a5,-158(s0)
    41e6:	ff5794e3          	bne	a5,s5,41ce <concreate+0xf0>
    41ea:	f6444783          	lbu	a5,-156(s0)
    41ee:	f3e5                	bnez	a5,41ce <concreate+0xf0>
      i = de.name[1] - '0';
    41f0:	f6344783          	lbu	a5,-157(s0)
    41f4:	fd07879b          	addiw	a5,a5,-48
      if (i < 0 || i >= sizeof(fa)) {
    41f8:	00fbef63          	bltu	s7,a5,4216 <concreate+0x138>
      if (fa[i]) {
    41fc:	fa040713          	addi	a4,s0,-96
    4200:	973e                	add	a4,a4,a5
    4202:	fd074703          	lbu	a4,-48(a4)
    4206:	e705                	bnez	a4,422e <concreate+0x150>
      fa[i] = 1;
    4208:	fa040713          	addi	a4,s0,-96
    420c:	97ba                	add	a5,a5,a4
    420e:	fd878823          	sb	s8,-48(a5)
      n++;
    4212:	2b05                	addiw	s6,s6,1
    4214:	bf6d                	j	41ce <concreate+0xf0>
        printf("%s: concreate weird file %s\n", s, de.name);
    4216:	f6240613          	addi	a2,s0,-158
    421a:	85ea                	mv	a1,s10
    421c:	00003517          	auipc	a0,0x3
    4220:	69450513          	addi	a0,a0,1684 # 78b0 <malloc+0x1ef8>
    4224:	6d8010ef          	jal	58fc <printf>
        exit(1);
    4228:	4505                	li	a0,1
    422a:	274010ef          	jal	549e <exit>
        printf("%s: concreate duplicate file %s\n", s, de.name);
    422e:	f6240613          	addi	a2,s0,-158
    4232:	85ea                	mv	a1,s10
    4234:	00003517          	auipc	a0,0x3
    4238:	69c50513          	addi	a0,a0,1692 # 78d0 <malloc+0x1f18>
    423c:	6c0010ef          	jal	58fc <printf>
        exit(1);
    4240:	4505                	li	a0,1
    4242:	25c010ef          	jal	549e <exit>
  close(fd);
    4246:	854a                	mv	a0,s2
    4248:	27e010ef          	jal	54c6 <close>
  if (n != N) {
    424c:	02800793          	li	a5,40
    4250:	00fb1a63          	bne	s6,a5,4264 <concreate+0x186>
    if (((i % 3) == 0 && pid == 0) || ((i % 3) == 1 && pid != 0)) {
    4254:	55555a37          	lui	s4,0x55555
    4258:	556a0a13          	addi	s4,s4,1366 # 55555556 <base+0x5554586e>
      close(open(file, 0));
    425c:	f9840993          	addi	s3,s0,-104
  for (i = 0; i < N; i++) {
    4260:	8ada                	mv	s5,s6
    4262:	a049                	j	42e4 <concreate+0x206>
    printf("%s: concreate not enough files in directory listing\n", s);
    4264:	85ea                	mv	a1,s10
    4266:	00003517          	auipc	a0,0x3
    426a:	69250513          	addi	a0,a0,1682 # 78f8 <malloc+0x1f40>
    426e:	68e010ef          	jal	58fc <printf>
    exit(1);
    4272:	4505                	li	a0,1
    4274:	22a010ef          	jal	549e <exit>
      printf("%s: fork failed\n", s);
    4278:	85ea                	mv	a1,s10
    427a:	00002517          	auipc	a0,0x2
    427e:	0fe50513          	addi	a0,a0,254 # 6378 <malloc+0x9c0>
    4282:	67a010ef          	jal	58fc <printf>
      exit(1);
    4286:	4505                	li	a0,1
    4288:	216010ef          	jal	549e <exit>
      close(open(file, 0));
    428c:	4581                	li	a1,0
    428e:	854e                	mv	a0,s3
    4290:	24e010ef          	jal	54de <open>
    4294:	232010ef          	jal	54c6 <close>
      close(open(file, 0));
    4298:	4581                	li	a1,0
    429a:	854e                	mv	a0,s3
    429c:	242010ef          	jal	54de <open>
    42a0:	226010ef          	jal	54c6 <close>
      close(open(file, 0));
    42a4:	4581                	li	a1,0
    42a6:	854e                	mv	a0,s3
    42a8:	236010ef          	jal	54de <open>
    42ac:	21a010ef          	jal	54c6 <close>
      close(open(file, 0));
    42b0:	4581                	li	a1,0
    42b2:	854e                	mv	a0,s3
    42b4:	22a010ef          	jal	54de <open>
    42b8:	20e010ef          	jal	54c6 <close>
      close(open(file, 0));
    42bc:	4581                	li	a1,0
    42be:	854e                	mv	a0,s3
    42c0:	21e010ef          	jal	54de <open>
    42c4:	202010ef          	jal	54c6 <close>
      close(open(file, 0));
    42c8:	4581                	li	a1,0
    42ca:	854e                	mv	a0,s3
    42cc:	212010ef          	jal	54de <open>
    42d0:	1f6010ef          	jal	54c6 <close>
    if (pid == 0)
    42d4:	06090a63          	beqz	s2,4348 <concreate+0x26a>
      wait(0);
    42d8:	4501                	li	a0,0
    42da:	1cc010ef          	jal	54a6 <wait>
  for (i = 0; i < N; i++) {
    42de:	2485                	addiw	s1,s1,1
    42e0:	0d548563          	beq	s1,s5,43aa <concreate+0x2cc>
    file[1] = '0' + i;
    42e4:	0304879b          	addiw	a5,s1,48
    42e8:	f8f40ca3          	sb	a5,-103(s0)
    pid = fork();
    42ec:	1aa010ef          	jal	5496 <fork>
    42f0:	892a                	mv	s2,a0
    if (pid < 0) {
    42f2:	f80543e3          	bltz	a0,4278 <concreate+0x19a>
    if (((i % 3) == 0 && pid == 0) || ((i % 3) == 1 && pid != 0)) {
    42f6:	03448733          	mul	a4,s1,s4
    42fa:	9301                	srli	a4,a4,0x20
    42fc:	41f4d79b          	sraiw	a5,s1,0x1f
    4300:	9f1d                	subw	a4,a4,a5
    4302:	0017179b          	slliw	a5,a4,0x1
    4306:	9fb9                	addw	a5,a5,a4
    4308:	40f487bb          	subw	a5,s1,a5
    430c:	00a7e733          	or	a4,a5,a0
    4310:	2701                	sext.w	a4,a4
    4312:	df2d                	beqz	a4,428c <concreate+0x1ae>
    4314:	00a03733          	snez	a4,a0
    4318:	17fd                	addi	a5,a5,-1
    431a:	0017b793          	seqz	a5,a5
    431e:	8ff9                	and	a5,a5,a4
    4320:	f7b5                	bnez	a5,428c <concreate+0x1ae>
      unlink(file);
    4322:	854e                	mv	a0,s3
    4324:	1ca010ef          	jal	54ee <unlink>
      unlink(file);
    4328:	854e                	mv	a0,s3
    432a:	1c4010ef          	jal	54ee <unlink>
      unlink(file);
    432e:	854e                	mv	a0,s3
    4330:	1be010ef          	jal	54ee <unlink>
      unlink(file);
    4334:	854e                	mv	a0,s3
    4336:	1b8010ef          	jal	54ee <unlink>
      unlink(file);
    433a:	854e                	mv	a0,s3
    433c:	1b2010ef          	jal	54ee <unlink>
      unlink(file);
    4340:	854e                	mv	a0,s3
    4342:	1ac010ef          	jal	54ee <unlink>
    4346:	b779                	j	42d4 <concreate+0x1f6>
      exit(0);
    4348:	4501                	li	a0,0
    434a:	154010ef          	jal	549e <exit>
      close(fd);
    434e:	178010ef          	jal	54c6 <close>
    if (pid == 0) {
    4352:	b581                	j	4192 <concreate+0xb4>
      close(fd);
    4354:	172010ef          	jal	54c6 <close>
      wait(&xstatus);
    4358:	8556                	mv	a0,s5
    435a:	14c010ef          	jal	54a6 <wait>
      if (xstatus != 0)
    435e:	f5c42483          	lw	s1,-164(s0)
    4362:	e2049be3          	bnez	s1,4198 <concreate+0xba>
  for (i = 0; i < N; i++) {
    4366:	2905                	addiw	s2,s2,1
    4368:	e3490be3          	beq	s2,s4,419e <concreate+0xc0>
    file[1] = '0' + i;
    436c:	0309079b          	addiw	a5,s2,48
    4370:	f8f40ca3          	sb	a5,-103(s0)
    unlink(file);
    4374:	854e                	mv	a0,s3
    4376:	178010ef          	jal	54ee <unlink>
    pid = fork();
    437a:	11c010ef          	jal	5496 <fork>
    if (pid && (i % 3) == 1) {
    437e:	da050de3          	beqz	a0,4138 <concreate+0x5a>
    4382:	036907b3          	mul	a5,s2,s6
    4386:	9381                	srli	a5,a5,0x20
    4388:	41f9571b          	sraiw	a4,s2,0x1f
    438c:	9f99                	subw	a5,a5,a4
    438e:	0017971b          	slliw	a4,a5,0x1
    4392:	9fb9                	addw	a5,a5,a4
    4394:	40f907bb          	subw	a5,s2,a5
    4398:	d9778be3          	beq	a5,s7,412e <concreate+0x50>
      fd = open(file, O_CREATE | O_RDWR);
    439c:	85e2                	mv	a1,s8
    439e:	854e                	mv	a0,s3
    43a0:	13e010ef          	jal	54de <open>
      if (fd < 0) {
    43a4:	fa0558e3          	bgez	a0,4354 <concreate+0x276>
    43a8:	b3d1                	j	416c <concreate+0x8e>
}
    43aa:	70aa                	ld	ra,168(sp)
    43ac:	740a                	ld	s0,160(sp)
    43ae:	64ea                	ld	s1,152(sp)
    43b0:	694a                	ld	s2,144(sp)
    43b2:	69aa                	ld	s3,136(sp)
    43b4:	6a0a                	ld	s4,128(sp)
    43b6:	7ae6                	ld	s5,120(sp)
    43b8:	7b46                	ld	s6,112(sp)
    43ba:	7ba6                	ld	s7,104(sp)
    43bc:	7c06                	ld	s8,96(sp)
    43be:	6ce6                	ld	s9,88(sp)
    43c0:	6d46                	ld	s10,80(sp)
    43c2:	614d                	addi	sp,sp,176
    43c4:	8082                	ret

00000000000043c6 <bigfile>:
{
    43c6:	7139                	addi	sp,sp,-64
    43c8:	fc06                	sd	ra,56(sp)
    43ca:	f822                	sd	s0,48(sp)
    43cc:	f426                	sd	s1,40(sp)
    43ce:	f04a                	sd	s2,32(sp)
    43d0:	ec4e                	sd	s3,24(sp)
    43d2:	e852                	sd	s4,16(sp)
    43d4:	e456                	sd	s5,8(sp)
    43d6:	e05a                	sd	s6,0(sp)
    43d8:	0080                	addi	s0,sp,64
    43da:	8b2a                	mv	s6,a0
  unlink("bigfile.dat");
    43dc:	00003517          	auipc	a0,0x3
    43e0:	55450513          	addi	a0,a0,1364 # 7930 <malloc+0x1f78>
    43e4:	10a010ef          	jal	54ee <unlink>
  fd = open("bigfile.dat", O_CREATE | O_RDWR);
    43e8:	20200593          	li	a1,514
    43ec:	00003517          	auipc	a0,0x3
    43f0:	54450513          	addi	a0,a0,1348 # 7930 <malloc+0x1f78>
    43f4:	0ea010ef          	jal	54de <open>
  if (fd < 0) {
    43f8:	08054a63          	bltz	a0,448c <bigfile+0xc6>
    43fc:	8a2a                	mv	s4,a0
    43fe:	4481                	li	s1,0
    memset(buf, i, SZ);
    4400:	25800913          	li	s2,600
    4404:	00009997          	auipc	s3,0x9
    4408:	8e498993          	addi	s3,s3,-1820 # cce8 <buf>
  for (i = 0; i < N; i++) {
    440c:	4ad1                	li	s5,20
    memset(buf, i, SZ);
    440e:	864a                	mv	a2,s2
    4410:	85a6                	mv	a1,s1
    4412:	854e                	mv	a0,s3
    4414:	661000ef          	jal	5274 <memset>
    if (write(fd, buf, SZ) != SZ) {
    4418:	864a                	mv	a2,s2
    441a:	85ce                	mv	a1,s3
    441c:	8552                	mv	a0,s4
    441e:	0a0010ef          	jal	54be <write>
    4422:	07251f63          	bne	a0,s2,44a0 <bigfile+0xda>
  for (i = 0; i < N; i++) {
    4426:	2485                	addiw	s1,s1,1
    4428:	ff5493e3          	bne	s1,s5,440e <bigfile+0x48>
  close(fd);
    442c:	8552                	mv	a0,s4
    442e:	098010ef          	jal	54c6 <close>
  fd = open("bigfile.dat", 0);
    4432:	4581                	li	a1,0
    4434:	00003517          	auipc	a0,0x3
    4438:	4fc50513          	addi	a0,a0,1276 # 7930 <malloc+0x1f78>
    443c:	0a2010ef          	jal	54de <open>
    4440:	8aaa                	mv	s5,a0
  total = 0;
    4442:	4a01                	li	s4,0
  for (i = 0;; i++) {
    4444:	4481                	li	s1,0
    cc = read(fd, buf, SZ / 2);
    4446:	12c00993          	li	s3,300
    444a:	00009917          	auipc	s2,0x9
    444e:	89e90913          	addi	s2,s2,-1890 # cce8 <buf>
  if (fd < 0) {
    4452:	06054163          	bltz	a0,44b4 <bigfile+0xee>
    cc = read(fd, buf, SZ / 2);
    4456:	864e                	mv	a2,s3
    4458:	85ca                	mv	a1,s2
    445a:	8556                	mv	a0,s5
    445c:	05a010ef          	jal	54b6 <read>
    if (cc < 0) {
    4460:	06054463          	bltz	a0,44c8 <bigfile+0x102>
    if (cc == 0)
    4464:	c145                	beqz	a0,4504 <bigfile+0x13e>
    if (cc != SZ / 2) {
    4466:	07351b63          	bne	a0,s3,44dc <bigfile+0x116>
    if (buf[0] != i / 2 || buf[SZ / 2 - 1] != i / 2) {
    446a:	01f4d79b          	srliw	a5,s1,0x1f
    446e:	9fa5                	addw	a5,a5,s1
    4470:	4017d79b          	sraiw	a5,a5,0x1
    4474:	00094703          	lbu	a4,0(s2)
    4478:	06f71c63          	bne	a4,a5,44f0 <bigfile+0x12a>
    447c:	12b94703          	lbu	a4,299(s2)
    4480:	06f71863          	bne	a4,a5,44f0 <bigfile+0x12a>
    total += cc;
    4484:	12ca0a1b          	addiw	s4,s4,300
  for (i = 0;; i++) {
    4488:	2485                	addiw	s1,s1,1
    cc = read(fd, buf, SZ / 2);
    448a:	b7f1                	j	4456 <bigfile+0x90>
    printf("%s: cannot create bigfile", s);
    448c:	85da                	mv	a1,s6
    448e:	00003517          	auipc	a0,0x3
    4492:	4b250513          	addi	a0,a0,1202 # 7940 <malloc+0x1f88>
    4496:	466010ef          	jal	58fc <printf>
    exit(1);
    449a:	4505                	li	a0,1
    449c:	002010ef          	jal	549e <exit>
      printf("%s: write bigfile failed\n", s);
    44a0:	85da                	mv	a1,s6
    44a2:	00003517          	auipc	a0,0x3
    44a6:	4be50513          	addi	a0,a0,1214 # 7960 <malloc+0x1fa8>
    44aa:	452010ef          	jal	58fc <printf>
      exit(1);
    44ae:	4505                	li	a0,1
    44b0:	7ef000ef          	jal	549e <exit>
    printf("%s: cannot open bigfile\n", s);
    44b4:	85da                	mv	a1,s6
    44b6:	00003517          	auipc	a0,0x3
    44ba:	4ca50513          	addi	a0,a0,1226 # 7980 <malloc+0x1fc8>
    44be:	43e010ef          	jal	58fc <printf>
    exit(1);
    44c2:	4505                	li	a0,1
    44c4:	7db000ef          	jal	549e <exit>
      printf("%s: read bigfile failed\n", s);
    44c8:	85da                	mv	a1,s6
    44ca:	00003517          	auipc	a0,0x3
    44ce:	4d650513          	addi	a0,a0,1238 # 79a0 <malloc+0x1fe8>
    44d2:	42a010ef          	jal	58fc <printf>
      exit(1);
    44d6:	4505                	li	a0,1
    44d8:	7c7000ef          	jal	549e <exit>
      printf("%s: short read bigfile\n", s);
    44dc:	85da                	mv	a1,s6
    44de:	00003517          	auipc	a0,0x3
    44e2:	4e250513          	addi	a0,a0,1250 # 79c0 <malloc+0x2008>
    44e6:	416010ef          	jal	58fc <printf>
      exit(1);
    44ea:	4505                	li	a0,1
    44ec:	7b3000ef          	jal	549e <exit>
      printf("%s: read bigfile wrong data\n", s);
    44f0:	85da                	mv	a1,s6
    44f2:	00003517          	auipc	a0,0x3
    44f6:	4e650513          	addi	a0,a0,1254 # 79d8 <malloc+0x2020>
    44fa:	402010ef          	jal	58fc <printf>
      exit(1);
    44fe:	4505                	li	a0,1
    4500:	79f000ef          	jal	549e <exit>
  close(fd);
    4504:	8556                	mv	a0,s5
    4506:	7c1000ef          	jal	54c6 <close>
  if (total != N * SZ) {
    450a:	678d                	lui	a5,0x3
    450c:	ee078793          	addi	a5,a5,-288 # 2ee0 <subdir+0x35a>
    4510:	02fa1263          	bne	s4,a5,4534 <bigfile+0x16e>
  unlink("bigfile.dat");
    4514:	00003517          	auipc	a0,0x3
    4518:	41c50513          	addi	a0,a0,1052 # 7930 <malloc+0x1f78>
    451c:	7d3000ef          	jal	54ee <unlink>
}
    4520:	70e2                	ld	ra,56(sp)
    4522:	7442                	ld	s0,48(sp)
    4524:	74a2                	ld	s1,40(sp)
    4526:	7902                	ld	s2,32(sp)
    4528:	69e2                	ld	s3,24(sp)
    452a:	6a42                	ld	s4,16(sp)
    452c:	6aa2                	ld	s5,8(sp)
    452e:	6b02                	ld	s6,0(sp)
    4530:	6121                	addi	sp,sp,64
    4532:	8082                	ret
    printf("%s: read bigfile wrong total\n", s);
    4534:	85da                	mv	a1,s6
    4536:	00003517          	auipc	a0,0x3
    453a:	4c250513          	addi	a0,a0,1218 # 79f8 <malloc+0x2040>
    453e:	3be010ef          	jal	58fc <printf>
    exit(1);
    4542:	4505                	li	a0,1
    4544:	75b000ef          	jal	549e <exit>

0000000000004548 <bigargtest>:
{
    4548:	7121                	addi	sp,sp,-448
    454a:	ff06                	sd	ra,440(sp)
    454c:	fb22                	sd	s0,432(sp)
    454e:	f726                	sd	s1,424(sp)
    4550:	0380                	addi	s0,sp,448
    4552:	84aa                	mv	s1,a0
  unlink("bigarg-ok");
    4554:	00003517          	auipc	a0,0x3
    4558:	4c450513          	addi	a0,a0,1220 # 7a18 <malloc+0x2060>
    455c:	793000ef          	jal	54ee <unlink>
  pid = fork();
    4560:	737000ef          	jal	5496 <fork>
  if (pid == 0) {
    4564:	c915                	beqz	a0,4598 <bigargtest+0x50>
  } else if (pid < 0) {
    4566:	08054c63          	bltz	a0,45fe <bigargtest+0xb6>
  wait(&xstatus);
    456a:	fdc40513          	addi	a0,s0,-36
    456e:	739000ef          	jal	54a6 <wait>
  if (xstatus != 0)
    4572:	fdc42503          	lw	a0,-36(s0)
    4576:	ed51                	bnez	a0,4612 <bigargtest+0xca>
  fd = open("bigarg-ok", 0);
    4578:	4581                	li	a1,0
    457a:	00003517          	auipc	a0,0x3
    457e:	49e50513          	addi	a0,a0,1182 # 7a18 <malloc+0x2060>
    4582:	75d000ef          	jal	54de <open>
  if (fd < 0) {
    4586:	08054863          	bltz	a0,4616 <bigargtest+0xce>
  close(fd);
    458a:	73d000ef          	jal	54c6 <close>
}
    458e:	70fa                	ld	ra,440(sp)
    4590:	745a                	ld	s0,432(sp)
    4592:	74ba                	ld	s1,424(sp)
    4594:	6139                	addi	sp,sp,448
    4596:	8082                	ret
    memset(big, ' ', sizeof(big));
    4598:	19000613          	li	a2,400
    459c:	02000593          	li	a1,32
    45a0:	e4840513          	addi	a0,s0,-440
    45a4:	4d1000ef          	jal	5274 <memset>
    big[sizeof(big) - 1] = '\0';
    45a8:	fc040ba3          	sb	zero,-41(s0)
    for (i = 0; i < MAXARG - 1; i++)
    45ac:	00005797          	auipc	a5,0x5
    45b0:	f2478793          	addi	a5,a5,-220 # 94d0 <args.1>
    45b4:	00005697          	auipc	a3,0x5
    45b8:	01468693          	addi	a3,a3,20 # 95c8 <args.1+0xf8>
      args[i] = big;
    45bc:	e4840713          	addi	a4,s0,-440
    45c0:	e398                	sd	a4,0(a5)
    for (i = 0; i < MAXARG - 1; i++)
    45c2:	07a1                	addi	a5,a5,8
    45c4:	fed79ee3          	bne	a5,a3,45c0 <bigargtest+0x78>
    args[MAXARG - 1] = 0;
    45c8:	00005797          	auipc	a5,0x5
    45cc:	0007b023          	sd	zero,0(a5) # 95c8 <args.1+0xf8>
    exec("echo", args);
    45d0:	00005597          	auipc	a1,0x5
    45d4:	f0058593          	addi	a1,a1,-256 # 94d0 <args.1>
    45d8:	00001517          	auipc	a0,0x1
    45dc:	51050513          	addi	a0,a0,1296 # 5ae8 <malloc+0x130>
    45e0:	6f7000ef          	jal	54d6 <exec>
    fd = open("bigarg-ok", O_CREATE);
    45e4:	20000593          	li	a1,512
    45e8:	00003517          	auipc	a0,0x3
    45ec:	43050513          	addi	a0,a0,1072 # 7a18 <malloc+0x2060>
    45f0:	6ef000ef          	jal	54de <open>
    close(fd);
    45f4:	6d3000ef          	jal	54c6 <close>
    exit(0);
    45f8:	4501                	li	a0,0
    45fa:	6a5000ef          	jal	549e <exit>
    printf("%s: bigargtest: fork failed\n", s);
    45fe:	85a6                	mv	a1,s1
    4600:	00003517          	auipc	a0,0x3
    4604:	42850513          	addi	a0,a0,1064 # 7a28 <malloc+0x2070>
    4608:	2f4010ef          	jal	58fc <printf>
    exit(1);
    460c:	4505                	li	a0,1
    460e:	691000ef          	jal	549e <exit>
    exit(xstatus);
    4612:	68d000ef          	jal	549e <exit>
    printf("%s: bigarg test failed!\n", s);
    4616:	85a6                	mv	a1,s1
    4618:	00003517          	auipc	a0,0x3
    461c:	43050513          	addi	a0,a0,1072 # 7a48 <malloc+0x2090>
    4620:	2dc010ef          	jal	58fc <printf>
    exit(1);
    4624:	4505                	li	a0,1
    4626:	679000ef          	jal	549e <exit>

000000000000462a <partial_write>:
{
    462a:	bb010113          	addi	sp,sp,-1104
    462e:	44113423          	sd	ra,1096(sp)
    4632:	44813023          	sd	s0,1088(sp)
    4636:	42913c23          	sd	s1,1080(sp)
    463a:	43213823          	sd	s2,1072(sp)
    463e:	43313423          	sd	s3,1064(sp)
    4642:	43413023          	sd	s4,1056(sp)
    4646:	41513c23          	sd	s5,1048(sp)
    464a:	45010413          	addi	s0,sp,1104
    464e:	8aaa                	mv	s5,a0
  unlink("testfile");
    4650:	00003517          	auipc	a0,0x3
    4654:	41850513          	addi	a0,a0,1048 # 7a68 <malloc+0x20b0>
    4658:	697000ef          	jal	54ee <unlink>
  int fd = open("testfile", O_CREATE | O_RDWR);
    465c:	20200593          	li	a1,514
    4660:	00003517          	auipc	a0,0x3
    4664:	40850513          	addi	a0,a0,1032 # 7a68 <malloc+0x20b0>
    4668:	677000ef          	jal	54de <open>
  if (fd < 0) {
    466c:	14054f63          	bltz	a0,47ca <partial_write+0x1a0>
    4670:	84aa                	mv	s1,a0
  int cc = write(fd, "A", 1);
    4672:	4605                	li	a2,1
    4674:	00003597          	auipc	a1,0x3
    4678:	42458593          	addi	a1,a1,1060 # 7a98 <malloc+0x20e0>
    467c:	643000ef          	jal	54be <write>
  if (cc != 1) {
    4680:	4785                	li	a5,1
    4682:	14f51e63          	bne	a0,a5,47de <partial_write+0x1b4>
  close(fd);
    4686:	8526                	mv	a0,s1
    4688:	63f000ef          	jal	54c6 <close>
  fd = open("testfile", O_RDWR);
    468c:	4589                	li	a1,2
    468e:	00003517          	auipc	a0,0x3
    4692:	3da50513          	addi	a0,a0,986 # 7a68 <malloc+0x20b0>
    4696:	649000ef          	jal	54de <open>
    469a:	84aa                	mv	s1,a0
  if (fd < 0) {
    469c:	14054b63          	bltz	a0,47f2 <partial_write+0x1c8>
  char *p = sbrk(0);
    46a0:	4501                	li	a0,0
    46a2:	5c9000ef          	jal	546a <sbrk>
  sbrk(PGSIZE - ((uint64)p % PGSIZE));
    46a6:	03451793          	slli	a5,a0,0x34
    46aa:	93d1                	srli	a5,a5,0x34
    46ac:	6505                	lui	a0,0x1
    46ae:	9d1d                	subw	a0,a0,a5
    46b0:	5bb000ef          	jal	546a <sbrk>
  p = sbrk(0);
    46b4:	4501                	li	a0,0
    46b6:	5b5000ef          	jal	546a <sbrk>
  if ((uint64)p % PGSIZE != 0) {
    46ba:	03451793          	slli	a5,a0,0x34
    46be:	14079463          	bnez	a5,4806 <partial_write+0x1dc>
  p[-1] = 'X';
    46c2:	05800793          	li	a5,88
    46c6:	fef50fa3          	sb	a5,-1(a0) # fff <bigdir+0x10b>
  cc = write(fd, p - 1, 2);
    46ca:	4609                	li	a2,2
    46cc:	fff50593          	addi	a1,a0,-1
    46d0:	8526                	mv	a0,s1
    46d2:	5ed000ef          	jal	54be <write>
  if (cc != -1) {
    46d6:	57fd                	li	a5,-1
    46d8:	14f51163          	bne	a0,a5,481a <partial_write+0x1f0>
  close(fd);
    46dc:	8526                	mv	a0,s1
    46de:	5e9000ef          	jal	54c6 <close>
  fd = open("testfile", O_RDONLY);
    46e2:	4581                	li	a1,0
    46e4:	00003517          	auipc	a0,0x3
    46e8:	38450513          	addi	a0,a0,900 # 7a68 <malloc+0x20b0>
    46ec:	5f3000ef          	jal	54de <open>
    46f0:	84aa                	mv	s1,a0
  if (fd < 0) {
    46f2:	12054e63          	bltz	a0,482e <partial_write+0x204>
  cc = read(fd, &b, 1);
    46f6:	4605                	li	a2,1
    46f8:	fbf40593          	addi	a1,s0,-65
    46fc:	5bb000ef          	jal	54b6 <read>
  if (cc != 1) {
    4700:	4785                	li	a5,1
    4702:	14f51063          	bne	a0,a5,4842 <partial_write+0x218>
  close(fd);
    4706:	8526                	mv	a0,s1
    4708:	5bf000ef          	jal	54c6 <close>
  if (b != 'X') {
    470c:	fbf44603          	lbu	a2,-65(s0)
    4710:	05800793          	li	a5,88
    4714:	14f61163          	bne	a2,a5,4856 <partial_write+0x22c>
  fd = open("bigfile", O_CREATE | O_RDWR);
    4718:	20200593          	li	a1,514
    471c:	00003517          	auipc	a0,0x3
    4720:	44c50513          	addi	a0,a0,1100 # 7b68 <malloc+0x21b0>
    4724:	5bb000ef          	jal	54de <open>
    4728:	8a2a                	mv	s4,a0
    472a:	04000913          	li	s2,64
    memset(buf, 0, sizeof(buf));
    472e:	bb840993          	addi	s3,s0,-1096
    4732:	40000493          	li	s1,1024
    4736:	8626                	mv	a2,s1
    4738:	4581                	li	a1,0
    473a:	854e                	mv	a0,s3
    473c:	339000ef          	jal	5274 <memset>
    cc = write(fd, buf, sizeof(buf));
    4740:	8626                	mv	a2,s1
    4742:	85ce                	mv	a1,s3
    4744:	8552                	mv	a0,s4
    4746:	579000ef          	jal	54be <write>
    if (cc != sizeof(buf)) {
    474a:	12951063          	bne	a0,s1,486a <partial_write+0x240>
  for (int i = 0; i < 64; i++) {
    474e:	397d                	addiw	s2,s2,-1
    4750:	fe0913e3          	bnez	s2,4736 <partial_write+0x10c>
  close(fd);
    4754:	8552                	mv	a0,s4
    4756:	571000ef          	jal	54c6 <close>
  unlink("bigfile");
    475a:	00003517          	auipc	a0,0x3
    475e:	40e50513          	addi	a0,a0,1038 # 7b68 <malloc+0x21b0>
    4762:	58d000ef          	jal	54ee <unlink>
  fd = open("testfile", O_RDONLY);
    4766:	4581                	li	a1,0
    4768:	00003517          	auipc	a0,0x3
    476c:	30050513          	addi	a0,a0,768 # 7a68 <malloc+0x20b0>
    4770:	56f000ef          	jal	54de <open>
    4774:	84aa                	mv	s1,a0
  if (fd < 0) {
    4776:	10054463          	bltz	a0,487e <partial_write+0x254>
  cc = read(fd, &b, 1);
    477a:	4605                	li	a2,1
    477c:	fbf40593          	addi	a1,s0,-65
    4780:	537000ef          	jal	54b6 <read>
  if (cc != 1) {
    4784:	4785                	li	a5,1
    4786:	10f51663          	bne	a0,a5,4892 <partial_write+0x268>
  close(fd);
    478a:	8526                	mv	a0,s1
    478c:	53b000ef          	jal	54c6 <close>
  if (b != 'X') {
    4790:	fbf44603          	lbu	a2,-65(s0)
    4794:	05800793          	li	a5,88
    4798:	10f61763          	bne	a2,a5,48a6 <partial_write+0x27c>
  unlink("testfile");
    479c:	00003517          	auipc	a0,0x3
    47a0:	2cc50513          	addi	a0,a0,716 # 7a68 <malloc+0x20b0>
    47a4:	54b000ef          	jal	54ee <unlink>
}
    47a8:	44813083          	ld	ra,1096(sp)
    47ac:	44013403          	ld	s0,1088(sp)
    47b0:	43813483          	ld	s1,1080(sp)
    47b4:	43013903          	ld	s2,1072(sp)
    47b8:	42813983          	ld	s3,1064(sp)
    47bc:	42013a03          	ld	s4,1056(sp)
    47c0:	41813a83          	ld	s5,1048(sp)
    47c4:	45010113          	addi	sp,sp,1104
    47c8:	8082                	ret
    printf("%s: cannot create testfile\n", s);
    47ca:	85d6                	mv	a1,s5
    47cc:	00003517          	auipc	a0,0x3
    47d0:	2ac50513          	addi	a0,a0,684 # 7a78 <malloc+0x20c0>
    47d4:	128010ef          	jal	58fc <printf>
    exit(1);
    47d8:	4505                	li	a0,1
    47da:	4c5000ef          	jal	549e <exit>
    printf("%s: could not write A\n", s);
    47de:	85d6                	mv	a1,s5
    47e0:	00003517          	auipc	a0,0x3
    47e4:	2c050513          	addi	a0,a0,704 # 7aa0 <malloc+0x20e8>
    47e8:	114010ef          	jal	58fc <printf>
    exit(1);
    47ec:	4505                	li	a0,1
    47ee:	4b1000ef          	jal	549e <exit>
    printf("%s: cannot re-open testfile\n", s);
    47f2:	85d6                	mv	a1,s5
    47f4:	00003517          	auipc	a0,0x3
    47f8:	2c450513          	addi	a0,a0,708 # 7ab8 <malloc+0x2100>
    47fc:	100010ef          	jal	58fc <printf>
    exit(1);
    4800:	4505                	li	a0,1
    4802:	49d000ef          	jal	549e <exit>
    printf("%s: sbrk did not align\n", s);
    4806:	85d6                	mv	a1,s5
    4808:	00003517          	auipc	a0,0x3
    480c:	2d050513          	addi	a0,a0,720 # 7ad8 <malloc+0x2120>
    4810:	0ec010ef          	jal	58fc <printf>
    exit(1);
    4814:	4505                	li	a0,1
    4816:	489000ef          	jal	549e <exit>
    printf("%s: write succeeded, should have failed\n", s);
    481a:	85d6                	mv	a1,s5
    481c:	00003517          	auipc	a0,0x3
    4820:	2d450513          	addi	a0,a0,724 # 7af0 <malloc+0x2138>
    4824:	0d8010ef          	jal	58fc <printf>
    exit(1);
    4828:	4505                	li	a0,1
    482a:	475000ef          	jal	549e <exit>
    printf("%s: cannot re-open testfile\n", s);
    482e:	85d6                	mv	a1,s5
    4830:	00003517          	auipc	a0,0x3
    4834:	28850513          	addi	a0,a0,648 # 7ab8 <malloc+0x2100>
    4838:	0c4010ef          	jal	58fc <printf>
    exit(1);
    483c:	4505                	li	a0,1
    483e:	461000ef          	jal	549e <exit>
    printf("%s: cannot read testfile\n", s);
    4842:	85d6                	mv	a1,s5
    4844:	00003517          	auipc	a0,0x3
    4848:	2dc50513          	addi	a0,a0,732 # 7b20 <malloc+0x2168>
    484c:	0b0010ef          	jal	58fc <printf>
    exit(1);
    4850:	4505                	li	a0,1
    4852:	44d000ef          	jal	549e <exit>
    printf("%s: read returned %c, expected X\n", s, b);
    4856:	85d6                	mv	a1,s5
    4858:	00003517          	auipc	a0,0x3
    485c:	2e850513          	addi	a0,a0,744 # 7b40 <malloc+0x2188>
    4860:	09c010ef          	jal	58fc <printf>
    exit(1);
    4864:	4505                	li	a0,1
    4866:	439000ef          	jal	549e <exit>
      printf("%s: could not write to bigfile\n", s);
    486a:	85d6                	mv	a1,s5
    486c:	00003517          	auipc	a0,0x3
    4870:	30450513          	addi	a0,a0,772 # 7b70 <malloc+0x21b8>
    4874:	088010ef          	jal	58fc <printf>
      exit(-1);
    4878:	557d                	li	a0,-1
    487a:	425000ef          	jal	549e <exit>
    printf("%s: cannot re-open testfile\n", s);
    487e:	85d6                	mv	a1,s5
    4880:	00003517          	auipc	a0,0x3
    4884:	23850513          	addi	a0,a0,568 # 7ab8 <malloc+0x2100>
    4888:	074010ef          	jal	58fc <printf>
    exit(1);
    488c:	4505                	li	a0,1
    488e:	411000ef          	jal	549e <exit>
    printf("%s: cannot read testfile\n", s);
    4892:	85d6                	mv	a1,s5
    4894:	00003517          	auipc	a0,0x3
    4898:	28c50513          	addi	a0,a0,652 # 7b20 <malloc+0x2168>
    489c:	060010ef          	jal	58fc <printf>
    exit(1);
    48a0:	4505                	li	a0,1
    48a2:	3fd000ef          	jal	549e <exit>
    printf("%s: read returned %c, expected X\n", s, b);
    48a6:	85d6                	mv	a1,s5
    48a8:	00003517          	auipc	a0,0x3
    48ac:	29850513          	addi	a0,a0,664 # 7b40 <malloc+0x2188>
    48b0:	04c010ef          	jal	58fc <printf>
    exit(1);
    48b4:	4505                	li	a0,1
    48b6:	3e9000ef          	jal	549e <exit>

00000000000048ba <lazy_alloc>:
{
    48ba:	1141                	addi	sp,sp,-16
    48bc:	e406                	sd	ra,8(sp)
    48be:	e022                	sd	s0,0(sp)
    48c0:	0800                	addi	s0,sp,16
  prev_end = sbrklazy(REGION_SZ);
    48c2:	40000537          	lui	a0,0x40000
    48c6:	3bb000ef          	jal	5480 <sbrklazy>
  if (prev_end == (char *)SBRK_ERROR) {
    48ca:	57fd                	li	a5,-1
    48cc:	02f50a63          	beq	a0,a5,4900 <lazy_alloc+0x46>
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE)
    48d0:	6605                	lui	a2,0x1
    48d2:	962a                	add	a2,a2,a0
    48d4:	400017b7          	lui	a5,0x40001
    48d8:	00f50733          	add	a4,a0,a5
    48dc:	87b2                	mv	a5,a2
    48de:	000406b7          	lui	a3,0x40
    *(char **)i = i;
    48e2:	e39c                	sd	a5,0(a5)
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE)
    48e4:	97b6                	add	a5,a5,a3
    48e6:	fee79ee3          	bne	a5,a4,48e2 <lazy_alloc+0x28>
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE) {
    48ea:	000406b7          	lui	a3,0x40
    if (*(char **)i != i) {
    48ee:	621c                	ld	a5,0(a2)
    48f0:	02c79163          	bne	a5,a2,4912 <lazy_alloc+0x58>
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE) {
    48f4:	9636                	add	a2,a2,a3
    48f6:	fee61ce3          	bne	a2,a4,48ee <lazy_alloc+0x34>
  exit(0);
    48fa:	4501                	li	a0,0
    48fc:	3a3000ef          	jal	549e <exit>
    printf("sbrklazy() failed\n");
    4900:	00003517          	auipc	a0,0x3
    4904:	29050513          	addi	a0,a0,656 # 7b90 <malloc+0x21d8>
    4908:	7f5000ef          	jal	58fc <printf>
    exit(1);
    490c:	4505                	li	a0,1
    490e:	391000ef          	jal	549e <exit>
      printf("failed to read value from memory\n");
    4912:	00003517          	auipc	a0,0x3
    4916:	29650513          	addi	a0,a0,662 # 7ba8 <malloc+0x21f0>
    491a:	7e3000ef          	jal	58fc <printf>
      exit(1);
    491e:	4505                	li	a0,1
    4920:	37f000ef          	jal	549e <exit>

0000000000004924 <lazy_unmap>:
{
    4924:	7139                	addi	sp,sp,-64
    4926:	fc06                	sd	ra,56(sp)
    4928:	f822                	sd	s0,48(sp)
    492a:	0080                	addi	s0,sp,64
  prev_end = sbrklazy(REGION_SZ);
    492c:	40000537          	lui	a0,0x40000
    4930:	351000ef          	jal	5480 <sbrklazy>
  if (prev_end == (char *)SBRK_ERROR) {
    4934:	57fd                	li	a5,-1
    4936:	04f50863          	beq	a0,a5,4986 <lazy_unmap+0x62>
    493a:	f426                	sd	s1,40(sp)
    493c:	f04a                	sd	s2,32(sp)
    493e:	ec4e                	sd	s3,24(sp)
    4940:	e852                	sd	s4,16(sp)
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE)
    4942:	6905                	lui	s2,0x1
    4944:	992a                	add	s2,s2,a0
    4946:	400017b7          	lui	a5,0x40001
    494a:	00f504b3          	add	s1,a0,a5
    494e:	87ca                	mv	a5,s2
    4950:	01000737          	lui	a4,0x1000
    *(char **)i = i;
    4954:	e39c                	sd	a5,0(a5)
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE)
    4956:	97ba                	add	a5,a5,a4
    4958:	fe979ee3          	bne	a5,s1,4954 <lazy_unmap+0x30>
      wait(&status);
    495c:	fcc40993          	addi	s3,s0,-52
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE) {
    4960:	01000a37          	lui	s4,0x1000
    pid = fork();
    4964:	333000ef          	jal	5496 <fork>
    if (pid < 0) {
    4968:	02054c63          	bltz	a0,49a0 <lazy_unmap+0x7c>
    } else if (pid == 0) {
    496c:	c139                	beqz	a0,49b2 <lazy_unmap+0x8e>
      wait(&status);
    496e:	854e                	mv	a0,s3
    4970:	337000ef          	jal	54a6 <wait>
      if (status == 0) {
    4974:	fcc42783          	lw	a5,-52(s0)
    4978:	c7b1                	beqz	a5,49c4 <lazy_unmap+0xa0>
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE) {
    497a:	9952                	add	s2,s2,s4
    497c:	fe9914e3          	bne	s2,s1,4964 <lazy_unmap+0x40>
  exit(0);
    4980:	4501                	li	a0,0
    4982:	31d000ef          	jal	549e <exit>
    4986:	f426                	sd	s1,40(sp)
    4988:	f04a                	sd	s2,32(sp)
    498a:	ec4e                	sd	s3,24(sp)
    498c:	e852                	sd	s4,16(sp)
    printf("sbrklazy() failed\n");
    498e:	00003517          	auipc	a0,0x3
    4992:	20250513          	addi	a0,a0,514 # 7b90 <malloc+0x21d8>
    4996:	767000ef          	jal	58fc <printf>
    exit(1);
    499a:	4505                	li	a0,1
    499c:	303000ef          	jal	549e <exit>
      printf("error forking\n");
    49a0:	00003517          	auipc	a0,0x3
    49a4:	23050513          	addi	a0,a0,560 # 7bd0 <malloc+0x2218>
    49a8:	755000ef          	jal	58fc <printf>
      exit(1);
    49ac:	4505                	li	a0,1
    49ae:	2f1000ef          	jal	549e <exit>
      sbrklazy(-1L * REGION_SZ);
    49b2:	c0000537          	lui	a0,0xc0000
    49b6:	2cb000ef          	jal	5480 <sbrklazy>
      *(char **)i = i;
    49ba:	01293023          	sd	s2,0(s2) # 1000 <bigdir+0x10c>
      exit(0);
    49be:	4501                	li	a0,0
    49c0:	2df000ef          	jal	549e <exit>
        printf("memory not unmapped\n");
    49c4:	00003517          	auipc	a0,0x3
    49c8:	21c50513          	addi	a0,a0,540 # 7be0 <malloc+0x2228>
    49cc:	731000ef          	jal	58fc <printf>
        exit(1);
    49d0:	4505                	li	a0,1
    49d2:	2cd000ef          	jal	549e <exit>

00000000000049d6 <lazy_copy>:
{
    49d6:	7119                	addi	sp,sp,-128
    49d8:	fc86                	sd	ra,120(sp)
    49da:	f8a2                	sd	s0,112(sp)
    49dc:	f4a6                	sd	s1,104(sp)
    49de:	f0ca                	sd	s2,96(sp)
    49e0:	ecce                	sd	s3,88(sp)
    49e2:	e8d2                	sd	s4,80(sp)
    49e4:	e4d6                	sd	s5,72(sp)
    49e6:	e0da                	sd	s6,64(sp)
    49e8:	fc5e                	sd	s7,56(sp)
    49ea:	0100                	addi	s0,sp,128
    char *p = sbrk(0);
    49ec:	4501                	li	a0,0
    49ee:	27d000ef          	jal	546a <sbrk>
    49f2:	84aa                	mv	s1,a0
    sbrklazy(4 * PGSIZE);
    49f4:	6511                	lui	a0,0x4
    49f6:	28b000ef          	jal	5480 <sbrklazy>
    open(p + 8192, 0);
    49fa:	4581                	li	a1,0
    49fc:	6509                	lui	a0,0x2
    49fe:	9526                	add	a0,a0,s1
    4a00:	2df000ef          	jal	54de <open>
    void *xx = sbrk(0);
    4a04:	4501                	li	a0,0
    4a06:	265000ef          	jal	546a <sbrk>
    4a0a:	84aa                	mv	s1,a0
    void *ret = sbrk(-(((uint64)xx) + 1));
    4a0c:	fff54513          	not	a0,a0
    4a10:	2501                	sext.w	a0,a0
    4a12:	259000ef          	jal	546a <sbrk>
    if (ret != xx) {
    4a16:	00a48c63          	beq	s1,a0,4a2e <lazy_copy+0x58>
    4a1a:	85aa                	mv	a1,a0
      printf("sbrk(sbrk(0)+1) returned %p, not old sz\n", ret);
    4a1c:	00003517          	auipc	a0,0x3
    4a20:	1dc50513          	addi	a0,a0,476 # 7bf8 <malloc+0x2240>
    4a24:	6d9000ef          	jal	58fc <printf>
      exit(1);
    4a28:	4505                	li	a0,1
    4a2a:	275000ef          	jal	549e <exit>
  unsigned long bad[] = {
    4a2e:	00004797          	auipc	a5,0x4
    4a32:	8ba78793          	addi	a5,a5,-1862 # 82e8 <malloc+0x2930>
    4a36:	7fa8                	ld	a0,120(a5)
    4a38:	63cc                	ld	a1,128(a5)
    4a3a:	67d0                	ld	a2,136(a5)
    4a3c:	6bd4                	ld	a3,144(a5)
    4a3e:	6fd8                	ld	a4,152(a5)
    4a40:	f8a43023          	sd	a0,-128(s0)
    4a44:	f8b43423          	sd	a1,-120(s0)
    4a48:	f8c43823          	sd	a2,-112(s0)
    4a4c:	f8d43c23          	sd	a3,-104(s0)
    4a50:	fae43023          	sd	a4,-96(s0)
    4a54:	73dc                	ld	a5,160(a5)
    4a56:	faf43423          	sd	a5,-88(s0)
  for (int i = 0; i < sizeof(bad) / sizeof(bad[0]); i++) {
    4a5a:	f8040913          	addi	s2,s0,-128
    int fd = open("README", 0);
    4a5e:	00001a97          	auipc	s5,0x1
    4a62:	262a8a93          	addi	s5,s5,610 # 5cc0 <malloc+0x308>
    if (read(fd, (char *)bad[i], 512) >= 0) {
    4a66:	20000a13          	li	s4,512
    fd = open("junk", O_CREATE | O_RDWR | O_TRUNC);
    4a6a:	60200b93          	li	s7,1538
    4a6e:	00001b17          	auipc	s6,0x1
    4a72:	162b0b13          	addi	s6,s6,354 # 5bd0 <malloc+0x218>
    int fd = open("README", 0);
    4a76:	4581                	li	a1,0
    4a78:	8556                	mv	a0,s5
    4a7a:	265000ef          	jal	54de <open>
    4a7e:	84aa                	mv	s1,a0
    if (fd < 0) {
    4a80:	04054563          	bltz	a0,4aca <lazy_copy+0xf4>
    if (read(fd, (char *)bad[i], 512) >= 0) {
    4a84:	00093983          	ld	s3,0(s2)
    4a88:	8652                	mv	a2,s4
    4a8a:	85ce                	mv	a1,s3
    4a8c:	22b000ef          	jal	54b6 <read>
    4a90:	04055663          	bgez	a0,4adc <lazy_copy+0x106>
    close(fd);
    4a94:	8526                	mv	a0,s1
    4a96:	231000ef          	jal	54c6 <close>
    fd = open("junk", O_CREATE | O_RDWR | O_TRUNC);
    4a9a:	85de                	mv	a1,s7
    4a9c:	855a                	mv	a0,s6
    4a9e:	241000ef          	jal	54de <open>
    4aa2:	84aa                	mv	s1,a0
    if (fd < 0) {
    4aa4:	04054563          	bltz	a0,4aee <lazy_copy+0x118>
    if (write(fd, (char *)bad[i], 512) >= 0) {
    4aa8:	8652                	mv	a2,s4
    4aaa:	85ce                	mv	a1,s3
    4aac:	213000ef          	jal	54be <write>
    4ab0:	04055863          	bgez	a0,4b00 <lazy_copy+0x12a>
    close(fd);
    4ab4:	8526                	mv	a0,s1
    4ab6:	211000ef          	jal	54c6 <close>
  for (int i = 0; i < sizeof(bad) / sizeof(bad[0]); i++) {
    4aba:	0921                	addi	s2,s2,8
    4abc:	fb040793          	addi	a5,s0,-80
    4ac0:	faf91be3          	bne	s2,a5,4a76 <lazy_copy+0xa0>
  exit(0);
    4ac4:	4501                	li	a0,0
    4ac6:	1d9000ef          	jal	549e <exit>
      printf("cannot open README\n");
    4aca:	00003517          	auipc	a0,0x3
    4ace:	15e50513          	addi	a0,a0,350 # 7c28 <malloc+0x2270>
    4ad2:	62b000ef          	jal	58fc <printf>
      exit(1);
    4ad6:	4505                	li	a0,1
    4ad8:	1c7000ef          	jal	549e <exit>
      printf("read succeeded\n");
    4adc:	00003517          	auipc	a0,0x3
    4ae0:	16450513          	addi	a0,a0,356 # 7c40 <malloc+0x2288>
    4ae4:	619000ef          	jal	58fc <printf>
      exit(1);
    4ae8:	4505                	li	a0,1
    4aea:	1b5000ef          	jal	549e <exit>
      printf("cannot open junk\n");
    4aee:	00003517          	auipc	a0,0x3
    4af2:	16250513          	addi	a0,a0,354 # 7c50 <malloc+0x2298>
    4af6:	607000ef          	jal	58fc <printf>
      exit(1);
    4afa:	4505                	li	a0,1
    4afc:	1a3000ef          	jal	549e <exit>
      printf("write succeeded\n");
    4b00:	00003517          	auipc	a0,0x3
    4b04:	16850513          	addi	a0,a0,360 # 7c68 <malloc+0x22b0>
    4b08:	5f5000ef          	jal	58fc <printf>
      exit(1);
    4b0c:	4505                	li	a0,1
    4b0e:	191000ef          	jal	549e <exit>

0000000000004b12 <lazy_sbrk>:
{
    4b12:	7179                	addi	sp,sp,-48
    4b14:	f406                	sd	ra,40(sp)
    4b16:	f022                	sd	s0,32(sp)
    4b18:	ec26                	sd	s1,24(sp)
    4b1a:	e84a                	sd	s2,16(sp)
    4b1c:	e44e                	sd	s3,8(sp)
    4b1e:	1800                	addi	s0,sp,48
  char *p = sbrk(0);
    4b20:	4501                	li	a0,0
    4b22:	149000ef          	jal	546a <sbrk>
    4b26:	84aa                	mv	s1,a0
  while ((uint64)p < MAXVA - (1 << 30)) {
    4b28:	0ff00793          	li	a5,255
    4b2c:	07fa                	slli	a5,a5,0x1e
    4b2e:	00f57e63          	bgeu	a0,a5,4b4a <lazy_sbrk+0x38>
    p = sbrklazy(1 << 30);
    4b32:	400009b7          	lui	s3,0x40000
  while ((uint64)p < MAXVA - (1 << 30)) {
    4b36:	893e                	mv	s2,a5
    p = sbrklazy(1 << 30);
    4b38:	854e                	mv	a0,s3
    4b3a:	147000ef          	jal	5480 <sbrklazy>
    p = sbrklazy(0);
    4b3e:	4501                	li	a0,0
    4b40:	141000ef          	jal	5480 <sbrklazy>
    4b44:	84aa                	mv	s1,a0
  while ((uint64)p < MAXVA - (1 << 30)) {
    4b46:	ff2569e3          	bltu	a0,s2,4b38 <lazy_sbrk+0x26>
  int n = TRAPFRAME - PGSIZE - (uint64)p;
    4b4a:	7975                	lui	s2,0xffffd
    4b4c:	4099093b          	subw	s2,s2,s1
  char *p1 = sbrklazy(n);
    4b50:	854a                	mv	a0,s2
    4b52:	12f000ef          	jal	5480 <sbrklazy>
    4b56:	862a                	mv	a2,a0
  if (p1 < 0 || p1 != p) {
    4b58:	00950d63          	beq	a0,s1,4b72 <lazy_sbrk+0x60>
    printf("sbrklazy(%d) returned %p, not expected %p\n", n, p1, p);
    4b5c:	86a6                	mv	a3,s1
    4b5e:	85ca                	mv	a1,s2
    4b60:	00003517          	auipc	a0,0x3
    4b64:	12050513          	addi	a0,a0,288 # 7c80 <malloc+0x22c8>
    4b68:	595000ef          	jal	58fc <printf>
    exit(1);
    4b6c:	4505                	li	a0,1
    4b6e:	131000ef          	jal	549e <exit>
  p = sbrk(PGSIZE);
    4b72:	6505                	lui	a0,0x1
    4b74:	0f7000ef          	jal	546a <sbrk>
    4b78:	862a                	mv	a2,a0
  if (p < 0 || (uint64)p != TRAPFRAME - PGSIZE) {
    4b7a:	040007b7          	lui	a5,0x4000
    4b7e:	17f5                	addi	a5,a5,-3 # 3fffffd <base+0x3ff0315>
    4b80:	07b2                	slli	a5,a5,0xc
    4b82:	00f50c63          	beq	a0,a5,4b9a <lazy_sbrk+0x88>
    printf("sbrk(%d) returned %p, not expected TRAPFRAME-PGSIZE\n", PGSIZE, p);
    4b86:	6585                	lui	a1,0x1
    4b88:	00003517          	auipc	a0,0x3
    4b8c:	12850513          	addi	a0,a0,296 # 7cb0 <malloc+0x22f8>
    4b90:	56d000ef          	jal	58fc <printf>
    exit(1);
    4b94:	4505                	li	a0,1
    4b96:	109000ef          	jal	549e <exit>
  p[0] = 1;
    4b9a:	040007b7          	lui	a5,0x4000
    4b9e:	17f5                	addi	a5,a5,-3 # 3fffffd <base+0x3ff0315>
    4ba0:	07b2                	slli	a5,a5,0xc
    4ba2:	4705                	li	a4,1
    4ba4:	00e78023          	sb	a4,0(a5)
  if (p[1] != 0) {
    4ba8:	0017c783          	lbu	a5,1(a5)
    4bac:	cb91                	beqz	a5,4bc0 <lazy_sbrk+0xae>
    printf("sbrk() returned non-zero-filled memory\n");
    4bae:	00003517          	auipc	a0,0x3
    4bb2:	13a50513          	addi	a0,a0,314 # 7ce8 <malloc+0x2330>
    4bb6:	547000ef          	jal	58fc <printf>
    exit(1);
    4bba:	4505                	li	a0,1
    4bbc:	0e3000ef          	jal	549e <exit>
  p = sbrk(1);
    4bc0:	4505                	li	a0,1
    4bc2:	0a9000ef          	jal	546a <sbrk>
    4bc6:	85aa                	mv	a1,a0
  if ((uint64)p != -1) {
    4bc8:	57fd                	li	a5,-1
    4bca:	00f50b63          	beq	a0,a5,4be0 <lazy_sbrk+0xce>
    printf("sbrk(1) returned %p, expected error\n", p);
    4bce:	00003517          	auipc	a0,0x3
    4bd2:	14250513          	addi	a0,a0,322 # 7d10 <malloc+0x2358>
    4bd6:	527000ef          	jal	58fc <printf>
    exit(1);
    4bda:	4505                	li	a0,1
    4bdc:	0c3000ef          	jal	549e <exit>
  p = sbrklazy(1);
    4be0:	4505                	li	a0,1
    4be2:	09f000ef          	jal	5480 <sbrklazy>
    4be6:	85aa                	mv	a1,a0
  if ((uint64)p != -1) {
    4be8:	57fd                	li	a5,-1
    4bea:	00f50b63          	beq	a0,a5,4c00 <lazy_sbrk+0xee>
    printf("sbrklazy(1) returned %p, expected error\n", p);
    4bee:	00003517          	auipc	a0,0x3
    4bf2:	14a50513          	addi	a0,a0,330 # 7d38 <malloc+0x2380>
    4bf6:	507000ef          	jal	58fc <printf>
    exit(1);
    4bfa:	4505                	li	a0,1
    4bfc:	0a3000ef          	jal	549e <exit>
  exit(0);
    4c00:	4501                	li	a0,0
    4c02:	09d000ef          	jal	549e <exit>

0000000000004c06 <lazy_copyinstr>:
{
    4c06:	7139                	addi	sp,sp,-64
    4c08:	fc06                	sd	ra,56(sp)
    4c0a:	f822                	sd	s0,48(sp)
    4c0c:	f426                	sd	s1,40(sp)
    4c0e:	f04a                	sd	s2,32(sp)
    4c10:	0080                	addi	s0,sp,64
    4c12:	892a                	mv	s2,a0
  char *p = sbrk(0);
    4c14:	4501                	li	a0,0
    4c16:	055000ef          	jal	546a <sbrk>
  sbrk(PGSIZE - ((uint64)p % PGSIZE));
    4c1a:	03451793          	slli	a5,a0,0x34
    4c1e:	93d1                	srli	a5,a5,0x34
    4c20:	6505                	lui	a0,0x1
    4c22:	9d1d                	subw	a0,a0,a5
    4c24:	047000ef          	jal	546a <sbrk>
  p = sbrk(0);
    4c28:	4501                	li	a0,0
    4c2a:	041000ef          	jal	546a <sbrk>
  if ((uint64)p % PGSIZE != 0) {
    4c2e:	03451793          	slli	a5,a0,0x34
    4c32:	eba1                	bnez	a5,4c82 <lazy_copyinstr+0x7c>
    4c34:	84aa                	mv	s1,a0
  sbrklazy(2 * PGSIZE);
    4c36:	6509                	lui	a0,0x2
    4c38:	049000ef          	jal	5480 <sbrklazy>
  p[4095] = '/';
    4c3c:	6505                	lui	a0,0x1
    4c3e:	00a487b3          	add	a5,s1,a0
    4c42:	02f00713          	li	a4,47
    4c46:	fee78fa3          	sb	a4,-1(a5)
  int fd = open(&p[4095], O_RDONLY);
    4c4a:	157d                	addi	a0,a0,-1 # fff <bigdir+0x10b>
    4c4c:	4581                	li	a1,0
    4c4e:	9526                	add	a0,a0,s1
    4c50:	08f000ef          	jal	54de <open>
    4c54:	84aa                	mv	s1,a0
  if (fd < 0) {
    4c56:	04054063          	bltz	a0,4c96 <lazy_copyinstr+0x90>
  int r = fstat(fd, &st);
    4c5a:	fc840593          	addi	a1,s0,-56
    4c5e:	099000ef          	jal	54f6 <fstat>
  if (r < 0) {
    4c62:	04054363          	bltz	a0,4ca8 <lazy_copyinstr+0xa2>
  if (st.type != T_DIR) {
    4c66:	fd041703          	lh	a4,-48(s0)
    4c6a:	4785                	li	a5,1
    4c6c:	04f71763          	bne	a4,a5,4cba <lazy_copyinstr+0xb4>
  close(fd);
    4c70:	8526                	mv	a0,s1
    4c72:	055000ef          	jal	54c6 <close>
}
    4c76:	70e2                	ld	ra,56(sp)
    4c78:	7442                	ld	s0,48(sp)
    4c7a:	74a2                	ld	s1,40(sp)
    4c7c:	7902                	ld	s2,32(sp)
    4c7e:	6121                	addi	sp,sp,64
    4c80:	8082                	ret
    printf("%s: sbrk did not align\n", s);
    4c82:	85ca                	mv	a1,s2
    4c84:	00003517          	auipc	a0,0x3
    4c88:	e5450513          	addi	a0,a0,-428 # 7ad8 <malloc+0x2120>
    4c8c:	471000ef          	jal	58fc <printf>
    exit(1);
    4c90:	4505                	li	a0,1
    4c92:	00d000ef          	jal	549e <exit>
    printf("could not open /");
    4c96:	00003517          	auipc	a0,0x3
    4c9a:	0d250513          	addi	a0,a0,210 # 7d68 <malloc+0x23b0>
    4c9e:	45f000ef          	jal	58fc <printf>
    exit(1);
    4ca2:	4505                	li	a0,1
    4ca4:	7fa000ef          	jal	549e <exit>
    printf("could not stat /");
    4ca8:	00003517          	auipc	a0,0x3
    4cac:	0d850513          	addi	a0,a0,216 # 7d80 <malloc+0x23c8>
    4cb0:	44d000ef          	jal	58fc <printf>
    exit(1);
    4cb4:	4505                	li	a0,1
    4cb6:	7e8000ef          	jal	549e <exit>
    printf("/ is not T_DIR");
    4cba:	00003517          	auipc	a0,0x3
    4cbe:	0de50513          	addi	a0,a0,222 # 7d98 <malloc+0x23e0>
    4cc2:	43b000ef          	jal	58fc <printf>
    exit(1);
    4cc6:	4505                	li	a0,1
    4cc8:	7d6000ef          	jal	549e <exit>

0000000000004ccc <fsfull>:
{
    4ccc:	7131                	addi	sp,sp,-192
    4cce:	fd06                	sd	ra,184(sp)
    4cd0:	f922                	sd	s0,176(sp)
    4cd2:	f526                	sd	s1,168(sp)
    4cd4:	f14a                	sd	s2,160(sp)
    4cd6:	ed4e                	sd	s3,152(sp)
    4cd8:	e952                	sd	s4,144(sp)
    4cda:	e556                	sd	s5,136(sp)
    4cdc:	e15a                	sd	s6,128(sp)
    4cde:	fcde                	sd	s7,120(sp)
    4ce0:	f8e2                	sd	s8,112(sp)
    4ce2:	f4e6                	sd	s9,104(sp)
    4ce4:	f0ea                	sd	s10,96(sp)
    4ce6:	ecee                	sd	s11,88(sp)
    4ce8:	0180                	addi	s0,sp,192
  printf("fsfull test\n");
    4cea:	00003517          	auipc	a0,0x3
    4cee:	0be50513          	addi	a0,a0,190 # 7da8 <malloc+0x23f0>
    4cf2:	40b000ef          	jal	58fc <printf>
  int fsblocks = 0;
    4cf6:	4981                	li	s3,0
  for (nfiles = 0;; nfiles++) {
    4cf8:	4481                	li	s1,0
    name[0] = 'f';
    4cfa:	06600d93          	li	s11,102
    name[1] = '0' + nfiles / 1000;
    4cfe:	106257b7          	lui	a5,0x10625
    4d02:	dd378793          	addi	a5,a5,-557 # 10624dd3 <base+0x106150eb>
    4d06:	f4f43423          	sd	a5,-184(s0)
    name[2] = '0' + (nfiles % 1000) / 100;
    4d0a:	51eb8b37          	lui	s6,0x51eb8
    4d0e:	51fb0b13          	addi	s6,s6,1311 # 51eb851f <base+0x51ea8837>
    name[3] = '0' + (nfiles % 100) / 10;
    4d12:	66666ab7          	lui	s5,0x66666
    4d16:	667a8a93          	addi	s5,s5,1639 # 66666667 <base+0x6665697f>
    printf("writing %s\n", name);
    4d1a:	f5040d13          	addi	s10,s0,-176
    name[0] = 'f';
    4d1e:	f5b40823          	sb	s11,-176(s0)
    name[1] = '0' + nfiles / 1000;
    4d22:	f4843783          	ld	a5,-184(s0)
    4d26:	02f487b3          	mul	a5,s1,a5
    4d2a:	9799                	srai	a5,a5,0x26
    4d2c:	41f4d69b          	sraiw	a3,s1,0x1f
    4d30:	9f95                	subw	a5,a5,a3
    4d32:	0307871b          	addiw	a4,a5,48
    4d36:	f4e408a3          	sb	a4,-175(s0)
    name[2] = '0' + (nfiles % 1000) / 100;
    4d3a:	3e800713          	li	a4,1000
    4d3e:	02f707bb          	mulw	a5,a4,a5
    4d42:	40f487bb          	subw	a5,s1,a5
    4d46:	03678733          	mul	a4,a5,s6
    4d4a:	9715                	srai	a4,a4,0x25
    4d4c:	41f7d79b          	sraiw	a5,a5,0x1f
    4d50:	40f707bb          	subw	a5,a4,a5
    4d54:	0307879b          	addiw	a5,a5,48
    4d58:	f4f40923          	sb	a5,-174(s0)
    name[3] = '0' + (nfiles % 100) / 10;
    4d5c:	036487b3          	mul	a5,s1,s6
    4d60:	9795                	srai	a5,a5,0x25
    4d62:	9f95                	subw	a5,a5,a3
    4d64:	06400713          	li	a4,100
    4d68:	02f707bb          	mulw	a5,a4,a5
    4d6c:	40f487bb          	subw	a5,s1,a5
    4d70:	03578733          	mul	a4,a5,s5
    4d74:	9709                	srai	a4,a4,0x22
    4d76:	41f7d79b          	sraiw	a5,a5,0x1f
    4d7a:	40f707bb          	subw	a5,a4,a5
    4d7e:	0307879b          	addiw	a5,a5,48
    4d82:	f4f409a3          	sb	a5,-173(s0)
    name[4] = '0' + (nfiles % 10);
    4d86:	03548733          	mul	a4,s1,s5
    4d8a:	9709                	srai	a4,a4,0x22
    4d8c:	9f15                	subw	a4,a4,a3
    4d8e:	0027179b          	slliw	a5,a4,0x2
    4d92:	9fb9                	addw	a5,a5,a4
    4d94:	0017979b          	slliw	a5,a5,0x1
    4d98:	40f487bb          	subw	a5,s1,a5
    4d9c:	0307879b          	addiw	a5,a5,48
    4da0:	f4f40a23          	sb	a5,-172(s0)
    name[5] = '\0';
    4da4:	f4040aa3          	sb	zero,-171(s0)
    printf("writing %s\n", name);
    4da8:	85ea                	mv	a1,s10
    4daa:	00003517          	auipc	a0,0x3
    4dae:	00e50513          	addi	a0,a0,14 # 7db8 <malloc+0x2400>
    4db2:	34b000ef          	jal	58fc <printf>
    int fd = open(name, O_CREATE | O_RDWR);
    4db6:	20200593          	li	a1,514
    4dba:	856a                	mv	a0,s10
    4dbc:	722000ef          	jal	54de <open>
    4dc0:	892a                	mv	s2,a0
    if (fd < 0) {
    4dc2:	0e055c63          	bgez	a0,4eba <fsfull+0x1ee>
      printf("open %s failed\n", name);
    4dc6:	f5040593          	addi	a1,s0,-176
    4dca:	00003517          	auipc	a0,0x3
    4dce:	ffe50513          	addi	a0,a0,-2 # 7dc8 <malloc+0x2410>
    4dd2:	32b000ef          	jal	58fc <printf>
  while (nfiles >= 0) {
    4dd6:	0a04cc63          	bltz	s1,4e8e <fsfull+0x1c2>
    name[0] = 'f';
    4dda:	06600c93          	li	s9,102
    name[1] = '0' + nfiles / 1000;
    4dde:	10625ab7          	lui	s5,0x10625
    4de2:	dd3a8a93          	addi	s5,s5,-557 # 10624dd3 <base+0x106150eb>
    name[2] = '0' + (nfiles % 1000) / 100;
    4de6:	3e800c13          	li	s8,1000
    4dea:	51eb8a37          	lui	s4,0x51eb8
    4dee:	51fa0a13          	addi	s4,s4,1311 # 51eb851f <base+0x51ea8837>
    name[3] = '0' + (nfiles % 100) / 10;
    4df2:	06400b93          	li	s7,100
    4df6:	66666937          	lui	s2,0x66666
    4dfa:	66790913          	addi	s2,s2,1639 # 66666667 <base+0x6665697f>
    unlink(name);
    4dfe:	f5040b13          	addi	s6,s0,-176
    name[0] = 'f';
    4e02:	f5940823          	sb	s9,-176(s0)
    name[1] = '0' + nfiles / 1000;
    4e06:	035487b3          	mul	a5,s1,s5
    4e0a:	9799                	srai	a5,a5,0x26
    4e0c:	41f4d69b          	sraiw	a3,s1,0x1f
    4e10:	9f95                	subw	a5,a5,a3
    4e12:	0307871b          	addiw	a4,a5,48
    4e16:	f4e408a3          	sb	a4,-175(s0)
    name[2] = '0' + (nfiles % 1000) / 100;
    4e1a:	02fc07bb          	mulw	a5,s8,a5
    4e1e:	40f487bb          	subw	a5,s1,a5
    4e22:	03478733          	mul	a4,a5,s4
    4e26:	9715                	srai	a4,a4,0x25
    4e28:	41f7d79b          	sraiw	a5,a5,0x1f
    4e2c:	40f707bb          	subw	a5,a4,a5
    4e30:	0307879b          	addiw	a5,a5,48
    4e34:	f4f40923          	sb	a5,-174(s0)
    name[3] = '0' + (nfiles % 100) / 10;
    4e38:	034487b3          	mul	a5,s1,s4
    4e3c:	9795                	srai	a5,a5,0x25
    4e3e:	9f95                	subw	a5,a5,a3
    4e40:	02fb87bb          	mulw	a5,s7,a5
    4e44:	40f487bb          	subw	a5,s1,a5
    4e48:	03278733          	mul	a4,a5,s2
    4e4c:	9709                	srai	a4,a4,0x22
    4e4e:	41f7d79b          	sraiw	a5,a5,0x1f
    4e52:	40f707bb          	subw	a5,a4,a5
    4e56:	0307879b          	addiw	a5,a5,48
    4e5a:	f4f409a3          	sb	a5,-173(s0)
    name[4] = '0' + (nfiles % 10);
    4e5e:	03248733          	mul	a4,s1,s2
    4e62:	9709                	srai	a4,a4,0x22
    4e64:	9f15                	subw	a4,a4,a3
    4e66:	0027179b          	slliw	a5,a4,0x2
    4e6a:	9fb9                	addw	a5,a5,a4
    4e6c:	0017979b          	slliw	a5,a5,0x1
    4e70:	40f487bb          	subw	a5,s1,a5
    4e74:	0307879b          	addiw	a5,a5,48
    4e78:	f4f40a23          	sb	a5,-172(s0)
    name[5] = '\0';
    4e7c:	f4040aa3          	sb	zero,-171(s0)
    unlink(name);
    4e80:	855a                	mv	a0,s6
    4e82:	66c000ef          	jal	54ee <unlink>
    nfiles--;
    4e86:	34fd                	addiw	s1,s1,-1
  while (nfiles >= 0) {
    4e88:	57fd                	li	a5,-1
    4e8a:	f6f49ce3          	bne	s1,a5,4e02 <fsfull+0x136>
  printf("fsfull test finished, %d blocks\n", fsblocks);
    4e8e:	85ce                	mv	a1,s3
    4e90:	00003517          	auipc	a0,0x3
    4e94:	f5850513          	addi	a0,a0,-168 # 7de8 <malloc+0x2430>
    4e98:	265000ef          	jal	58fc <printf>
}
    4e9c:	70ea                	ld	ra,184(sp)
    4e9e:	744a                	ld	s0,176(sp)
    4ea0:	74aa                	ld	s1,168(sp)
    4ea2:	790a                	ld	s2,160(sp)
    4ea4:	69ea                	ld	s3,152(sp)
    4ea6:	6a4a                	ld	s4,144(sp)
    4ea8:	6aaa                	ld	s5,136(sp)
    4eaa:	6b0a                	ld	s6,128(sp)
    4eac:	7be6                	ld	s7,120(sp)
    4eae:	7c46                	ld	s8,112(sp)
    4eb0:	7ca6                	ld	s9,104(sp)
    4eb2:	7d06                	ld	s10,96(sp)
    4eb4:	6de6                	ld	s11,88(sp)
    4eb6:	6129                	addi	sp,sp,192
    4eb8:	8082                	ret
    int total = 0;
    4eba:	4a01                	li	s4,0
      int cc = write(fd, buf, BSIZE);
    4ebc:	40000c93          	li	s9,1024
    4ec0:	00008c17          	auipc	s8,0x8
    4ec4:	e28c0c13          	addi	s8,s8,-472 # cce8 <buf>
      if (cc < BSIZE)
    4ec8:	3ff00b93          	li	s7,1023
      int cc = write(fd, buf, BSIZE);
    4ecc:	8666                	mv	a2,s9
    4ece:	85e2                	mv	a1,s8
    4ed0:	854a                	mv	a0,s2
    4ed2:	5ec000ef          	jal	54be <write>
      if (cc < BSIZE)
    4ed6:	00abd663          	bge	s7,a0,4ee2 <fsfull+0x216>
      total += cc;
    4eda:	00aa0a3b          	addw	s4,s4,a0
      fsblocks++;
    4ede:	2985                	addiw	s3,s3,1 # 40000001 <base+0x3fff0319>
    while (1) {
    4ee0:	b7f5                	j	4ecc <fsfull+0x200>
    printf("wrote %d bytes\n", total);
    4ee2:	85d2                	mv	a1,s4
    4ee4:	00003517          	auipc	a0,0x3
    4ee8:	ef450513          	addi	a0,a0,-268 # 7dd8 <malloc+0x2420>
    4eec:	211000ef          	jal	58fc <printf>
    close(fd);
    4ef0:	854a                	mv	a0,s2
    4ef2:	5d4000ef          	jal	54c6 <close>
    if (total == 0)
    4ef6:	ee0a00e3          	beqz	s4,4dd6 <fsfull+0x10a>
  for (nfiles = 0;; nfiles++) {
    4efa:	2485                	addiw	s1,s1,1
    4efc:	b50d                	j	4d1e <fsfull+0x52>

0000000000004efe <run>:

// run each test in its own process. run returns 1 if child's exit()
// indicates success.
int
run(void f(char *), char *s)
{
    4efe:	7179                	addi	sp,sp,-48
    4f00:	f406                	sd	ra,40(sp)
    4f02:	f022                	sd	s0,32(sp)
    4f04:	ec26                	sd	s1,24(sp)
    4f06:	e84a                	sd	s2,16(sp)
    4f08:	1800                	addi	s0,sp,48
    4f0a:	84aa                	mv	s1,a0
    4f0c:	892e                	mv	s2,a1
  int pid;
  int xstatus;

  printf("test %s: ", s);
    4f0e:	00003517          	auipc	a0,0x3
    4f12:	f0250513          	addi	a0,a0,-254 # 7e10 <malloc+0x2458>
    4f16:	1e7000ef          	jal	58fc <printf>
  if ((pid = fork()) < 0) {
    4f1a:	57c000ef          	jal	5496 <fork>
    4f1e:	02054a63          	bltz	a0,4f52 <run+0x54>
    printf("runtest: fork error\n");
    exit(1);
  }
  if (pid == 0) {
    4f22:	c129                	beqz	a0,4f64 <run+0x66>
    f(s);
    exit(0);
  } else {
    wait(&xstatus);
    4f24:	fdc40513          	addi	a0,s0,-36
    4f28:	57e000ef          	jal	54a6 <wait>
    if (xstatus != 0)
    4f2c:	fdc42783          	lw	a5,-36(s0)
    4f30:	cf9d                	beqz	a5,4f6e <run+0x70>
      printf("FAILED\n");
    4f32:	00003517          	auipc	a0,0x3
    4f36:	f0650513          	addi	a0,a0,-250 # 7e38 <malloc+0x2480>
    4f3a:	1c3000ef          	jal	58fc <printf>
    else
      printf("OK\n");
    return xstatus == 0;
    4f3e:	fdc42503          	lw	a0,-36(s0)
  }
}
    4f42:	00153513          	seqz	a0,a0
    4f46:	70a2                	ld	ra,40(sp)
    4f48:	7402                	ld	s0,32(sp)
    4f4a:	64e2                	ld	s1,24(sp)
    4f4c:	6942                	ld	s2,16(sp)
    4f4e:	6145                	addi	sp,sp,48
    4f50:	8082                	ret
    printf("runtest: fork error\n");
    4f52:	00003517          	auipc	a0,0x3
    4f56:	ece50513          	addi	a0,a0,-306 # 7e20 <malloc+0x2468>
    4f5a:	1a3000ef          	jal	58fc <printf>
    exit(1);
    4f5e:	4505                	li	a0,1
    4f60:	53e000ef          	jal	549e <exit>
    f(s);
    4f64:	854a                	mv	a0,s2
    4f66:	9482                	jalr	s1
    exit(0);
    4f68:	4501                	li	a0,0
    4f6a:	534000ef          	jal	549e <exit>
      printf("OK\n");
    4f6e:	00003517          	auipc	a0,0x3
    4f72:	ed250513          	addi	a0,a0,-302 # 7e40 <malloc+0x2488>
    4f76:	187000ef          	jal	58fc <printf>
    4f7a:	b7d1                	j	4f3e <run+0x40>

0000000000004f7c <runtests>:

int
runtests(struct test *tests, char *justone, int continuous)
{
    4f7c:	7179                	addi	sp,sp,-48
    4f7e:	f406                	sd	ra,40(sp)
    4f80:	f022                	sd	s0,32(sp)
    4f82:	ec26                	sd	s1,24(sp)
    4f84:	e44e                	sd	s3,8(sp)
    4f86:	1800                	addi	s0,sp,48
    4f88:	84aa                	mv	s1,a0
  int ntests = 0;
  for (struct test *t = tests; t->s != 0; t++) {
    4f8a:	6508                	ld	a0,8(a0)
    4f8c:	c125                	beqz	a0,4fec <runtests+0x70>
    4f8e:	e84a                	sd	s2,16(sp)
    4f90:	e052                	sd	s4,0(sp)
    4f92:	892e                	mv	s2,a1
    if ((justone == 0) || strcmp(t->s, justone) == 0) {
      ntests++;
      if (!run(t->f, t->s)) {
        if (continuous != 2) {
    4f94:	1679                	addi	a2,a2,-2 # ffe <bigdir+0x10a>
    4f96:	00c03a33          	snez	s4,a2
  int ntests = 0;
    4f9a:	4981                	li	s3,0
    4f9c:	a831                	j	4fb8 <runtests+0x3c>
      if (!run(t->f, t->s)) {
    4f9e:	648c                	ld	a1,8(s1)
    4fa0:	6088                	ld	a0,0(s1)
    4fa2:	f5dff0ef          	jal	4efe <run>
    4fa6:	00153513          	seqz	a0,a0
        if (continuous != 2) {
    4faa:	00aa7533          	and	a0,s4,a0
    4fae:	ed01                	bnez	a0,4fc6 <runtests+0x4a>
      ntests++;
    4fb0:	2985                	addiw	s3,s3,1
  for (struct test *t = tests; t->s != 0; t++) {
    4fb2:	04c1                	addi	s1,s1,16
    4fb4:	6488                	ld	a0,8(s1)
    4fb6:	c115                	beqz	a0,4fda <runtests+0x5e>
    if ((justone == 0) || strcmp(t->s, justone) == 0) {
    4fb8:	fe0903e3          	beqz	s2,4f9e <runtests+0x22>
    4fbc:	85ca                	mv	a1,s2
    4fbe:	25a000ef          	jal	5218 <strcmp>
    4fc2:	f965                	bnez	a0,4fb2 <runtests+0x36>
    4fc4:	bfe9                	j	4f9e <runtests+0x22>
          printf("SOME TESTS FAILED\n");
    4fc6:	00003517          	auipc	a0,0x3
    4fca:	e8250513          	addi	a0,a0,-382 # 7e48 <malloc+0x2490>
    4fce:	12f000ef          	jal	58fc <printf>
          return -1;
    4fd2:	59fd                	li	s3,-1
    4fd4:	6942                	ld	s2,16(sp)
    4fd6:	6a02                	ld	s4,0(sp)
    4fd8:	a019                	j	4fde <runtests+0x62>
    4fda:	6942                	ld	s2,16(sp)
    4fdc:	6a02                	ld	s4,0(sp)
        }
      }
    }
  }
  return ntests;
}
    4fde:	854e                	mv	a0,s3
    4fe0:	70a2                	ld	ra,40(sp)
    4fe2:	7402                	ld	s0,32(sp)
    4fe4:	64e2                	ld	s1,24(sp)
    4fe6:	69a2                	ld	s3,8(sp)
    4fe8:	6145                	addi	sp,sp,48
    4fea:	8082                	ret
  return ntests;
    4fec:	4981                	li	s3,0
    4fee:	bfc5                	j	4fde <runtests+0x62>

0000000000004ff0 <countfree>:

// use sbrk() to count how many free physical memory pages there are.
int
countfree()
{
    4ff0:	7179                	addi	sp,sp,-48
    4ff2:	f406                	sd	ra,40(sp)
    4ff4:	f022                	sd	s0,32(sp)
    4ff6:	ec26                	sd	s1,24(sp)
    4ff8:	e84a                	sd	s2,16(sp)
    4ffa:	e44e                	sd	s3,8(sp)
    4ffc:	e052                	sd	s4,0(sp)
    4ffe:	1800                	addi	s0,sp,48
  int n = 0;
  uint64 sz0 = (uint64)sbrk(0);
    5000:	4501                	li	a0,0
    5002:	468000ef          	jal	546a <sbrk>
    5006:	8a2a                	mv	s4,a0
  int n = 0;
    5008:	4481                	li	s1,0
  while (1) {
    char *a = sbrk(PGSIZE);
    500a:	6985                	lui	s3,0x1
    if (a == SBRK_ERROR) {
    500c:	597d                	li	s2,-1
    char *a = sbrk(PGSIZE);
    500e:	854e                	mv	a0,s3
    5010:	45a000ef          	jal	546a <sbrk>
    if (a == SBRK_ERROR) {
    5014:	01250463          	beq	a0,s2,501c <countfree+0x2c>
      break;
    }
    n += 1;
    5018:	2485                	addiw	s1,s1,1
  while (1) {
    501a:	bfd5                	j	500e <countfree+0x1e>
  }
  sbrk(-((uint64)sbrk(0) - sz0));
    501c:	4501                	li	a0,0
    501e:	44c000ef          	jal	546a <sbrk>
    5022:	40aa053b          	subw	a0,s4,a0
    5026:	444000ef          	jal	546a <sbrk>
  return n;
}
    502a:	8526                	mv	a0,s1
    502c:	70a2                	ld	ra,40(sp)
    502e:	7402                	ld	s0,32(sp)
    5030:	64e2                	ld	s1,24(sp)
    5032:	6942                	ld	s2,16(sp)
    5034:	69a2                	ld	s3,8(sp)
    5036:	6a02                	ld	s4,0(sp)
    5038:	6145                	addi	sp,sp,48
    503a:	8082                	ret

000000000000503c <drivetests>:

int
drivetests(int quick, int continuous, char *justone)
{
    503c:	7159                	addi	sp,sp,-112
    503e:	f486                	sd	ra,104(sp)
    5040:	f0a2                	sd	s0,96(sp)
    5042:	eca6                	sd	s1,88(sp)
    5044:	e8ca                	sd	s2,80(sp)
    5046:	e4ce                	sd	s3,72(sp)
    5048:	e0d2                	sd	s4,64(sp)
    504a:	fc56                	sd	s5,56(sp)
    504c:	f85a                	sd	s6,48(sp)
    504e:	f45e                	sd	s7,40(sp)
    5050:	f062                	sd	s8,32(sp)
    5052:	ec66                	sd	s9,24(sp)
    5054:	e86a                	sd	s10,16(sp)
    5056:	e46e                	sd	s11,8(sp)
    5058:	1880                	addi	s0,sp,112
    505a:	8aaa                	mv	s5,a0
    505c:	89ae                	mv	s3,a1
    505e:	8a32                	mv	s4,a2
      printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
      if (continuous != 2) {
        return 1;
      }
    }
    if (justone != 0 && ntests == 0) {
    5060:	00c03cb3          	snez	s9,a2
    printf("usertests starting\n");
    5064:	00003c17          	auipc	s8,0x3
    5068:	dfcc0c13          	addi	s8,s8,-516 # 7e60 <malloc+0x24a8>
    n = runtests(quicktests, justone, continuous);
    506c:	00004b97          	auipc	s7,0x4
    5070:	fa4b8b93          	addi	s7,s7,-92 # 9010 <quicktests>
      if (continuous != 2) {
    5074:	4b09                	li	s6,2
      n = runtests(slowtests, justone, continuous);
    5076:	00004d17          	auipc	s10,0x4
    507a:	3dad0d13          	addi	s10,s10,986 # 9450 <slowtests>
      printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
    507e:	00003d97          	auipc	s11,0x3
    5082:	e1ad8d93          	addi	s11,s11,-486 # 7e98 <malloc+0x24e0>
    5086:	a80d                	j	50b8 <drivetests+0x7c>
      if (continuous != 2) {
    5088:	09699563          	bne	s3,s6,5112 <drivetests+0xd6>
    int ntests = 0;
    508c:	4481                	li	s1,0
    508e:	a099                	j	50d4 <drivetests+0x98>
        printf("usertests slow tests starting\n");
    5090:	00003517          	auipc	a0,0x3
    5094:	de850513          	addi	a0,a0,-536 # 7e78 <malloc+0x24c0>
    5098:	065000ef          	jal	58fc <printf>
    509c:	a081                	j	50dc <drivetests+0xa0>
        if (continuous != 2) {
    509e:	07699a63          	bne	s3,s6,5112 <drivetests+0xd6>
    if ((free1 = countfree()) < free0) {
    50a2:	f4fff0ef          	jal	4ff0 <countfree>
    50a6:	05254463          	blt	a0,s2,50ee <drivetests+0xb2>
    if (justone != 0 && ntests == 0) {
    50aa:	0014b493          	seqz	s1,s1
    50ae:	009cf4b3          	and	s1,s9,s1
    50b2:	e8b1                	bnez	s1,5106 <drivetests+0xca>
      printf("NO TESTS EXECUTED\n");
      return 1;
    }
  } while (continuous);
    50b4:	06098f63          	beqz	s3,5132 <drivetests+0xf6>
    printf("usertests starting\n");
    50b8:	8562                	mv	a0,s8
    50ba:	043000ef          	jal	58fc <printf>
    int free0 = countfree();
    50be:	f33ff0ef          	jal	4ff0 <countfree>
    50c2:	892a                	mv	s2,a0
    n = runtests(quicktests, justone, continuous);
    50c4:	864e                	mv	a2,s3
    50c6:	85d2                	mv	a1,s4
    50c8:	855e                	mv	a0,s7
    50ca:	eb3ff0ef          	jal	4f7c <runtests>
    50ce:	84aa                	mv	s1,a0
    if (n < 0) {
    50d0:	fa054ce3          	bltz	a0,5088 <drivetests+0x4c>
    if (!quick) {
    50d4:	fc0a97e3          	bnez	s5,50a2 <drivetests+0x66>
      if (justone == 0)
    50d8:	fa0a0ce3          	beqz	s4,5090 <drivetests+0x54>
      n = runtests(slowtests, justone, continuous);
    50dc:	864e                	mv	a2,s3
    50de:	85d2                	mv	a1,s4
    50e0:	856a                	mv	a0,s10
    50e2:	e9bff0ef          	jal	4f7c <runtests>
      if (n < 0) {
    50e6:	fa054ce3          	bltz	a0,509e <drivetests+0x62>
        ntests += n;
    50ea:	9ca9                	addw	s1,s1,a0
    50ec:	bf5d                	j	50a2 <drivetests+0x66>
      printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
    50ee:	864a                	mv	a2,s2
    50f0:	85aa                	mv	a1,a0
    50f2:	856e                	mv	a0,s11
    50f4:	009000ef          	jal	58fc <printf>
      if (continuous != 2) {
    50f8:	01699d63          	bne	s3,s6,5112 <drivetests+0xd6>
    if (justone != 0 && ntests == 0) {
    50fc:	0014b493          	seqz	s1,s1
    5100:	009cf4b3          	and	s1,s9,s1
    5104:	d8d5                	beqz	s1,50b8 <drivetests+0x7c>
      printf("NO TESTS EXECUTED\n");
    5106:	00003517          	auipc	a0,0x3
    510a:	dc250513          	addi	a0,a0,-574 # 7ec8 <malloc+0x2510>
    510e:	7ee000ef          	jal	58fc <printf>
        return 1;
    5112:	4505                	li	a0,1
  return 0;
}
    5114:	70a6                	ld	ra,104(sp)
    5116:	7406                	ld	s0,96(sp)
    5118:	64e6                	ld	s1,88(sp)
    511a:	6946                	ld	s2,80(sp)
    511c:	69a6                	ld	s3,72(sp)
    511e:	6a06                	ld	s4,64(sp)
    5120:	7ae2                	ld	s5,56(sp)
    5122:	7b42                	ld	s6,48(sp)
    5124:	7ba2                	ld	s7,40(sp)
    5126:	7c02                	ld	s8,32(sp)
    5128:	6ce2                	ld	s9,24(sp)
    512a:	6d42                	ld	s10,16(sp)
    512c:	6da2                	ld	s11,8(sp)
    512e:	6165                	addi	sp,sp,112
    5130:	8082                	ret
  return 0;
    5132:	854e                	mv	a0,s3
    5134:	b7c5                	j	5114 <drivetests+0xd8>

0000000000005136 <main>:

int
main(int argc, char *argv[])
{
    5136:	1101                	addi	sp,sp,-32
    5138:	ec06                	sd	ra,24(sp)
    513a:	e822                	sd	s0,16(sp)
    513c:	e426                	sd	s1,8(sp)
    513e:	e04a                	sd	s2,0(sp)
    5140:	1000                	addi	s0,sp,32
    5142:	84aa                	mv	s1,a0
  int continuous = 0;
  int quick = 0;
  char *justone = 0;

  if (argc == 2 && strcmp(argv[1], "-q") == 0) {
    5144:	4789                	li	a5,2
    5146:	00f50e63          	beq	a0,a5,5162 <main+0x2c>
    continuous = 1;
  } else if (argc == 2 && strcmp(argv[1], "-C") == 0) {
    continuous = 2;
  } else if (argc == 2 && argv[1][0] != '-') {
    justone = argv[1];
  } else if (argc > 1) {
    514a:	4785                	li	a5,1
    514c:	06a7c663          	blt	a5,a0,51b8 <main+0x82>
  char *justone = 0;
    5150:	4601                	li	a2,0
  int quick = 0;
    5152:	4501                	li	a0,0
  int continuous = 0;
    5154:	4581                	li	a1,0
    printf("Usage: usertests [-c] [-C] [-q] [testname]\n");
    exit(1);
  }
  if (drivetests(quick, continuous, justone)) {
    5156:	ee7ff0ef          	jal	503c <drivetests>
    515a:	cd35                	beqz	a0,51d6 <main+0xa0>
    exit(1);
    515c:	4505                	li	a0,1
    515e:	340000ef          	jal	549e <exit>
    5162:	892e                	mv	s2,a1
  if (argc == 2 && strcmp(argv[1], "-q") == 0) {
    5164:	00003597          	auipc	a1,0x3
    5168:	d7c58593          	addi	a1,a1,-644 # 7ee0 <malloc+0x2528>
    516c:	00893503          	ld	a0,8(s2)
    5170:	0a8000ef          	jal	5218 <strcmp>
    5174:	85aa                	mv	a1,a0
    5176:	e501                	bnez	a0,517e <main+0x48>
  char *justone = 0;
    5178:	4601                	li	a2,0
    quick = 1;
    517a:	4505                	li	a0,1
    517c:	bfe9                	j	5156 <main+0x20>
  } else if (argc == 2 && strcmp(argv[1], "-c") == 0) {
    517e:	00003597          	auipc	a1,0x3
    5182:	d6a58593          	addi	a1,a1,-662 # 7ee8 <malloc+0x2530>
    5186:	00893503          	ld	a0,8(s2)
    518a:	08e000ef          	jal	5218 <strcmp>
    518e:	cd15                	beqz	a0,51ca <main+0x94>
  } else if (argc == 2 && strcmp(argv[1], "-C") == 0) {
    5190:	00003597          	auipc	a1,0x3
    5194:	da858593          	addi	a1,a1,-600 # 7f38 <malloc+0x2580>
    5198:	00893503          	ld	a0,8(s2)
    519c:	07c000ef          	jal	5218 <strcmp>
    51a0:	c905                	beqz	a0,51d0 <main+0x9a>
  } else if (argc == 2 && argv[1][0] != '-') {
    51a2:	00893603          	ld	a2,8(s2)
    51a6:	00064703          	lbu	a4,0(a2)
    51aa:	02d00793          	li	a5,45
    51ae:	00f70563          	beq	a4,a5,51b8 <main+0x82>
  int quick = 0;
    51b2:	4501                	li	a0,0
  int continuous = 0;
    51b4:	4581                	li	a1,0
    51b6:	b745                	j	5156 <main+0x20>
    printf("Usage: usertests [-c] [-C] [-q] [testname]\n");
    51b8:	00003517          	auipc	a0,0x3
    51bc:	d3850513          	addi	a0,a0,-712 # 7ef0 <malloc+0x2538>
    51c0:	73c000ef          	jal	58fc <printf>
    exit(1);
    51c4:	4505                	li	a0,1
    51c6:	2d8000ef          	jal	549e <exit>
  char *justone = 0;
    51ca:	4601                	li	a2,0
    continuous = 1;
    51cc:	4585                	li	a1,1
    51ce:	b761                	j	5156 <main+0x20>
    continuous = 2;
    51d0:	85a6                	mv	a1,s1
  char *justone = 0;
    51d2:	4601                	li	a2,0
    51d4:	b749                	j	5156 <main+0x20>
  }
  printf("ALL TESTS PASSED\n");
    51d6:	00003517          	auipc	a0,0x3
    51da:	d4a50513          	addi	a0,a0,-694 # 7f20 <malloc+0x2568>
    51de:	71e000ef          	jal	58fc <printf>
  exit(0);
    51e2:	4501                	li	a0,0
    51e4:	2ba000ef          	jal	549e <exit>

00000000000051e8 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
    51e8:	1141                	addi	sp,sp,-16
    51ea:	e406                	sd	ra,8(sp)
    51ec:	e022                	sd	s0,0(sp)
    51ee:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
    51f0:	f47ff0ef          	jal	5136 <main>
  exit(r);
    51f4:	2aa000ef          	jal	549e <exit>

00000000000051f8 <strcpy>:
}

char *
strcpy(char *s, const char *t)
{
    51f8:	1141                	addi	sp,sp,-16
    51fa:	e406                	sd	ra,8(sp)
    51fc:	e022                	sd	s0,0(sp)
    51fe:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while ((*s++ = *t++) != 0)
    5200:	87aa                	mv	a5,a0
    5202:	0585                	addi	a1,a1,1
    5204:	0785                	addi	a5,a5,1
    5206:	fff5c703          	lbu	a4,-1(a1)
    520a:	fee78fa3          	sb	a4,-1(a5)
    520e:	fb75                	bnez	a4,5202 <strcpy+0xa>
    ;
  return os;
}
    5210:	60a2                	ld	ra,8(sp)
    5212:	6402                	ld	s0,0(sp)
    5214:	0141                	addi	sp,sp,16
    5216:	8082                	ret

0000000000005218 <strcmp>:

int
strcmp(const char *p, const char *q)
{
    5218:	1141                	addi	sp,sp,-16
    521a:	e406                	sd	ra,8(sp)
    521c:	e022                	sd	s0,0(sp)
    521e:	0800                	addi	s0,sp,16
  while (*p && *p == *q)
    5220:	00054783          	lbu	a5,0(a0)
    5224:	cb91                	beqz	a5,5238 <strcmp+0x20>
    5226:	0005c703          	lbu	a4,0(a1)
    522a:	00f71763          	bne	a4,a5,5238 <strcmp+0x20>
    p++, q++;
    522e:	0505                	addi	a0,a0,1
    5230:	0585                	addi	a1,a1,1
  while (*p && *p == *q)
    5232:	00054783          	lbu	a5,0(a0)
    5236:	fbe5                	bnez	a5,5226 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
    5238:	0005c503          	lbu	a0,0(a1)
}
    523c:	40a7853b          	subw	a0,a5,a0
    5240:	60a2                	ld	ra,8(sp)
    5242:	6402                	ld	s0,0(sp)
    5244:	0141                	addi	sp,sp,16
    5246:	8082                	ret

0000000000005248 <strlen>:

uint
strlen(const char *s)
{
    5248:	1141                	addi	sp,sp,-16
    524a:	e406                	sd	ra,8(sp)
    524c:	e022                	sd	s0,0(sp)
    524e:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
    5250:	00054783          	lbu	a5,0(a0)
    5254:	cf91                	beqz	a5,5270 <strlen+0x28>
    5256:	00150793          	addi	a5,a0,1
    525a:	86be                	mv	a3,a5
    525c:	0785                	addi	a5,a5,1
    525e:	fff7c703          	lbu	a4,-1(a5)
    5262:	ff65                	bnez	a4,525a <strlen+0x12>
    5264:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    5268:	60a2                	ld	ra,8(sp)
    526a:	6402                	ld	s0,0(sp)
    526c:	0141                	addi	sp,sp,16
    526e:	8082                	ret
  for (n = 0; s[n]; n++)
    5270:	4501                	li	a0,0
    5272:	bfdd                	j	5268 <strlen+0x20>

0000000000005274 <memset>:

void *
memset(void *dst, int c, uint n)
{
    5274:	1141                	addi	sp,sp,-16
    5276:	e406                	sd	ra,8(sp)
    5278:	e022                	sd	s0,0(sp)
    527a:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
    527c:	ca19                	beqz	a2,5292 <memset+0x1e>
    527e:	87aa                	mv	a5,a0
    5280:	1602                	slli	a2,a2,0x20
    5282:	9201                	srli	a2,a2,0x20
    5284:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    5288:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
    528c:	0785                	addi	a5,a5,1
    528e:	fee79de3          	bne	a5,a4,5288 <memset+0x14>
  }
  return dst;
}
    5292:	60a2                	ld	ra,8(sp)
    5294:	6402                	ld	s0,0(sp)
    5296:	0141                	addi	sp,sp,16
    5298:	8082                	ret

000000000000529a <strchr>:

char *
strchr(const char *s, char c)
{
    529a:	1141                	addi	sp,sp,-16
    529c:	e406                	sd	ra,8(sp)
    529e:	e022                	sd	s0,0(sp)
    52a0:	0800                	addi	s0,sp,16
  for (; *s; s++)
    52a2:	00054783          	lbu	a5,0(a0)
    52a6:	c799                	beqz	a5,52b4 <strchr+0x1a>
    if (*s == c)
    52a8:	00f58763          	beq	a1,a5,52b6 <strchr+0x1c>
  for (; *s; s++)
    52ac:	0505                	addi	a0,a0,1
    52ae:	00054783          	lbu	a5,0(a0)
    52b2:	fbfd                	bnez	a5,52a8 <strchr+0xe>
      return (char *)s;
  return 0;
    52b4:	4501                	li	a0,0
}
    52b6:	60a2                	ld	ra,8(sp)
    52b8:	6402                	ld	s0,0(sp)
    52ba:	0141                	addi	sp,sp,16
    52bc:	8082                	ret

00000000000052be <gets>:

char *
gets(char *buf, int max)
{
    52be:	711d                	addi	sp,sp,-96
    52c0:	ec86                	sd	ra,88(sp)
    52c2:	e8a2                	sd	s0,80(sp)
    52c4:	e4a6                	sd	s1,72(sp)
    52c6:	e0ca                	sd	s2,64(sp)
    52c8:	fc4e                	sd	s3,56(sp)
    52ca:	f852                	sd	s4,48(sp)
    52cc:	f456                	sd	s5,40(sp)
    52ce:	f05a                	sd	s6,32(sp)
    52d0:	ec5e                	sd	s7,24(sp)
    52d2:	e862                	sd	s8,16(sp)
    52d4:	1080                	addi	s0,sp,96
    52d6:	8baa                	mv	s7,a0
    52d8:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for (i = 0; i + 1 < max;) {
    52da:	892a                	mv	s2,a0
    52dc:	4481                	li	s1,0
    cc = read(0, &c, 1);
    52de:	faf40b13          	addi	s6,s0,-81
    52e2:	4a85                	li	s5,1
  for (i = 0; i + 1 < max;) {
    52e4:	8c26                	mv	s8,s1
    52e6:	0014899b          	addiw	s3,s1,1
    52ea:	84ce                	mv	s1,s3
    52ec:	0349d863          	bge	s3,s4,531c <gets+0x5e>
    cc = read(0, &c, 1);
    52f0:	8656                	mv	a2,s5
    52f2:	85da                	mv	a1,s6
    52f4:	4501                	li	a0,0
    52f6:	1c0000ef          	jal	54b6 <read>
    if (cc < 1)
    52fa:	02a05163          	blez	a0,531c <gets+0x5e>
      break;
    buf[i++] = c;
    52fe:	faf44783          	lbu	a5,-81(s0)
    5302:	00f90023          	sb	a5,0(s2)
    if (c == '\n' || c == '\r')
    5306:	0905                	addi	s2,s2,1
    5308:	ff678713          	addi	a4,a5,-10
    530c:	00173713          	seqz	a4,a4
    5310:	17cd                	addi	a5,a5,-13
    5312:	0017b793          	seqz	a5,a5
    5316:	8fd9                	or	a5,a5,a4
    5318:	d7f1                	beqz	a5,52e4 <gets+0x26>
    buf[i++] = c;
    531a:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
    531c:	9c5e                	add	s8,s8,s7
    531e:	000c0023          	sb	zero,0(s8)
  return buf;
}
    5322:	855e                	mv	a0,s7
    5324:	60e6                	ld	ra,88(sp)
    5326:	6446                	ld	s0,80(sp)
    5328:	64a6                	ld	s1,72(sp)
    532a:	6906                	ld	s2,64(sp)
    532c:	79e2                	ld	s3,56(sp)
    532e:	7a42                	ld	s4,48(sp)
    5330:	7aa2                	ld	s5,40(sp)
    5332:	7b02                	ld	s6,32(sp)
    5334:	6be2                	ld	s7,24(sp)
    5336:	6c42                	ld	s8,16(sp)
    5338:	6125                	addi	sp,sp,96
    533a:	8082                	ret

000000000000533c <stat>:

int
stat(const char *n, struct stat *st)
{
    533c:	1101                	addi	sp,sp,-32
    533e:	ec06                	sd	ra,24(sp)
    5340:	e822                	sd	s0,16(sp)
    5342:	e04a                	sd	s2,0(sp)
    5344:	1000                	addi	s0,sp,32
    5346:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
    5348:	4581                	li	a1,0
    534a:	194000ef          	jal	54de <open>
  if (fd < 0)
    534e:	02054263          	bltz	a0,5372 <stat+0x36>
    5352:	e426                	sd	s1,8(sp)
    5354:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
    5356:	85ca                	mv	a1,s2
    5358:	19e000ef          	jal	54f6 <fstat>
    535c:	892a                	mv	s2,a0
  close(fd);
    535e:	8526                	mv	a0,s1
    5360:	166000ef          	jal	54c6 <close>
  return r;
    5364:	64a2                	ld	s1,8(sp)
}
    5366:	854a                	mv	a0,s2
    5368:	60e2                	ld	ra,24(sp)
    536a:	6442                	ld	s0,16(sp)
    536c:	6902                	ld	s2,0(sp)
    536e:	6105                	addi	sp,sp,32
    5370:	8082                	ret
    return -1;
    5372:	57fd                	li	a5,-1
    5374:	893e                	mv	s2,a5
    5376:	bfc5                	j	5366 <stat+0x2a>

0000000000005378 <atoi>:

int
atoi(const char *s)
{
    5378:	1141                	addi	sp,sp,-16
    537a:	e406                	sd	ra,8(sp)
    537c:	e022                	sd	s0,0(sp)
    537e:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while ('0' <= *s && *s <= '9')
    5380:	00054683          	lbu	a3,0(a0)
    5384:	fd06879b          	addiw	a5,a3,-48 # 3ffd0 <base+0x302e8>
    5388:	0ff7f793          	zext.b	a5,a5
    538c:	4625                	li	a2,9
    538e:	02f66963          	bltu	a2,a5,53c0 <atoi+0x48>
    5392:	872a                	mv	a4,a0
  n = 0;
    5394:	4501                	li	a0,0
    n = n * 10 + *s++ - '0';
    5396:	0705                	addi	a4,a4,1 # 1000001 <base+0xff0319>
    5398:	0025179b          	slliw	a5,a0,0x2
    539c:	9fa9                	addw	a5,a5,a0
    539e:	0017979b          	slliw	a5,a5,0x1
    53a2:	9fb5                	addw	a5,a5,a3
    53a4:	fd07851b          	addiw	a0,a5,-48
  while ('0' <= *s && *s <= '9')
    53a8:	00074683          	lbu	a3,0(a4)
    53ac:	fd06879b          	addiw	a5,a3,-48
    53b0:	0ff7f793          	zext.b	a5,a5
    53b4:	fef671e3          	bgeu	a2,a5,5396 <atoi+0x1e>
  return n;
}
    53b8:	60a2                	ld	ra,8(sp)
    53ba:	6402                	ld	s0,0(sp)
    53bc:	0141                	addi	sp,sp,16
    53be:	8082                	ret
  n = 0;
    53c0:	4501                	li	a0,0
    53c2:	bfdd                	j	53b8 <atoi+0x40>

00000000000053c4 <memmove>:

void *
memmove(void *vdst, const void *vsrc, int n)
{
    53c4:	1141                	addi	sp,sp,-16
    53c6:	e406                	sd	ra,8(sp)
    53c8:	e022                	sd	s0,0(sp)
    53ca:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
    53cc:	02b57563          	bgeu	a0,a1,53f6 <memmove+0x32>
    while (n-- > 0)
    53d0:	00c05f63          	blez	a2,53ee <memmove+0x2a>
    53d4:	1602                	slli	a2,a2,0x20
    53d6:	9201                	srli	a2,a2,0x20
    53d8:	00c507b3          	add	a5,a0,a2
  dst = vdst;
    53dc:	872a                	mv	a4,a0
      *dst++ = *src++;
    53de:	0585                	addi	a1,a1,1
    53e0:	0705                	addi	a4,a4,1
    53e2:	fff5c683          	lbu	a3,-1(a1)
    53e6:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
    53ea:	fee79ae3          	bne	a5,a4,53de <memmove+0x1a>
    src += n;
    while (n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
    53ee:	60a2                	ld	ra,8(sp)
    53f0:	6402                	ld	s0,0(sp)
    53f2:	0141                	addi	sp,sp,16
    53f4:	8082                	ret
    while (n-- > 0)
    53f6:	fec05ce3          	blez	a2,53ee <memmove+0x2a>
    dst += n;
    53fa:	00c50733          	add	a4,a0,a2
    src += n;
    53fe:	95b2                	add	a1,a1,a2
    5400:	fff6079b          	addiw	a5,a2,-1
    5404:	1782                	slli	a5,a5,0x20
    5406:	9381                	srli	a5,a5,0x20
    5408:	fff7c793          	not	a5,a5
    540c:	97ba                	add	a5,a5,a4
      *--dst = *--src;
    540e:	15fd                	addi	a1,a1,-1
    5410:	177d                	addi	a4,a4,-1
    5412:	0005c683          	lbu	a3,0(a1)
    5416:	00d70023          	sb	a3,0(a4)
    while (n-- > 0)
    541a:	fef71ae3          	bne	a4,a5,540e <memmove+0x4a>
    541e:	bfc1                	j	53ee <memmove+0x2a>

0000000000005420 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
    5420:	1141                	addi	sp,sp,-16
    5422:	e406                	sd	ra,8(sp)
    5424:	e022                	sd	s0,0(sp)
    5426:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
    5428:	ce19                	beqz	a2,5446 <memcmp+0x26>
    542a:	1602                	slli	a2,a2,0x20
    542c:	9201                	srli	a2,a2,0x20
    542e:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
    5432:	00054783          	lbu	a5,0(a0)
    5436:	0005c703          	lbu	a4,0(a1)
    543a:	00e79b63          	bne	a5,a4,5450 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
    543e:	0505                	addi	a0,a0,1
    p2++;
    5440:	0585                	addi	a1,a1,1
  while (n-- > 0) {
    5442:	fed518e3          	bne	a0,a3,5432 <memcmp+0x12>
  }
  return 0;
    5446:	4501                	li	a0,0
}
    5448:	60a2                	ld	ra,8(sp)
    544a:	6402                	ld	s0,0(sp)
    544c:	0141                	addi	sp,sp,16
    544e:	8082                	ret
      return *p1 - *p2;
    5450:	40e7853b          	subw	a0,a5,a4
    5454:	bfd5                	j	5448 <memcmp+0x28>

0000000000005456 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
    5456:	1141                	addi	sp,sp,-16
    5458:	e406                	sd	ra,8(sp)
    545a:	e022                	sd	s0,0(sp)
    545c:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    545e:	f67ff0ef          	jal	53c4 <memmove>
}
    5462:	60a2                	ld	ra,8(sp)
    5464:	6402                	ld	s0,0(sp)
    5466:	0141                	addi	sp,sp,16
    5468:	8082                	ret

000000000000546a <sbrk>:

char *
sbrk(int n)
{
    546a:	1141                	addi	sp,sp,-16
    546c:	e406                	sd	ra,8(sp)
    546e:	e022                	sd	s0,0(sp)
    5470:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
    5472:	4585                	li	a1,1
    5474:	0b2000ef          	jal	5526 <sys_sbrk>
}
    5478:	60a2                	ld	ra,8(sp)
    547a:	6402                	ld	s0,0(sp)
    547c:	0141                	addi	sp,sp,16
    547e:	8082                	ret

0000000000005480 <sbrklazy>:

char *
sbrklazy(int n)
{
    5480:	1141                	addi	sp,sp,-16
    5482:	e406                	sd	ra,8(sp)
    5484:	e022                	sd	s0,0(sp)
    5486:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
    5488:	4589                	li	a1,2
    548a:	09c000ef          	jal	5526 <sys_sbrk>
}
    548e:	60a2                	ld	ra,8(sp)
    5490:	6402                	ld	s0,0(sp)
    5492:	0141                	addi	sp,sp,16
    5494:	8082                	ret

0000000000005496 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
    5496:	4885                	li	a7,1
 ecall
    5498:	00000073          	ecall
 ret
    549c:	8082                	ret

000000000000549e <exit>:
.global exit
exit:
 li a7, SYS_exit
    549e:	4889                	li	a7,2
 ecall
    54a0:	00000073          	ecall
 ret
    54a4:	8082                	ret

00000000000054a6 <wait>:
.global wait
wait:
 li a7, SYS_wait
    54a6:	488d                	li	a7,3
 ecall
    54a8:	00000073          	ecall
 ret
    54ac:	8082                	ret

00000000000054ae <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
    54ae:	4891                	li	a7,4
 ecall
    54b0:	00000073          	ecall
 ret
    54b4:	8082                	ret

00000000000054b6 <read>:
.global read
read:
 li a7, SYS_read
    54b6:	4895                	li	a7,5
 ecall
    54b8:	00000073          	ecall
 ret
    54bc:	8082                	ret

00000000000054be <write>:
.global write
write:
 li a7, SYS_write
    54be:	48c1                	li	a7,16
 ecall
    54c0:	00000073          	ecall
 ret
    54c4:	8082                	ret

00000000000054c6 <close>:
.global close
close:
 li a7, SYS_close
    54c6:	48d5                	li	a7,21
 ecall
    54c8:	00000073          	ecall
 ret
    54cc:	8082                	ret

00000000000054ce <kill>:
.global kill
kill:
 li a7, SYS_kill
    54ce:	4899                	li	a7,6
 ecall
    54d0:	00000073          	ecall
 ret
    54d4:	8082                	ret

00000000000054d6 <exec>:
.global exec
exec:
 li a7, SYS_exec
    54d6:	489d                	li	a7,7
 ecall
    54d8:	00000073          	ecall
 ret
    54dc:	8082                	ret

00000000000054de <open>:
.global open
open:
 li a7, SYS_open
    54de:	48bd                	li	a7,15
 ecall
    54e0:	00000073          	ecall
 ret
    54e4:	8082                	ret

00000000000054e6 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
    54e6:	48c5                	li	a7,17
 ecall
    54e8:	00000073          	ecall
 ret
    54ec:	8082                	ret

00000000000054ee <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
    54ee:	48c9                	li	a7,18
 ecall
    54f0:	00000073          	ecall
 ret
    54f4:	8082                	ret

00000000000054f6 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
    54f6:	48a1                	li	a7,8
 ecall
    54f8:	00000073          	ecall
 ret
    54fc:	8082                	ret

00000000000054fe <link>:
.global link
link:
 li a7, SYS_link
    54fe:	48cd                	li	a7,19
 ecall
    5500:	00000073          	ecall
 ret
    5504:	8082                	ret

0000000000005506 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
    5506:	48d1                	li	a7,20
 ecall
    5508:	00000073          	ecall
 ret
    550c:	8082                	ret

000000000000550e <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
    550e:	48a5                	li	a7,9
 ecall
    5510:	00000073          	ecall
 ret
    5514:	8082                	ret

0000000000005516 <dup>:
.global dup
dup:
 li a7, SYS_dup
    5516:	48a9                	li	a7,10
 ecall
    5518:	00000073          	ecall
 ret
    551c:	8082                	ret

000000000000551e <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
    551e:	48ad                	li	a7,11
 ecall
    5520:	00000073          	ecall
 ret
    5524:	8082                	ret

0000000000005526 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
    5526:	48b1                	li	a7,12
 ecall
    5528:	00000073          	ecall
 ret
    552c:	8082                	ret

000000000000552e <pause>:
.global pause
pause:
 li a7, SYS_pause
    552e:	48b5                	li	a7,13
 ecall
    5530:	00000073          	ecall
 ret
    5534:	8082                	ret

0000000000005536 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
    5536:	48b9                	li	a7,14
 ecall
    5538:	00000073          	ecall
 ret
    553c:	8082                	ret

000000000000553e <sync>:
.global sync
sync:
 li a7, SYS_sync
    553e:	48d9                	li	a7,22
 ecall
    5540:	00000073          	ecall
 ret
    5544:	8082                	ret

0000000000005546 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
    5546:	1101                	addi	sp,sp,-32
    5548:	ec06                	sd	ra,24(sp)
    554a:	e822                	sd	s0,16(sp)
    554c:	1000                	addi	s0,sp,32
    554e:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
    5552:	4605                	li	a2,1
    5554:	fef40593          	addi	a1,s0,-17
    5558:	f67ff0ef          	jal	54be <write>
}
    555c:	60e2                	ld	ra,24(sp)
    555e:	6442                	ld	s0,16(sp)
    5560:	6105                	addi	sp,sp,32
    5562:	8082                	ret

0000000000005564 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
    5564:	715d                	addi	sp,sp,-80
    5566:	e486                	sd	ra,72(sp)
    5568:	e0a2                	sd	s0,64(sp)
    556a:	f84a                	sd	s2,48(sp)
    556c:	f44e                	sd	s3,40(sp)
    556e:	0880                	addi	s0,sp,80
    5570:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if (sgn && xx < 0) {
    5572:	00d036b3          	snez	a3,a3
    5576:	03f5d793          	srli	a5,a1,0x3f
    557a:	8efd                	and	a3,a3,a5
  neg = 0;
    557c:	4301                	li	t1,0
  if (sgn && xx < 0) {
    557e:	c681                	beqz	a3,5586 <printint+0x22>
    neg = 1;
    x = -xx;
    5580:	40b005b3          	neg	a1,a1
    neg = 1;
    5584:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
    5586:	fb840993          	addi	s3,s0,-72
  neg = 0;
    558a:	86ce                	mv	a3,s3
  i = 0;
    558c:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    558e:	00003817          	auipc	a6,0x3
    5592:	e0280813          	addi	a6,a6,-510 # 8390 <digits>
    5596:	88ba                	mv	a7,a4
    5598:	0017051b          	addiw	a0,a4,1
    559c:	872a                	mv	a4,a0
    559e:	02c5f7b3          	remu	a5,a1,a2
    55a2:	97c2                	add	a5,a5,a6
    55a4:	0007c783          	lbu	a5,0(a5)
    55a8:	00f68023          	sb	a5,0(a3)
  } while ((x /= base) != 0);
    55ac:	87ae                	mv	a5,a1
    55ae:	02c5d5b3          	divu	a1,a1,a2
    55b2:	0685                	addi	a3,a3,1
    55b4:	fec7f1e3          	bgeu	a5,a2,5596 <printint+0x32>
  if (neg)
    55b8:	00030b63          	beqz	t1,55ce <printint+0x6a>
    buf[i++] = '-';
    55bc:	fd040793          	addi	a5,s0,-48
    55c0:	953e                	add	a0,a0,a5
    55c2:	02d00793          	li	a5,45
    55c6:	fef50423          	sb	a5,-24(a0)
    55ca:	0028871b          	addiw	a4,a7,2

  while (--i >= 0)
    55ce:	02e05563          	blez	a4,55f8 <printint+0x94>
    55d2:	fc26                	sd	s1,56(sp)
    55d4:	377d                	addiw	a4,a4,-1
    55d6:	00e984b3          	add	s1,s3,a4
    55da:	19fd                	addi	s3,s3,-1 # fff <bigdir+0x10b>
    55dc:	99ba                	add	s3,s3,a4
    55de:	1702                	slli	a4,a4,0x20
    55e0:	9301                	srli	a4,a4,0x20
    55e2:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
    55e6:	0004c583          	lbu	a1,0(s1)
    55ea:	854a                	mv	a0,s2
    55ec:	f5bff0ef          	jal	5546 <putc>
  while (--i >= 0)
    55f0:	14fd                	addi	s1,s1,-1
    55f2:	ff349ae3          	bne	s1,s3,55e6 <printint+0x82>
    55f6:	74e2                	ld	s1,56(sp)
}
    55f8:	60a6                	ld	ra,72(sp)
    55fa:	6406                	ld	s0,64(sp)
    55fc:	7942                	ld	s2,48(sp)
    55fe:	79a2                	ld	s3,40(sp)
    5600:	6161                	addi	sp,sp,80
    5602:	8082                	ret

0000000000005604 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
    5604:	711d                	addi	sp,sp,-96
    5606:	ec86                	sd	ra,88(sp)
    5608:	e8a2                	sd	s0,80(sp)
    560a:	e4a6                	sd	s1,72(sp)
    560c:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for (i = 0; fmt[i]; i++) {
    560e:	0005c483          	lbu	s1,0(a1)
    5612:	2a048063          	beqz	s1,58b2 <vprintf+0x2ae>
    5616:	e0ca                	sd	s2,64(sp)
    5618:	fc4e                	sd	s3,56(sp)
    561a:	f852                	sd	s4,48(sp)
    561c:	f456                	sd	s5,40(sp)
    561e:	f05a                	sd	s6,32(sp)
    5620:	ec5e                	sd	s7,24(sp)
    5622:	e862                	sd	s8,16(sp)
    5624:	8b2a                	mv	s6,a0
    5626:	8a2e                	mv	s4,a1
    5628:	8bb2                	mv	s7,a2
  state = 0;
    562a:	4981                	li	s3,0
  for (i = 0; fmt[i]; i++) {
    562c:	4901                	li	s2,0
    562e:	4701                	li	a4,0
      if (c0 == '%') {
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if (state == '%') {
    5630:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if (c0)
        c1 = fmt[i + 1] & 0xff;
      if (c1)
        c2 = fmt[i + 2] & 0xff;
      if (c0 == 'd') {
    5634:	06400c13          	li	s8,100
    5638:	a00d                	j	565a <vprintf+0x56>
        putc(fd, c0);
    563a:	85a6                	mv	a1,s1
    563c:	855a                	mv	a0,s6
    563e:	f09ff0ef          	jal	5546 <putc>
    5642:	a019                	j	5648 <vprintf+0x44>
    } else if (state == '%') {
    5644:	03598363          	beq	s3,s5,566a <vprintf+0x66>
  for (i = 0; fmt[i]; i++) {
    5648:	0019079b          	addiw	a5,s2,1
    564c:	893e                	mv	s2,a5
    564e:	873e                	mv	a4,a5
    5650:	97d2                	add	a5,a5,s4
    5652:	0007c483          	lbu	s1,0(a5)
    5656:	24048763          	beqz	s1,58a4 <vprintf+0x2a0>
    c0 = fmt[i] & 0xff;
    565a:	0004879b          	sext.w	a5,s1
    if (state == 0) {
    565e:	fe0993e3          	bnez	s3,5644 <vprintf+0x40>
      if (c0 == '%') {
    5662:	fd579ce3          	bne	a5,s5,563a <vprintf+0x36>
        state = '%';
    5666:	89be                	mv	s3,a5
    5668:	b7c5                	j	5648 <vprintf+0x44>
        c1 = fmt[i + 1] & 0xff;
    566a:	00ea06b3          	add	a3,s4,a4
    566e:	0016c603          	lbu	a2,1(a3)
      if (c1)
    5672:	24060563          	beqz	a2,58bc <vprintf+0x2b8>
      if (c0 == 'd') {
    5676:	0b878763          	beq	a5,s8,5724 <vprintf+0x120>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if (c0 == 'l' && c1 == 'd') {
    567a:	f9478693          	addi	a3,a5,-108
    567e:	0016b693          	seqz	a3,a3
    5682:	f9c60593          	addi	a1,a2,-100
    5686:	0015b593          	seqz	a1,a1
    568a:	8df5                	and	a1,a1,a3
    568c:	e9c5                	bnez	a1,573c <vprintf+0x138>
        c2 = fmt[i + 2] & 0xff;
    568e:	9752                	add	a4,a4,s4
    5690:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    5694:	f9460713          	addi	a4,a2,-108
    5698:	00173713          	seqz	a4,a4
    569c:	8f75                	and	a4,a4,a3
    569e:	f9c50593          	addi	a1,a0,-100
    56a2:	0015b593          	seqz	a1,a1
    56a6:	8df9                	and	a1,a1,a4
    56a8:	e5dd                	bnez	a1,5756 <vprintf+0x152>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if (c0 == 'u') {
    56aa:	07500593          	li	a1,117
    56ae:	0cb78163          	beq	a5,a1,5770 <vprintf+0x16c>
        printint(fd, va_arg(ap, uint32), 10, 0);
      } else if (c0 == 'l' && c1 == 'u') {
    56b2:	f8b60593          	addi	a1,a2,-117
    56b6:	0015b593          	seqz	a1,a1
    56ba:	8df5                	and	a1,a1,a3
    56bc:	e5f1                	bnez	a1,5788 <vprintf+0x184>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
    56be:	f8b50593          	addi	a1,a0,-117
    56c2:	0015b593          	seqz	a1,a1
    56c6:	8df9                	and	a1,a1,a4
    56c8:	ede9                	bnez	a1,57a2 <vprintf+0x19e>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if (c0 == 'x') {
    56ca:	07800593          	li	a1,120
    56ce:	0eb78763          	beq	a5,a1,57bc <vprintf+0x1b8>
        printint(fd, va_arg(ap, uint32), 16, 0);
      } else if (c0 == 'l' && c1 == 'x') {
    56d2:	f8860613          	addi	a2,a2,-120
    56d6:	00163613          	seqz	a2,a2
    56da:	8ef1                	and	a3,a3,a2
    56dc:	0e069c63          	bnez	a3,57d4 <vprintf+0x1d0>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
    56e0:	f8850513          	addi	a0,a0,-120
    56e4:	00153513          	seqz	a0,a0
    56e8:	8f69                	and	a4,a4,a0
    56ea:	10071263          	bnez	a4,57ee <vprintf+0x1ea>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if (c0 == 'p') {
    56ee:	07000713          	li	a4,112
    56f2:	10e78a63          	beq	a5,a4,5806 <vprintf+0x202>
        printptr(fd, va_arg(ap, uint64));
      } else if (c0 == 'c') {
    56f6:	06300713          	li	a4,99
    56fa:	14e78a63          	beq	a5,a4,584e <vprintf+0x24a>
        putc(fd, va_arg(ap, uint32));
      } else if (c0 == 's') {
    56fe:	07300713          	li	a4,115
    5702:	16e78063          	beq	a5,a4,5862 <vprintf+0x25e>
        if ((s = va_arg(ap, char *)) == 0)
          s = "(null)";
        for (; *s; s++)
          putc(fd, *s);
      } else if (c0 == '%') {
    5706:	02500713          	li	a4,37
    570a:	18e78863          	beq	a5,a4,589a <vprintf+0x296>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
    570e:	02500593          	li	a1,37
    5712:	855a                	mv	a0,s6
    5714:	e33ff0ef          	jal	5546 <putc>
        putc(fd, c0);
    5718:	85a6                	mv	a1,s1
    571a:	855a                	mv	a0,s6
    571c:	e2bff0ef          	jal	5546 <putc>
      }

      state = 0;
    5720:	4981                	li	s3,0
    5722:	b71d                	j	5648 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
    5724:	008b8493          	addi	s1,s7,8
    5728:	4685                	li	a3,1
    572a:	4629                	li	a2,10
    572c:	000ba583          	lw	a1,0(s7)
    5730:	855a                	mv	a0,s6
    5732:	e33ff0ef          	jal	5564 <printint>
    5736:	8ba6                	mv	s7,s1
      state = 0;
    5738:	4981                	li	s3,0
    573a:	b739                	j	5648 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
    573c:	008b8493          	addi	s1,s7,8
    5740:	4685                	li	a3,1
    5742:	4629                	li	a2,10
    5744:	000bb583          	ld	a1,0(s7)
    5748:	855a                	mv	a0,s6
    574a:	e1bff0ef          	jal	5564 <printint>
        i += 1;
    574e:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
    5750:	8ba6                	mv	s7,s1
      state = 0;
    5752:	4981                	li	s3,0
    5754:	bdd5                	j	5648 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
    5756:	008b8493          	addi	s1,s7,8
    575a:	4685                	li	a3,1
    575c:	4629                	li	a2,10
    575e:	000bb583          	ld	a1,0(s7)
    5762:	855a                	mv	a0,s6
    5764:	e01ff0ef          	jal	5564 <printint>
        i += 2;
    5768:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
    576a:	8ba6                	mv	s7,s1
      state = 0;
    576c:	4981                	li	s3,0
        i += 2;
    576e:	bde9                	j	5648 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
    5770:	008b8493          	addi	s1,s7,8
    5774:	4681                	li	a3,0
    5776:	4629                	li	a2,10
    5778:	000be583          	lwu	a1,0(s7)
    577c:	855a                	mv	a0,s6
    577e:	de7ff0ef          	jal	5564 <printint>
    5782:	8ba6                	mv	s7,s1
      state = 0;
    5784:	4981                	li	s3,0
    5786:	b5c9                	j	5648 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
    5788:	008b8493          	addi	s1,s7,8
    578c:	4681                	li	a3,0
    578e:	4629                	li	a2,10
    5790:	000bb583          	ld	a1,0(s7)
    5794:	855a                	mv	a0,s6
    5796:	dcfff0ef          	jal	5564 <printint>
        i += 1;
    579a:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
    579c:	8ba6                	mv	s7,s1
      state = 0;
    579e:	4981                	li	s3,0
    57a0:	b565                	j	5648 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
    57a2:	008b8493          	addi	s1,s7,8
    57a6:	4681                	li	a3,0
    57a8:	4629                	li	a2,10
    57aa:	000bb583          	ld	a1,0(s7)
    57ae:	855a                	mv	a0,s6
    57b0:	db5ff0ef          	jal	5564 <printint>
        i += 2;
    57b4:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
    57b6:	8ba6                	mv	s7,s1
      state = 0;
    57b8:	4981                	li	s3,0
        i += 2;
    57ba:	b579                	j	5648 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
    57bc:	008b8493          	addi	s1,s7,8
    57c0:	4681                	li	a3,0
    57c2:	4641                	li	a2,16
    57c4:	000be583          	lwu	a1,0(s7)
    57c8:	855a                	mv	a0,s6
    57ca:	d9bff0ef          	jal	5564 <printint>
    57ce:	8ba6                	mv	s7,s1
      state = 0;
    57d0:	4981                	li	s3,0
    57d2:	bd9d                	j	5648 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
    57d4:	008b8493          	addi	s1,s7,8
    57d8:	4681                	li	a3,0
    57da:	4641                	li	a2,16
    57dc:	000bb583          	ld	a1,0(s7)
    57e0:	855a                	mv	a0,s6
    57e2:	d83ff0ef          	jal	5564 <printint>
        i += 1;
    57e6:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
    57e8:	8ba6                	mv	s7,s1
      state = 0;
    57ea:	4981                	li	s3,0
    57ec:	bdb1                	j	5648 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
    57ee:	008b8493          	addi	s1,s7,8
    57f2:	4641                	li	a2,16
    57f4:	000bb583          	ld	a1,0(s7)
    57f8:	855a                	mv	a0,s6
    57fa:	d6bff0ef          	jal	5564 <printint>
        i += 2;
    57fe:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
    5800:	8ba6                	mv	s7,s1
      state = 0;
    5802:	4981                	li	s3,0
        i += 2;
    5804:	b591                	j	5648 <vprintf+0x44>
    5806:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
    5808:	008b8793          	addi	a5,s7,8
    580c:	8cbe                	mv	s9,a5
    580e:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
    5812:	03000593          	li	a1,48
    5816:	855a                	mv	a0,s6
    5818:	d2fff0ef          	jal	5546 <putc>
  putc(fd, 'x');
    581c:	07800593          	li	a1,120
    5820:	855a                	mv	a0,s6
    5822:	d25ff0ef          	jal	5546 <putc>
    5826:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    5828:	00003b97          	auipc	s7,0x3
    582c:	b68b8b93          	addi	s7,s7,-1176 # 8390 <digits>
    5830:	03c9d793          	srli	a5,s3,0x3c
    5834:	97de                	add	a5,a5,s7
    5836:	0007c583          	lbu	a1,0(a5)
    583a:	855a                	mv	a0,s6
    583c:	d0bff0ef          	jal	5546 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    5840:	0992                	slli	s3,s3,0x4
    5842:	34fd                	addiw	s1,s1,-1
    5844:	f4f5                	bnez	s1,5830 <vprintf+0x22c>
        printptr(fd, va_arg(ap, uint64));
    5846:	8be6                	mv	s7,s9
      state = 0;
    5848:	4981                	li	s3,0
    584a:	6ca2                	ld	s9,8(sp)
    584c:	bbf5                	j	5648 <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
    584e:	008b8493          	addi	s1,s7,8
    5852:	000bc583          	lbu	a1,0(s7)
    5856:	855a                	mv	a0,s6
    5858:	cefff0ef          	jal	5546 <putc>
    585c:	8ba6                	mv	s7,s1
      state = 0;
    585e:	4981                	li	s3,0
    5860:	b3e5                	j	5648 <vprintf+0x44>
        if ((s = va_arg(ap, char *)) == 0)
    5862:	008b8993          	addi	s3,s7,8
    5866:	000bb483          	ld	s1,0(s7)
    586a:	cc91                	beqz	s1,5886 <vprintf+0x282>
        for (; *s; s++)
    586c:	0004c583          	lbu	a1,0(s1)
    5870:	c195                	beqz	a1,5894 <vprintf+0x290>
          putc(fd, *s);
    5872:	855a                	mv	a0,s6
    5874:	cd3ff0ef          	jal	5546 <putc>
        for (; *s; s++)
    5878:	0485                	addi	s1,s1,1
    587a:	0004c583          	lbu	a1,0(s1)
    587e:	f9f5                	bnez	a1,5872 <vprintf+0x26e>
        if ((s = va_arg(ap, char *)) == 0)
    5880:	8bce                	mv	s7,s3
      state = 0;
    5882:	4981                	li	s3,0
    5884:	b3d1                	j	5648 <vprintf+0x44>
          s = "(null)";
    5886:	00003497          	auipc	s1,0x3
    588a:	a5a48493          	addi	s1,s1,-1446 # 82e0 <malloc+0x2928>
        for (; *s; s++)
    588e:	02800593          	li	a1,40
    5892:	b7c5                	j	5872 <vprintf+0x26e>
        if ((s = va_arg(ap, char *)) == 0)
    5894:	8bce                	mv	s7,s3
      state = 0;
    5896:	4981                	li	s3,0
    5898:	bb45                	j	5648 <vprintf+0x44>
        putc(fd, '%');
    589a:	85be                	mv	a1,a5
    589c:	855a                	mv	a0,s6
    589e:	ca9ff0ef          	jal	5546 <putc>
    58a2:	bdbd                	j	5720 <vprintf+0x11c>
    58a4:	6906                	ld	s2,64(sp)
    58a6:	79e2                	ld	s3,56(sp)
    58a8:	7a42                	ld	s4,48(sp)
    58aa:	7aa2                	ld	s5,40(sp)
    58ac:	7b02                	ld	s6,32(sp)
    58ae:	6be2                	ld	s7,24(sp)
    58b0:	6c42                	ld	s8,16(sp)
    }
  }
}
    58b2:	60e6                	ld	ra,88(sp)
    58b4:	6446                	ld	s0,80(sp)
    58b6:	64a6                	ld	s1,72(sp)
    58b8:	6125                	addi	sp,sp,96
    58ba:	8082                	ret
      if (c0 == 'd') {
    58bc:	06400713          	li	a4,100
    58c0:	e6e782e3          	beq	a5,a4,5724 <vprintf+0x120>
      } else if (c0 == 'l' && c1 == 'd') {
    58c4:	f9478693          	addi	a3,a5,-108
    58c8:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
    58cc:	8532                	mv	a0,a2
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    58ce:	4701                	li	a4,0
    58d0:	bbe9                	j	56aa <vprintf+0xa6>

00000000000058d2 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
    58d2:	715d                	addi	sp,sp,-80
    58d4:	ec06                	sd	ra,24(sp)
    58d6:	e822                	sd	s0,16(sp)
    58d8:	1000                	addi	s0,sp,32
    58da:	e010                	sd	a2,0(s0)
    58dc:	e414                	sd	a3,8(s0)
    58de:	e818                	sd	a4,16(s0)
    58e0:	ec1c                	sd	a5,24(s0)
    58e2:	03043023          	sd	a6,32(s0)
    58e6:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
    58ea:	8622                	mv	a2,s0
    58ec:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
    58f0:	d15ff0ef          	jal	5604 <vprintf>
}
    58f4:	60e2                	ld	ra,24(sp)
    58f6:	6442                	ld	s0,16(sp)
    58f8:	6161                	addi	sp,sp,80
    58fa:	8082                	ret

00000000000058fc <printf>:

void
printf(const char *fmt, ...)
{
    58fc:	711d                	addi	sp,sp,-96
    58fe:	ec06                	sd	ra,24(sp)
    5900:	e822                	sd	s0,16(sp)
    5902:	1000                	addi	s0,sp,32
    5904:	e40c                	sd	a1,8(s0)
    5906:	e810                	sd	a2,16(s0)
    5908:	ec14                	sd	a3,24(s0)
    590a:	f018                	sd	a4,32(s0)
    590c:	f41c                	sd	a5,40(s0)
    590e:	03043823          	sd	a6,48(s0)
    5912:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
    5916:	00840613          	addi	a2,s0,8
    591a:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
    591e:	85aa                	mv	a1,a0
    5920:	4505                	li	a0,1
    5922:	ce3ff0ef          	jal	5604 <vprintf>
}
    5926:	60e2                	ld	ra,24(sp)
    5928:	6442                	ld	s0,16(sp)
    592a:	6125                	addi	sp,sp,96
    592c:	8082                	ret

000000000000592e <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
    592e:	1141                	addi	sp,sp,-16
    5930:	e406                	sd	ra,8(sp)
    5932:	e022                	sd	s0,0(sp)
    5934:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header *)ap - 1;
    5936:	ff050713          	addi	a4,a0,-16
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    593a:	00004797          	auipc	a5,0x4
    593e:	b867b783          	ld	a5,-1146(a5) # 94c0 <freep>
    5942:	a095                	j	59a6 <free+0x78>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if (bp + bp->s.size == p->s.ptr) {
    5944:	ff852583          	lw	a1,-8(a0)
    5948:	6390                	ld	a2,0(a5)
    594a:	02059813          	slli	a6,a1,0x20
    594e:	01c85693          	srli	a3,a6,0x1c
    5952:	96ba                	add	a3,a3,a4
    5954:	02d60563          	beq	a2,a3,597e <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
    5958:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if (p + p->s.size == bp) {
    595c:	4790                	lw	a2,8(a5)
    595e:	02061593          	slli	a1,a2,0x20
    5962:	01c5d693          	srli	a3,a1,0x1c
    5966:	96be                	add	a3,a3,a5
    5968:	02d70263          	beq	a4,a3,598c <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
    596c:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
    596e:	00004717          	auipc	a4,0x4
    5972:	b4f73923          	sd	a5,-1198(a4) # 94c0 <freep>
}
    5976:	60a2                	ld	ra,8(sp)
    5978:	6402                	ld	s0,0(sp)
    597a:	0141                	addi	sp,sp,16
    597c:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
    597e:	4614                	lw	a3,8(a2)
    5980:	9ead                	addw	a3,a3,a1
    5982:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
    5986:	6394                	ld	a3,0(a5)
    5988:	6290                	ld	a2,0(a3)
    598a:	b7f9                	j	5958 <free+0x2a>
    p->s.size += bp->s.size;
    598c:	ff852703          	lw	a4,-8(a0)
    5990:	9f31                	addw	a4,a4,a2
    5992:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
    5994:	ff053703          	ld	a4,-16(a0)
    5998:	bfd1                	j	596c <free+0x3e>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    599a:	6394                	ld	a3,0(a5)
    599c:	00d7e463          	bltu	a5,a3,59a4 <free+0x76>
    59a0:	fad762e3          	bltu	a4,a3,5944 <free+0x16>
    59a4:	87b6                	mv	a5,a3
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    59a6:	fee7fae3          	bgeu	a5,a4,599a <free+0x6c>
    59aa:	6394                	ld	a3,0(a5)
    59ac:	f8d76ce3          	bltu	a4,a3,5944 <free+0x16>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    59b0:	f8d7fae3          	bgeu	a5,a3,5944 <free+0x16>
    59b4:	87b6                	mv	a5,a3
    59b6:	bfc5                	j	59a6 <free+0x78>

00000000000059b8 <malloc>:
  return freep;
}

void *
malloc(uint nbytes)
{
    59b8:	7139                	addi	sp,sp,-64
    59ba:	fc06                	sd	ra,56(sp)
    59bc:	f822                	sd	s0,48(sp)
    59be:	f04a                	sd	s2,32(sp)
    59c0:	ec4e                	sd	s3,24(sp)
    59c2:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1) / sizeof(Header) + 1;
    59c4:	02051993          	slli	s3,a0,0x20
    59c8:	0209d993          	srli	s3,s3,0x20
    59cc:	09bd                	addi	s3,s3,15
    59ce:	0049d993          	srli	s3,s3,0x4
    59d2:	2985                	addiw	s3,s3,1
    59d4:	894e                	mv	s2,s3
  if ((prevp = freep) == 0) {
    59d6:	00004517          	auipc	a0,0x4
    59da:	aea53503          	ld	a0,-1302(a0) # 94c0 <freep>
    59de:	c905                	beqz	a0,5a0e <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
    59e0:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
    59e2:	4798                	lw	a4,8(a5)
    59e4:	09377663          	bgeu	a4,s3,5a70 <malloc+0xb8>
    59e8:	f426                	sd	s1,40(sp)
    59ea:	e852                	sd	s4,16(sp)
    59ec:	e456                	sd	s5,8(sp)
    59ee:	e05a                	sd	s6,0(sp)
  if (nu < 4096)
    59f0:	8a4e                	mv	s4,s3
    59f2:	6705                	lui	a4,0x1
    59f4:	00e9f363          	bgeu	s3,a4,59fa <malloc+0x42>
    59f8:	6a05                	lui	s4,0x1
    59fa:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
    59fe:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void *)(p + 1);
    }
    if (p == freep)
    5a02:	00004497          	auipc	s1,0x4
    5a06:	abe48493          	addi	s1,s1,-1346 # 94c0 <freep>
  if (p == SBRK_ERROR)
    5a0a:	5afd                	li	s5,-1
    5a0c:	a83d                	j	5a4a <malloc+0x92>
    5a0e:	f426                	sd	s1,40(sp)
    5a10:	e852                	sd	s4,16(sp)
    5a12:	e456                	sd	s5,8(sp)
    5a14:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
    5a16:	0000a797          	auipc	a5,0xa
    5a1a:	2d278793          	addi	a5,a5,722 # fce8 <base>
    5a1e:	00004717          	auipc	a4,0x4
    5a22:	aaf73123          	sd	a5,-1374(a4) # 94c0 <freep>
    5a26:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
    5a28:	0007a423          	sw	zero,8(a5)
    if (p->s.size >= nunits) {
    5a2c:	b7d1                	j	59f0 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
    5a2e:	6398                	ld	a4,0(a5)
    5a30:	e118                	sd	a4,0(a0)
    5a32:	a899                	j	5a88 <malloc+0xd0>
  hp->s.size = nu;
    5a34:	01652423          	sw	s6,8(a0)
  free((void *)(hp + 1));
    5a38:	0541                	addi	a0,a0,16
    5a3a:	ef5ff0ef          	jal	592e <free>
  return freep;
    5a3e:	6088                	ld	a0,0(s1)
      if ((p = morecore(nunits)) == 0)
    5a40:	c125                	beqz	a0,5aa0 <malloc+0xe8>
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
    5a42:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
    5a44:	4798                	lw	a4,8(a5)
    5a46:	03277163          	bgeu	a4,s2,5a68 <malloc+0xb0>
    if (p == freep)
    5a4a:	6098                	ld	a4,0(s1)
    5a4c:	853e                	mv	a0,a5
    5a4e:	fef71ae3          	bne	a4,a5,5a42 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
    5a52:	8552                	mv	a0,s4
    5a54:	a17ff0ef          	jal	546a <sbrk>
  if (p == SBRK_ERROR)
    5a58:	fd551ee3          	bne	a0,s5,5a34 <malloc+0x7c>
        return 0;
    5a5c:	4501                	li	a0,0
    5a5e:	74a2                	ld	s1,40(sp)
    5a60:	6a42                	ld	s4,16(sp)
    5a62:	6aa2                	ld	s5,8(sp)
    5a64:	6b02                	ld	s6,0(sp)
    5a66:	a03d                	j	5a94 <malloc+0xdc>
    5a68:	74a2                	ld	s1,40(sp)
    5a6a:	6a42                	ld	s4,16(sp)
    5a6c:	6aa2                	ld	s5,8(sp)
    5a6e:	6b02                	ld	s6,0(sp)
      if (p->s.size == nunits)
    5a70:	fae90fe3          	beq	s2,a4,5a2e <malloc+0x76>
        p->s.size -= nunits;
    5a74:	4137073b          	subw	a4,a4,s3
    5a78:	c798                	sw	a4,8(a5)
        p += p->s.size;
    5a7a:	02071693          	slli	a3,a4,0x20
    5a7e:	01c6d713          	srli	a4,a3,0x1c
    5a82:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
    5a84:	0137a423          	sw	s3,8(a5)
      freep = prevp;
    5a88:	00004717          	auipc	a4,0x4
    5a8c:	a2a73c23          	sd	a0,-1480(a4) # 94c0 <freep>
      return (void *)(p + 1);
    5a90:	01078513          	addi	a0,a5,16
  }
}
    5a94:	70e2                	ld	ra,56(sp)
    5a96:	7442                	ld	s0,48(sp)
    5a98:	7902                	ld	s2,32(sp)
    5a9a:	69e2                	ld	s3,24(sp)
    5a9c:	6121                	addi	sp,sp,64
    5a9e:	8082                	ret
    5aa0:	74a2                	ld	s1,40(sp)
    5aa2:	6a42                	ld	s4,16(sp)
    5aa4:	6aa2                	ld	s5,8(sp)
    5aa6:	6b02                	ld	s6,0(sp)
    5aa8:	b7f5                	j	5a94 <malloc+0xdc>
