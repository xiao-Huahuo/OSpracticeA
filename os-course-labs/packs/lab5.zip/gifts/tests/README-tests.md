# lab5 官方用户测试集（课程组出品 · 判分参照）

构建:内嵌方案,`UPROGS` 追加 `zerocopy cowpair`。
前置:lab5 三大件已实现(COW fork、缺页分支、计数 syscall sys_pmc)。
本包 gifts/ 的 user.h/usys.pl/kernel/syscall.h 已含 `SYS_pmc=24`
(与 lab4 的 SYS_schedstat=23 累积),以包内版本为准。

| 测试 | 覆盖 | 通过判据 |
|---|---|---|
| `zerocopy` | 零复制断言 | fork 立即 exec 的复制增量 ≤ 2,打印 `T5-1 PASS` |
| `cowpair` | 配对写+计数对账 | 共享计数>0、数据隔离、增量恰为 2,打印 `T5-2 PASS` |

说明:两测均为与 sid 无关的不变式;`LAB5_COW_BUDGET` 的耗尽降级
行为因人而异(合同允许报错/继续两态),不作自动断言,验收问答现场核。
