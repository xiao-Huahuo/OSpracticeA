# 赠送件 · dump_pagetable 调用点示例（Makefile/代码接线附录）

> 本文件是**示例**而非实现:展示 dump 的典型挂载点与重放方式,
> 输出格式契约见 `dump_pagetable-ABI.md`。

## 建议的调用点(三选一或并列)

1. **自动一次**:第一个用户进程页表装配完成后、`userret` 之前调用
   `dump_pagetable(p->pagetable)` —— 满足"装配完打印一次"的观测合同;
2. **现场重放**:把 dump 包成 `sys_dumps(0)` 一类的观测系统调用
   (调用号若新增,走与 lab4 schedstat 相同的"调用号表扩展"流程),
   供验收现场对任意进程重放;
3. **make 目标**:在 Makefile 加 `dump:` 目标,`make dump` 等价于
   `make qemu` + 预置注入(复用 lab2 的 inject_uart.py),输出重定向存档。

## 回归接线(lab4 验收必查)

lab4 回归 = 本 dump 重放正确。因此 dump 的输出**不得依赖全局唯一
进程**:重放时必须显式选择进程(或至少对"当前 sh 进程"成立)。
