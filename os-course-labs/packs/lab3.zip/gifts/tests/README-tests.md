# lab3 官方用户测试集（课程组出品 · 判分参照）

构建:与 lab2 相同的内嵌方案,`UPROGS` 追加 `badaccess memcap`。
前置:SV39 页表、guard 页与内存上限已实现(lab3 里程碑 3)。

| 测试 | 覆盖 | 通过判据 |
|---|---|---|
| `badaccess` | 越界/守卫页命中被杀 | TEST-3a/3b 均 PASS:子进程被杀而非存活,父进程 wait 回收,sh 存活 |
| `memcap` | 内存上限与 OOM 语义 | TEST-4 PASS:sbrk 到上限返回错误而非 panic,已分配内存可用 |

说明:两测均为**与 sid 无关的不变式**——上限数值因人而异
(LAB3_MEMCAP_DELTA),测试只断言"到顶报错、内核完好"的合同行为。
