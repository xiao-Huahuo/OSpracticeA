# 赠送件 · virtio_disk 依赖集定稿（你的缓存层合同）

> virtio 设备协议本身**不是教学目标**;驱动是环境事实。你只需要
> 让自己的 buf/bio 层满足以下调用面。

## 1. 驱动暴露的两个函数

```c
void virtio_disk_init(void);          // main 的 fs 初始化阶段调用一次
void virtio_disk_rw(struct buf *b, int write);  // write=1 写盘,0 读盘
```

## 2. 你的 struct buf 必须提供的最小字段集（参照 ref 树 virtio_disk.c 实际访问）

| 字段 | 类型 | 语义 |
|---|---|---|
| `data[BSIZE]` | `uchar[BSIZE]` | DMA 缓冲(驱动直接把它写进描述符) |
| `blockno` | `uint` | 设备扇区 = blockno × (BSIZE/512) |
| `disk` | `int` | 传输进行中标志:驱动置 1,中断完成处置 0;**睡眠通道 = &b->disk** |
| `valid` | `int`(可选) | 你的缓存层自用,驱动不触碰 |

字段名可不同——驱动按 `b->xxx` 访问,你以**最小 patch**(重命名或
包装结构)对齐;这就是"依赖集定稿"的全部内容。

## 3. 驱动对你方上下文的假设

1. `virtio_disk_rw` 内部会在 `b->disk==1` 上 **sleep** —— 因此调用者
   必须是**进程上下文**且不得持自旋锁(中断上下文禁止进盘路径);
2. 完成中断在设备中断处理里对 `&b->disk` 做 **wakeup** —— 你的
   sleep/wakeup 协议(lab4)必须支持中断上下文发唤醒;
3. BSIZE 与扇区换算固定为 `BSIZE/512` —— 你的 BSIZE 改动会破坏 DMA
   对齐,lab6 不允许改 BSIZE。

## 4. 冲击测试口径(教师侧)

以上 3 条即唯一耦合面;冲击测试仅验证:并发 virtio_disk_rw 不丢
描述符、完成中断不丢唤醒。其余(日志/缓存策略)均是你的实现域。
